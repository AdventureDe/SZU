<template>
  <view v-if="visible" class="modal-overlay">
    <view class="modal-content">
      <text>{{ message }}</text>
    </view>
  </view>
</template>

<script>
export default {
  data() {
    return {
      visible: false,   // 控制弹窗的显示和隐藏
      message: '',      // 弹窗的内容
      fading: false     // 控制渐变动画
    };
  },
  methods: {
    open(message, duration = 3000) {
      this.message = message;
      this.visible = true;
      this.fading = false;  // 确保渐变消失前，初始时不进行动画

      // 通过定时器设置渐隐动画
      setTimeout(() => {
        this.fading = true;  // 开始渐变消失动画
      }, duration - 500);   // 提前500ms开始渐变，这样就能在完全显示后渐隐消失

      // 3秒后自动关闭弹窗
      setTimeout(() => {
        this.visible = false;
        this.fading = false;  // 清除渐变状态
      }, duration);
    }
  }
}
</script>

<style scoped>
.modal-overlay {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: rgba(0, 0, 0, 0);
  display: flex;
  justify-content: center;
  align-items: center;
  opacity: 1;
  transition: opacity 0.5s ease-out;  /* 设置过渡动画 */
}

.modal-content {
  background-color: #990033;
  padding: 20px;
  border-radius: 20px;
  text-align: center;
  width: 80%;
  font-size: 16px;
}

.modal-overlay.fade-out {
  opacity: 0;  /* 渐变消失时的透明度 */
}
</style>

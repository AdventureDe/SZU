<template>
  <div>
    <label>
      <input type="checkbox" v-model="checked" /> 是否同意
    </label>
    <p>当前值：{{ checked }}</p>
  </div>
</template>

<script>
export default {
  data() {
    return {
      checked: false, // 初始值
    };
  },
};
</script>

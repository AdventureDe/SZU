//商家信息
const storeData = {
	//商家唯一标识
	store_id: '1005',
	//商家名称
	store_name: '螺娘·柳州螺蛳粉',
	//头像
	avatar: '/static/img/store_img/1005/1.jpg',
	//横幅图片
	banner: '/static/img/store_img/1005/1.jpg',
	//详情
	info: '好好好！',
	//商家住址
	address: '南山区学府社区桂庙路',
	//地标或社区
	community: '南山店',
	//配送时间
	delivery_time: '10:00~1:00',
	//联系电话
	telephone: '13499989916',
	//商家购物车
	shopping_cart: [],
	//配送费
	shipping_dees: 5,
	//配送起步价
	starting_price: 30
};

//首页门店列表
const storeList = [{
	//商户标识
	store_id: '1992',
	//店名
	name: '肯德基',
	//门头
	avatar: '/static/img/store_img/1992/1.jpg',
	//小区
	community: '深大店',
	//评分
	mark: '4.8',
	//月售
	monthly_sales: 356,
	//门店距离，按米计算
	distance: 114,
	//起送价
	starting_price: 50,
	//配送费
	shipping_dees: 5,
	//商品列表
	goods: [{
			//id
			id: '1',
			//商品名称
			name: '星期四',
			//主图
			main_pic: '/static/img/store_img/1992/1.jpg',
			//标签 【招牌，爆款，推荐】等等
			tag: '招牌',
			//现价
			price: 50,
			//原价
			old_price: 65,
		}, {
			id: '2',
			name: 'v50',
			main_pic: '/static/img/store_img/1992/1.jpg',
			tag: '招牌',
			price: 50,
			old_price: 65,
		}, {
			id: '3',
			name: '夜宵小食',
			main_pic: '/static/img/store_img/1992/1.jpg',
			tag: '爆款',
			price: 50,
			old_price: 65,
		}, {
			id: '4',
			name: '香辣鸡腿堡',
			main_pic: '/static/img/store_img/1992/1.jpg',
			tag: '爆款',
			price: 50,
			old_price: 65,
		}, {
			id: '5',
			name: '麦辣鸡腿',
			main_pic: '/static/img/store_img/1992/1.jpg',
			tag: '推荐',
			price: 50,
			old_price: 65,
		}, {
			id: '6',
			name: '香辣鸡翅',
			main_pic: '/static/img/store_img/1992/1.jpg',
			tag: '推荐',
			price: 45,
			old_price: 65,
		}

	]

}, {
	store_id: '853',
	name: '麦当劳',
	avatar: '/static/img/store_img/853/1.jpg',
	community: '深大丽湖店',
	mark: '4.8',
	monthly_sales: 356,
	distance: 234,
	starting_price: 30,
	shipping_dees: 5,
	goods: [{
		id: '1',
		name: '麦辣鸡腿堡',
		main_pic: '/static/img/store_img/853/1.jpg',
		tag: '招牌',
		price: 34,
		old_price: 65,
	}, {
		id: '2',
		name: '麦麦脆汁鸡',
		main_pic: '/static/img/store_img/853/1.jpg',
		tag: '爆款',
		price: 13,
		old_price: 29,
	}, {
		id: '3',
		name: '穷鬼套餐',
		main_pic: '/static/img/store_img/853/1.jpg',
		tag: '爆款',
		price: 13.9,
		old_price: 12.9,
	}, {
		id: '4',
		name: '巨无霸',
		main_pic: '/static/img/store_img/853/1.jpg',
		tag: '推荐',
		price: 15.5,
		old_price: 15.5,
	}, {
		id: '5',
		name: '芝士培根汉堡',
		main_pic: '/static/img/store_img/853/1.jpg',
		tag: '推荐',
		price: 24,
		old_price: 33,
	}]

}, {
	store_id: '999',
	name: '德克士',
	avatar: '/static/img/store_img/999/1.jpg',
	community: '深圳大学粤海校区',
	mark: '4.9',
	monthly_sales: 356,
	distance: 135,
	starting_price: 5,
	shipping_dees: 30,
	goods: [{
		id: '1',
		name: '鳕鱼堡',
		main_pic: '/static/img/store_img/999/1.jpg',
		tag: '招牌',
		price: 13,
		old_price: 22,
	}, {
		id: '2',
		name: '不素之霸',
		main_pic: '/static/img/store_img/999/1.jpg',
		tag: '爆款',
		price: 22,
		old_price: 43,
	}, {
		id: '3',
		name: '麦香鸡',
		main_pic: '/static/img/store_img/999/1.jpg',
		tag: '爆款',
		price: 13,
		old_price: 22,
	}, {
		id: '4',
		name: '单人餐',
		main_pic: '/static/img/store_img/999/1.jpg',
		tag: '推荐',
		price: 33.5,
		old_price: 66.5,
	}]

}, {
	store_id: '123',
	name: '瑞幸咖啡',
	avatar: '/static/img/store_img/123/1.jpg',
	community: '天庭',
	mark: '4.4',
	monthly_sales: 432,
	distance: 532,
	starting_price: 4,
	shipping_dees: 20,
	goods: [{
		id: '1',
		name: '生椰拿铁',
		main_pic: '/static/img/store_img/123/1.jpg',
		tag: '招牌',
		price: 11.31,
		old_price: 18,
	}, {
		id: '2',
		name: '轻轻茉莉',
		main_pic: '/static/img/store_img/123/1.jpg',
		tag: '爆款',
		price: 11,
		old_price: 14,
	}, {
		id: '3',
		name: '小黄油拿铁',
		main_pic: '/static/img/store_img/123/1.jpg',
		tag: '爆款',
		price: 12.48,
		old_price: 19,
	}, {
		id: '4',
		name: '丝绒拿铁',
		main_pic: '/static/img/store_img/123/1.jpg',
		tag: '推荐',
		price: 11.31,
		old_price: 23,
	}]
}, {
	store_id: '1005',
	name: '螺娘·柳州螺蛳粉',
	avatar: '/static/img/store_img/1005/1.jpg',
	community: '南山店',
	mark: '4.8',
	monthly_sales: 9000,
	distance: 1853,
	starting_price: 4,
	shipping_dees: 20,
	goods: [{
		id: '1',
		name: '原味螺蛳粉',
		main_pic: '/static/img/store_img/1005/1.jpg',
		tag: '招牌',
		price: 16.88,
		old_price: 32,
	}, {
		id: '2',
		name: '麻辣螺蛳粉',
		main_pic: '/static/img/store_img/1005/1.jpg',
		tag: '爆款',
		price: 32,
		old_price: 16.88,
	}, {
		id: '3',
		name: '老友粉螺蛳粉（河粉👍）',
		main_pic: '/static/img/store_img/1005/1.jpg',
		tag: '爆款',
		price: 18.88,
		old_price: 35,
	}, {
		id: '4',
		name: '原味螺蛳粉+煎蛋+豆腐串',
		main_pic: '/static/img/store_img/1005/1.jpg',
		tag: '推荐',
		price: 33.32,
		old_price: 34,
	}]

}]

//评论数据
const commentData = [{
		header_img: '/static/img/store_img/123/1.jpg',
		user_name: "Szuer_test",
		rate: 5,
		create_time: "2024.12.12",
		content: "好吃,赞,这家店自己已经回购很多次",
		imgs: [
			'/static/img/store_img/123/1.jpg',
			'/static/img/store_img/123/1.jpg',
			'/static/img/store_img/123/1.jpg',
			'/static/img/store_img/123/1.jpg'
		]
	},
	{
		content: "中评",
		create_time:"2024.12.12",
		header_img: '/static/img/store_img/123/1.jpg',
		user_name: "web3.0",
		rate: 4,
		// imgs:[]
	},
	{
		content: "超级棒",
		create_time: "2024.12.12",
		header_img: '/static/img/store_img/123/1.jpg',
		user_name: "荒漠屠夫",
		rate: 5,
		// imgs:[]
	}, {
		content: "好评",
		create_time: "2024.12.12",
		header_img: '/static/img/store_img/123/1.jpg',
		user_name: "cxk",
		rate: 5,
		imgs: [
			'/static/img/store_img/123/1.jpg',
			'/static/img/store_img/123/1.jpg',
			'/static/img/store_img/123/1.jpg',
			'/static/img/store_img/123/1.jpg'
		]
	},
	{
		content: "中评",
		create_time: "2024.12.12",
		header_img:'/static/img/store_img/1005/1.jpg',
		user_name: "封魔剑魂",
		rate: 3.5,
		// imgs:[]
	},
	{
		content: "吃了那么多家,这是我吃过最正宗的一家了,味道纯正,口感顶级。外卖小哥送餐及时,外卖包装精致,菜品看着也非常新鲜,五分好评",
		create_time: "2024.12.12",
		header_img:'/static/img/store_img/1005/1.jpg',
		user_name: "飞机",
		rate: 3,
		// imgs:[]
	}
];

//商品数据
const goodsData = [{
			id: 1,
			type_id: 1,
			name: '原味螺蛳粉🔥',
			descripe: "月售1000+",
			img: '/static/img/store_img/1005/1.jpg',
			price: "16.88",
			oldprice: "32",
			//规格
			form: {
				id: 1,
				name: "辣度"
			},
			form_child: [{
					id: 1,
					pid: 1,
					name: "不辣",
					price: "16.88",
					oldprice: "32",
					select: true
				},
				{
					id: 2,
					pid: 1,
					name: "微少辣",
					price:"16.88",
					oldprice:"32",
					select: false
				},
				{
					id: 3,
					pid: 1,
					name: "微辣",
					price: "16.88",
					oldprice: "32",
					select: false
				},
				{
					id: 4,
					pid: 1,
					name: "中辣",
					price: "16.88",
					oldprice: "32",
					select: false
				},
				{
					id: 5,
					pid: 1,
					name: "特辣",
					price: "16.88",
					oldprice: "32",
					select: false
				}],
}, 
{			id: 2,
			type_id: 1,
			name: '多菜少粉🥬',
			descripe: "月售700+",
			img: '/static/img/store_img/1005/1.jpg',
			price: "17.88",
			oldprice: "32",
			form: {
				id: 1,
				name: "辣度"
			},
			form_child: [{
					id: 1,
					pid: 1,
					name: "不辣",
					price: "16.88",
					oldprice: "32",
					select: true
				},
				{
					id: 2,
					pid: 1,
					name: "微少辣",
					price:"16.88",
					oldprice:"32",
					select: false
				},
				{
					id: 3,
					pid: 1,
					name: "微辣",
					price: "16.88",
					oldprice: "32",
					select: false
				},
				{
					id: 4,
					pid: 1,
					name: "中辣",
					price: "16.88",
					oldprice: "32",
					select: false
				},
				{
					id: 5,
					pid: 1,
					name: "特辣",
					price: "16.88",
					oldprice: "32",
					select: false
				}],
	
},
{			id: 3,
			type_id: 1,
			name: '老友粉😁',
			descripe: "月售200+",
			img: '/static/img/store_img/1005/1.jpg',
			price: "16.88",
			oldprice: "32",
			form: {
				id: 1,
				name: "辣度"
			},
			form_child: [{
					id: 1,
					pid: 1,
					name: "不辣",
					price: "16.88",
					oldprice: "32",
					select: true
				},
				{
					id: 2,
					pid: 1,
					name: "微少辣",
					price:"16.88",
					oldprice:"32",
					select: false
				},
				{
					id: 3,
					pid: 1,
					name: "微辣",
					price: "16.88",
					oldprice: "32",
					select: false
				},
				{
					id: 4,
					pid: 1,
					name: "中辣",
					price: "16.88",
					oldprice: "32",
					select: false
				},
				{
					id: 5,
					pid: 1,
					name: "特辣",
					price: "16.88",
					oldprice: "32",
					select: false
				}],
	
},
{
	id: 4,
	type_id: 2,
	name: '虎皮扣肉螺蛳粉',
	descripe: "月售500+",
	img: '/static/img/store_img/1005/1.jpg',
	price: "22.88",
	oldprice: "40",
}, {
	id: 5,
	type_id: 2,
	name: '炸弹螺蛳粉',
	descripe: "月售1000+",
	img: '/static/img/store_img/1005/1.jpg',
	price: "21.88",
	oldprice: "38",

}, {
	id: 6,
	type_id: 3,
	name: '鸭血',
	descripe: "月售100+",
	img: '/static/img/store_img/1005/1.jpg',
	price: "3",
	oldprice: "5"
}, {
	id: 7,
	type_id: 3,
	name: '螺肉',
	descripe: "月售96",
	img: '/static/img/store_img/1005/1.jpg',
	price: "7.3",
	oldprice: "15"
}, {
	id: 8,
	type_id: 4,
	name: '油麦菜',
	descripe: "月售21",
	img: '/static/img/store_img/1005/1.jpg',
	price: "4.9",
	oldprice: ""
}, {
	id:9,
	type_id: 4,
	name: '海带结',
	descripe: "月售291",
	img: '/static/img/store_img/1005/1.jpg',
	price: "2.9",
	oldprice: "6"
}, {
	id: 10,
	type_id: 5,
	name: '响铃卷',
	descripe: "月售100+",
	img: '/static/img/store_img/1005/1.jpg',
	price: "3.88",
	oldprice: "3.99"
}, {
	id: 11,
	type_id: 5,
	name: '七彩椒',
	descripe: "月售60",
	img: '/static/img/store_img/1005/1.jpg',
	price: "4",
	oldprice: ""
}, {
	id: 12,
	type_id: 5,
	name: '香菜',
	descripe: "月售500+",
	img: '/static/img/store_img/1005/1.jpg',
	price: "0.66",
	oldprice: ""
}, {
	id: 13,
	type_id: 6,
	name: '豆奶',
	descripe: "月售100+",
	img: '/static/img/store_img/1005/1.jpg',
	price: "3.99",
	oldprice: "5"
}, {
	id: 14,
	type_id: 6,
	name: '橙汁饮料',
	descripe: "月售35",
	img: '/static/img/store_img/1005/1.jpg',
	price: "4",
	oldprice: "",

}, {
	id: 15,
	type_id: 6,
	name: '柠檬茶',
	descripe: "月售37",
	img: '/static/img/store_img/1005/1.jpg',
	price: "4",
	oldprice: "5"
},
{
	id: 15,
	type_id: 7,
	name: '木薯糖水🥣',
	descripe: "月售100+",
	img: '/static/img/store_img/1005/1.jpg',
	price: "9.6",
	oldprice: "9.9"
},
{
	id: 16,
	type_id: 8,
	name: '干捞螺蛳粉',
	descripe: "月售100+",
	img: '/static/img/store_img/1005/1.jpg',
	price: "18.88",
	oldprice: "36"
},
{
	id: 17,
	type_id: 8,
	name: '干捞螺丝面',
	descripe: "月售12",
	img: '/static/img/store_img/1005/1.jpg',
	price: "18.88",
	oldprice: "36"
},
{
	id: 18,
	type_id: 8,
	name: '螺肉干捞螺蛳粉',
	descripe: "月售21",
	img: '/static/img/store_img/1005/1.jpg',
	price: "24.88",
	oldprice: "36"
},
{
	id: 19,
	type_id: 8,
	name: '肥肠干捞螺蛳粉',
	descripe: "月售14",
	img: '/static/img/store_img/1005/1.jpg',
	price: "26.88",
	oldprice: "36"
},
{
	id: 20,
	type_id: 9,
	name: '堂食门店',
	descripe: "月售999999+",
	img: '/static/img/store_img/1005/1.jpg',
	price: "0",
	oldprice: ""
},
{
	id: 21,
	type_id:9,
	name: '骨汤现熬',
	descripe: "月售999999+",
	img: '/static/img/store_img/1005/1.jpg',
	price: "0",
	oldprice: ""
},
{
	id: 22,
	type_id: 9,
	name: '品牌连锁',
	descripe: "月售999999+",
	img: '/static/img/store_img/1005/1.jpg',
	price: "0",
	oldprice: ""
},
{
	id: 23,
	type_id: 9,
	name: '手艺传承',
	descripe: "月售999999+",
	img: '/static/img/store_img/1005/1.jpg',
	price: "0",
	oldprice: ""
},
{
	id:24,
	type_id: 9,
	name: 'test-item',
	descripe: "月售999999+",
	img: '/static/img/store_img/1005/1.jpg',
	price: "0.03",
	oldprice: ""
}
];

//商品种类数据 typeid
const categoryData = [{
		id: 1,
		name: '进店必选👍'
	},
	{
		id: 2,
		name: '热惠套餐😍'
	},
	{
		id: 3,
		name: '新鲜限卤🍗'
	},
	{
		id: 4,
		name: '素材加餐🥬'
	},
	{
		id: 5,
		name: '加佐料区🥰'
	},
	{
		id: 6,
		name: '酒水饮料🍹'
	},
	{
		id:7,
		name:'糖水🥣'
	},
	{
		id:8,
		name:'干捞卤粉😊'
	},
	{
		id:9,
		name:'明厨亮灶'
	}
];

//商品详细
const goodsInfo = {
	//商品id
	id: 18,
	//商品类id
	type_id: 1,
	//商品名称
	name: '新疆特色辣子鸡排饭',
	//商品描述-就是掌柜描述，
	descripe: "口味可以自己选，有香辣、蒜香、葱香、孜然、老麻口味",
	//主图
	img:'/static/img/store_img/1005/1.jpg',
	//滚动图片
	banner_img: ['/static/img/store_img/1005/1.jpg','/static/img/store_img/1005/1.jpg',
		'/static/img/store_img/1005/1.jpg'
	],
	//现价
	price: "23",
	//原价
	oldprice: "44",
	//月销售
	monthly_sales: "566",
	//商品标签
	goods_tag: ['约800克', '香辣', '特色菜', '营养美食'],
	//规格
	form: {
		id: 1,
		name: "尺寸"
	},
	form_child: [{
			id: 81,
			pid: 1,
			name: "8寸500g",
			price: "46",
			oldprice: "100",
			select: true
		},
		{
			id: 82,
			pid: 1,
			name: "10寸600g",
			price: "97",
			oldprice: "100",
			select: false
		},
		{
			id: 83,
			pid: 1,
			name: "12寸800g",
			price: "135",
			oldprice: "100",
			select: false
		},
		{
			id: 84,
			pid: 1,
			name: "四川麻辣",
			price: "12",
			oldprice: "100",
			select: false
		},
		{
			id: 85,
			pid: 1,
			name: "香辣",
			price: "20",
			oldprice: "100",
			select: false
		},
		{
			id: 86,
			pid: 1,
			name: "卤香",
			price: "90",
			oldprice: "100",
			select: false
		},
		{
			id: 87,
			pid: 1,
			name: "鲜甜广味",
			price: "80",
			oldprice: "100",
			select: false
		},
		{
			id: 88,
			pid: 1,
			name: "镇店茴香味",
			price: "100",
			oldprice: "100",
			select: false
		}
	],
	//详情
	detail: [{
			tit: '掌柜描述',
			txt: '口味可以自己选，有香辣、蒜香、葱香、孜然、老麻口味',
		}, {
			tit: '主料',
			txt: '鸡胸排，大葱',
		}, {
			tit: '菜系',
			txt: '新疆特色菜',
		}, {
			tit: '口味',
			txt: '香辣',
		}
		//......更多
	],
	//图文
	desc: `
		<view style="width:100%">
			<image style="width:100%;display:block;" src="//imgs.1op.cn/i/hxshop/goods/14.jpg" />
			<image style="width:100%;display:block;" src="//imgs.1op.cn/i/hxshop/goods/7.jpg" />
			<image style="width:100%;display:block;" src="//imgs.1op.cn/i/hxshop/goods/6.jpg" />
			<image style="width:100%;display:block;" src="//imgs.1op.cn/i/hxshop/goods/3.jpg" />
			<image style="width:100%;display:block;" src="//imgs.1op.cn/i/hxshop/goods/1.jpg" />
		</view>
	`,
};

//商品评价
const goodsEva = {
	//总评价数
	sum: '386',
	//好评
	praise: '306',
	//差评
	bad_review: '80',
	//评价标签
	eva_tag: {
		//有图
		'exist_pic': '62',
		//赞
		'appreciate': '96',
		//踩
		'oppose': '16',
		//其他标签
		'other': ['92%人口味满意', '300人希望再次购买']
	},
	eva_list: [{
			//用户名
			name: '白色的太阳',
			//头像
			avatar: '/static/img/store_img/1005/1.jpg',
			//评论时间
			time: '2020.03.12',
			//点赞或踩商品,没有投票【0】、赞【1】、踩【2】
			point: 1,
			//评价内容
			content: "味道好极了，家里人超爱吃，希望下次能多放点辣椒，我们家吃辣",
			//上传的图片
			pic: ['/static/img/store_img/1005/1.jpg', '/static/img/store_img/1005/1.jpg',
				'/static/img/store_img/1005/1.jpg'
			]
		},
		{
			//用户名
			name: '匿名用户',
			//头像
			avatar: '/static/img/store_img/1005/1.jpg',
			//评论时间
			time: '2020.03.16',
			//点赞或踩商品,没有投票【0】、赞【1】、踩【2】
			point: 2,
			//评价内容
			content: "",
			//上传的图片
			pic: []
		},
		{
			//用户名
			name: '匿名用户',
			//头像
			avatar: '/static/img/store_img/1005/1.jpg' ,
			//评论时间
			time: '2020.03.16',
			//点赞或踩商品,没有投票【0】、赞【1】、踩【2】
			point: 0,
			//评价内容
			content: "一般般",
			//上传的图片
			pic: []
		},
	]
}

// 订单
const ordersData = [{
		id: 'MS2020041101',
		store_id: 168,
		tag:'/static/img/store_img/1005/1.jpg',
		store_name: '肯德基',
		community: '深大店',
		avatar:  '/static/img/store_img/1005/1.jpg',
		create_time: '2024-12-14 19:51',
		total: 50,
		//订单状态 [1已取消，2待支付，3待收货，4待评价，5完成，6退款中，7退款完成]
		status: 3,
	},
	{
		id: 'MS2020041102',
		store_id: 186,
		tag:'/static/img/store_img/1005/1.jpg',
		store_name: '麦当劳',
		community: '深大丽湖点',
		avatar:  '/static/img/store_img/1005/1.jpg',
		create_time: '2024-12-14 19:51',
		total: 34,
		//订单状态 [1已取消，2待支付，3待收货，4待评价，5完成，6退款中，7退款完成]
		status: 2,
	},
	{
		id: 'MS2020041103',
		store_id: 183,
		tag: '/static/img/store_img/1005/1.jpg',
		store_name: '柳州螺蛳粉',
		community: '南山店',
		avatar:  '/static/img/store_img/1005/1.jpg',
		create_time:'2024-12-14 19:51',
		total: 16.88,
		//订单状态 [1已取消，2待支付，3待收货，4待评价，5完成，6退款中，7退款完成]
		status: 1,
	},
	{
		id: 'MS2020041104',
		store_id: 182,
		tag: '/static/img/store_img/1005/1.jpg',
		store_name: '四川特色冒菜',
		community: '科技园店',
		avatar:  '/static/img/store_img/1005/1.jpg',
		create_time: '2024-12-14 19:51',
		total: 24.77,
		//订单状态 [1已取消，2待支付，3待收货，4待评价，5完成，6退款中，7退款完成]
		status: 4,
	},
	{
		id: 'MS2020041105',
		store_id: 181,
		tag: '/static/img/store_img/1005/1.jpg',
		store_name: '绝味鸭脖',
		community: '海岸城店',
		avatar:  '/static/img/store_img/1005/1.jpg',
		create_time: '2024-12-14 19:51',
		total: 54.9,
		//订单状态 [1已取消，2待支付，3待收货，4待评价，5完成，6退款中，7退款完成]
		status: 5,
	},
	{
		id: 'MS2020041106',
		store_id: 180,
		tag: '/static/img/store_img/1005/1.jpg',
		store_name: '萨莉亚',
		community: '深大店',
		avatar: '/static/img/store_img/1005/1.jpg',
		create_time: '2024-12-14 19:51',
		total:34.5,
		//订单状态 [1已取消，2待支付，3待收货，4待评价，5完成，6退款中，7退款完成]
		status: 6,
	},
	{
		id: 'MS2020041107',
		store_id: 170,
		tag: '/static/img/store_img/1005/1.jpg',
		store_name: '肯德基',
		community: '科技园店',
		avatar: '/static/img/store_img/1005/1.jpg',
		create_time: '2024-12-14 19:51',
		total: 46,
		//订单状态 [1已取消，2待支付，3待收货，4待评价，5完成，6退款中，7退款完成]
		status: 7,
	}
]

export default {
	storeData,
	storeList,
	commentData,
	goodsData,
	categoryData,
	goodsInfo,
	goodsEva,
	ordersData
}
<template>
	<view>
		<hx-navbar left-text="帮助" defaultBackUrl="help_feedback" :background-color="[245,245,245]"></hx-navbar>
		
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			}
		},
		methods: {
			
		}
	}
</script>

<style>

</style>

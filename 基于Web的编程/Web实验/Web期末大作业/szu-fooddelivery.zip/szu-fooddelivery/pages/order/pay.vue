<template>
	<view>
		<hx-navbar title="支付订单" :backgroundColor="[241,241,241]"></hx-navbar>
		<view class="head">
			<view class="row">
				<text v-if="countdownStr">支付剩余时间 {{countdownStr}}</text>
				<text v-else>重新提交订单</text>
			</view>
			<view class="row pricebox pt-8">
				<text class="fh">￥</text>
				<text class="txt1">{{orderInfo.money}}</text>
			</view>
			<view class="row pt-4">
				<text>{{orderInfo.store_name}}</text>
				<text v-if="orderInfo.store_community">（{{orderInfo.store_community}}）</text>
				<text>订单详情</text>
				<i class="hxicon-right"></i>
			</view>
		</view>
		<view class="container">
			<radio-group class="list-box">
				<block v-for="(item,i) in payData" :key="i">
					<view class="flex-rl list-item">
						<view class="left">
							<view class="iconbox" :style="'background-color:' + item.icon_color">
								<image class='icon' src='@/static/img/user/matemask.png'></image>
							</view>

						</view>
						<view class="b-b right">
							<view class="tit-box">
								<text class="tit">{{item.name}}</text>
							</view>
							<radio :value="item.id" color="#990033" />
						</view>
					</view>
				</block>
			</radio-group>
		</view>
		<custom-modal ref="modal"></custom-modal>
		<view class="btn" @click="submitPay">
			<text>确认支付</text>
		</view>
	</view>
</template>
<script>
	import CustomModal from '@/components/tanchuang/tanchuang.vue'; // 导入自定义弹窗组件
	import axios from 'axios';

	export default {
		components: {
			CustomModal // 注册 CustomModal 组件
		},
		onLoad(option) {
			let that = this;
			// 获取订单id
			if (option.id) {
				// 可以根据订单id获取订单数据
			}
		},
		onReady() {
			let that = this;
			that.orderInfo = {
				order_id: "1",
				money: 16.88,
				store_name: '螺娘·柳州螺蛳粉',
				store_community: '南山店',
				create_date: "2024-12-18 13:58:37",
				expiration_date: "2024-12-18 14:28:37"
			};

			// 设置默认支付方式
			for (let i in this.payData) {
				if (this.payData[i].default == 1) {
					this.payType = this.payData[i].id;
				}
			}
		},
		data() {
			return {
				countdownStr: "00:00",
				orderInfo: {},
				payType: "metamask",
				payData: [{
					id: "metamask",
					name: "MetaMask",
					icon: "hxicon-weixinzhifu",
					icon_color: "#ffffff",
					default: 1,
				}],
			};
		},
		methods: {
			async submitPay() {
				// 提交支付请求的参数
				const payload = {
					amount: 0.01, // 转账金额，以以太币为单位
					fromAddress: '0x9251C09d0ae5Ec0D4CA3E9F2B47e8907e85e58e3',
					toAddress: '0x9692B936bB84aaf4e5fBd305c856a65eE6E0888a'
				};
				const walletAddress='0x9251C09d0ae5Ec0D4CA3E9F2B47e8907e85e58e3';
				const message = `签名以交易: ${new Date().toISOString()}`;
				const signature = await window.ethereum.request({
					method: 'personal_sign',
					params: [message, walletAddress]
				});
				// 使用 axios 向后端发送 POST 请求
				axios.post('http://localhost:5000/pay', payload)
				.then(response => {
						// 处理成功的响应
						console.log(response.data)
						if (response.data.success) {
							this.$refs.modal.open("支付成功!", 2000);
							uni.switchTab({
								url: '/pages/index/index'
							});
						} else {
							this.$refs.modal.open("支付失败！", 2000);
						}
					})
					.catch(error => {
						// 处理请求失败的情况
						console.error('请求失败:', error);
						alert("请求失败，请稍后重试");
					});
			}
		},
	}
</script>

<style lang="scss">
	page {
		background-color: #f1f1f1;
	}

	.pt-8 {
		margin-top: 8px;
	}

	.pt-4 {
		margin-top: 4px;
	}

	.flex-rl {
		display: flex;
		flex-direction: row;
		justify-content: space-between;
	}

	.head {
		display: flex;
		flex-direction: column;
		justify-content: center;
		padding: 30px 15px;

		.row {
			display: flex;
			flex-direction: row;
			justify-content: center;
			font-size: 12px;
			color: #888;

			.fh {
				font-size: 16px;
				font-weight: bold;
				color: #000;
			}

			.txt1 {
				font-size: 34px;
				font-weight: bold;
				color: #000;
			}

			[class*="hxicon-"] {
				position: relative;
				top: 3px;
				margin-left: 3px;
			}
		}

		.pricebox {
			display: flex;
			flex-direction: row;
			align-items: baseline;
		}

	}

	.container {
		margin: 15px;
		border-radius: 10px;
		background-color: #fff;
		overflow: hidden;
		padding: 0 8px 0 14px;

		.list-box {
			display: flex;
			flex-direction: column;

			.list-item {
				display: flex;
				flex-direction: row;

				align-items: center;
				height: 50px;


				.left {
					display: flex;
					flex-direction: row;
					align-items: center;

					.iconbox {
						display: flex;
						flex-direction: row;
						justify-content: center;
						align-items: center;
						height: 24px;
						width: 24px;
						border-radius: 4px;

						.icon {
							width: 20px;
							height: 20px;
						}

					}


				}

				.right {
					display: flex;
					flex-direction: row;
					align-items: center;
					flex: 1;
					height: 100%;

					.tit-box {
						flex: 1;

						.tit {
							font-size: 16px;
							font-family: "Arial";
							color: #333;
							font-weight: bold;
							margin-left: 6px;
						}
					}

				}
			}
		}
	}

	.btn {
		position: fixed;
		display: flex;
		flex-direction: row;
		justify-content: center;
		align-items: center;
		border-radius: 10px;
		overflow: hidden;
		bottom: 15px;
		left: 15px;
		right: 15px;
		height: 45px;
		font-size: 16px;
		font-weight: bold;
		color: #333;
		background: linear-gradient(45deg, #990033, #ff007f);
	}
</style>
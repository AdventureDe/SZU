<template>
	<view class="login-container">
		<div class="stars">
			<div class="star star1"></div>
			<div class="star star2"></div>
			<div class="star star3"></div>
			<div class="star star4"></div>
			<div class="star star5"></div>
			<div class="star star6"></div>
			<div class="star star7"></div>
			<div class="star star8"></div>
			<div class="star star9"></div>
			<div class="star star10"></div>
			<div class="star star11"></div>
			<div class="star star12"></div>
			<div class="star star13"></div>
			<div class="star star14"></div>
			<div class="star star15"></div>
			<div class="star star16"></div>
			<div class="star star17"></div>
			<div class="star star18"></div>
			<div class="star star19"></div>
			<div class="star star20"></div>
		</div>

		<view class="header">
			<text class="banner">
				Szu外卖
			</text>
		</view>
		<view class="login1">
			<button @click="connectMetaMask" class="login-button">
				<image class="button-icon" src="/static/img/user/matemask.png" mode=""></image>
				MetaMask登录/注册
			</button>
			<p v-if="error" class="error-message">{{ error }}</p>
		</view>
		<button @click="connectMetaMask" class="login-button">
			<image class="button-icon" src="/static/img/user/trustwallet.png" mode=""></image>
			Trust Wallet登录/注册
		</button>
		<button @click="connectMetaMask" class="login-button">
			<image class="button-icon" src="/static/img/user/coinbasewallet.png" mode=""></image>
			Coinbase Wallet登录/注册
		</button>

		<view class="agreement-section">
			<checkbox-group v-model="agreementChecked">
				<checkbox id="check" class="check" :checked="agreementChecked" @change="handleCheckboxChange" />
			</checkbox-group>

			<label for="check">
				未注册钱包登录后将自动生成账号，且代表您已经阅读并同意
				<text @click="navigateTo('/pages/base/protocol/protocol')" class="agreement-link">
					《用户协议》
				</text>
				和
				<text @click="navigateTo('/pages/base/protocol/policy')" class="agreement-link">
					《隐私政策》
				</text>
			</label>
		</view>
	</view>
</template>

<script>
	export default {
		name: "Login",
		data() {
			return {
				accounts: [],
				selectedAccount: null,
				selectedRole: "user",
				showAccountPopup: false, // 控制弹窗显示
				agreementChecked: true,
				error: null,
			};
		},
		methods: {

			navigateTo(page) {
				uni.navigateTo({
					url: page
				});
			},
			formatAccountAddress(address) {
				return address.slice(0, 6) + '...' + address.slice(-4);
			},
			handleCheckboxChange(e) {
				this.agreementChecked = e.detail.value;
			},
			async connectMetaMask() {
				if (!this.agreementChecked) {
					this.error = "请先阅读并同意用户协议和隐私政策。";
					return;
				}

				if (typeof window.ethereum === "undefined") {
					this.error = "未安装MetaMask。请安装它以登录。";
					return;
				}

				try {
					// 请求 MetaMask 地址
					const accounts = await window.ethereum.request({
						method: "eth_requestAccounts"
					});

					if (accounts.length === 0) {
						this.error = "未能获取钱包地址。";
						return;
					}

					const walletAddress = accounts[0];
					console.log("钱包地址:", walletAddress); // 调试输出

					// 获取签名
					const message = `签名以登录: ${new Date().toISOString()}`;
					const signature = await window.ethereum.request({
						method: 'personal_sign',
						params: [message, walletAddress]
					});

					console.log("签名:", signature); // 调试输出

					// 向 Flask 后端发送请求
					const response = await uni.request({
						url: 'http://localhost:5000/login',
						method: 'POST',
						data: {
							wallet_address: walletAddress,
							signature: signature
						},
						success: (res) => {
							console.log(res.data); // 调试输出
							if (res.data.message === "登录成功" || res.data.message === "注册成功") {
								setTimeout(() => {
									uni.switchTab({
										url: '/pages/index/index'
									});
								}, 500); // 延迟500ms跳转

							} else {
								this.error = res.data.error || "未知错误";
							}
						},
						fail: (err) => {
							console.error("请求失败:", err); // 调试输出
							this.error = "连接到服务器失败";
						}
					});
				} catch (err) {
					console.error("MetaMask 错误:", err); // 调试输出
					this.error = "未能连接到MetaMask： " + err.message;
				}
			}
		},
	};
</script>

<style lang="scss">
	/* 动态星空背景 */
	.stars {
		position: absolute;
		top: 0;
		left: 0;
		width: 100%;
		height: 100%;
		pointer-events: none;
		overflow: hidden;
	}

	.star {
		position: absolute;
		border-radius: 50%;
		background-color: white;
		opacity: 0.8;
		animation: twinkle 1.5s infinite ease-in-out, fall 5s infinite linear;
	}

	/* 生成随机星星 */
	.star1 {
		width: 2px;
		height: 2px;
		top: -10px;
		left: 55%;
		animation: twinkle 1.5s infinite ease-in-out, fall 5s infinite linear;
	}

	.star2 {
		width: 3px;
		height: 3px;
		top: -20px;
		left: 20%;
		animation: twinkle 2s infinite ease-in-out, fall 6s infinite linear;
	}

	.star3 {
		width: 1px;
		height: 1px;
		top: -15px;
		left: 30%;
		animation: twinkle 1.2s infinite ease-in-out, fall 4s infinite linear;
	}

	.star4 {
		width: 5px;
		height: 5px;
		top: 5px;
		left: 50%;
		animation: twinkle 1.8s infinite ease-in-out, fall 7s infinite linear;
	}

	/* 更多星星 */
	.star5 {
		width: 1.5px;
		height: 1.5px;
		top: -10px;
		left: 70%;
		animation: twinkle 1.7s infinite ease-in-out, fall 8s infinite linear;
	}

	.star6 {
		width: 2.5px;
		height: 2.5px;
		top: -30px;
		left: 80%;
		animation: twinkle 2s infinite ease-in-out, fall 6.5s infinite linear;
	}

	.star7 {
		width: 1px;
		height: 1px;
		top: -25px;
		left: 90%;
		animation: twinkle 1.4s infinite ease-in-out, fall 7.2s infinite linear;
	}

	.star8 {
		width: 2px;
		height: 2px;
		top: -30px;
		left: 15%;
		animation: twinkle 1.6s infinite ease-in-out, fall 5s infinite linear;
	}

	.star9 {
		width: 3px;
		height: 3px;
		top: -20px;
		left: 25%;
		animation: twinkle 2.1s infinite ease-in-out, fall 6s infinite linear;
	}

	.star10 {
		width: 1.5px;
		height: 1.5px;
		top: -25px;
		left: 35%;
		animation: twinkle 1.5s infinite ease-in-out, fall 4.5s infinite linear;
	}

	.star11 {
		width: 2.5px;
		height: 2.5px;
		top: -15px;
		left: 45%;
		animation: twinkle 1.8s infinite ease-in-out, fall 5.5s infinite linear;
	}

	.star12 {
		width: 1px;
		height: 1px;
		top: -10px;
		left: 55%;
		animation: twinkle 1.7s infinite ease-in-out, fall 6.2s infinite linear;
	}

	.star13 {
		width: 2px;
		height: 2px;
		top: -30px;
		left: 65%;
		animation: twinkle 2.3s infinite ease-in-out, fall 5.3s infinite linear;
	}

	.star14 {
		width: 1.8px;
		height: 1.8px;
		top: -40px;
		left: 75%;
		animation: twinkle 1.9s infinite ease-in-out, fall 6.8s infinite linear;
	}

	.star15 {
		width: 2px;
		height: 2px;
		top: -50px;
		left: 85%;
		animation: twinkle 1.6s infinite ease-in-out, fall 7s infinite linear;
	}

	.star16 {
		width: 1.5px;
		height: 1.5px;
		top: -20px;
		left: 5%;
		animation: twinkle 1.8s infinite ease-in-out, fall 6.1s infinite linear;
	}

	.star17 {
		width: 3px;
		height: 3px;
		top: -10px;
		left: 10%;
		animation: twinkle 1.4s infinite ease-in-out, fall 5.2s infinite linear;
	}

	.star18 {
		width: 2.5px;
		height: 2.5px;
		top: -30px;
		left: 20%;
		animation: twinkle 2.2s infinite ease-in-out, fall 5.7s infinite linear;
	}

	.star19 {
		width: 1px;
		height: 1px;
		top: -25px;
		left: 40%;
		animation: twinkle 1.3s infinite ease-in-out, fall 6.3s infinite linear;
	}

	.star20 {
		width: 2px;
		height: 2px;
		top: -35px;
		left: 60%;
		animation: twinkle 1.5s infinite ease-in-out, fall 6.5s infinite linear;
	}

	/* 星星闪烁动画 */
	@keyframes twinkle {

		0%,
		100% {
			opacity: 0.6;
		}

		50% {
			opacity: 1;
		}
	}

	/* 星星下落动画 */
	@keyframes fall {
		0% {
			transform: translateY(0);
		}

		100% {
			transform: translateY(100vh);
		}
	}

	.login-container {
		display: flex;
		flex-direction: column;
		align-items: center;
		justify-content: center;
		height: 100vh;
		background-color: black;
		font-family: Arial, sans-serif;
		position: relative;
	}

	.role-selector {
		position: absolute;
		top: 20px;
		right: 20px;
	}

	.header {
		margin-bottom: 100rpx;
	}

	.banner {
		font-size: 160rpx;
		font-family: "宋体";
		color: #00ffff;
	}

	label {
		font-size: 16px;
		color: white;
	}

	.login-button {
		display: flex;
		align-items: center;
		justify-content: center;
		background-color: #007bff;
		border: none;
		border-radius: 5px;
		color: #fff;
		font-size: 16px;
		font-family: sans-serif;
		padding: 12px 20px;
		margin: 30px;
		width: 300px;
		height: 50px;
		text-align: center;
		text-decoration: none;
		transition: background-color 0.3s ease-in-out;
	}


	.button-icon {
		margin-right: 10px;
		width: 20px;
		height: 20px;
	}

	.error-message {
		color: red;
		font-size: 16px;
		/* 根据需要调整字体大小 */
		text-align: center;
		margin-top: 15px;
		/* 设置错误信息与按钮的距离 */
		width: 100%;
		display: block;
		/* 使其独占一行 */
		padding: 0 20px;
		/* 适当的左右内边距 */
	}

	.account-dropdown {
		width: 100%;
		padding: 8px;
		margin: 10px 0;
		font-size: 16px;
		border: 1px solid #ccc;
		border-radius: 4px;
	}

	.accounts-container {
		margin: 10px 0;
	}

	.agreement-section {
		display: flex;
		align-items: center;
		justify-content: center;
		margin-top: 40px;
		color: white;
		font-size: 10px;
		text-align: left;
		width: 95%;
		max-width: 400px;
		margin: 0 auto;
		word-wrap: break-word;

		.check {
			background-color: black;
			border-color: #fff;
			activeBackgroundColor: #fff;
			activeBorderColor: #fff;
			vertical-align: middle;
			/* 确保复选框垂直居中 */
		}

		label {
			font-size: 10px;
			align-items: center;
			line-height: 1.5;
			/* 调整文字行高 */
		}

		.agreement-link {
			color: #00ffff;
			text-decoration: none;
			cursor: pointer;
			word-break: break-word;
		}

		.agreement-link:hover {
			color: #ffcc00;
		}
	}
</style>
<template>
	<view>
		<hx-navbar title="个人信息" transparent="hidden"></hx-navbar>
		
		<text>
			热更新
		</text>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			}
		},
		methods: {
			
		}
	}
</script>

<style>

</style>

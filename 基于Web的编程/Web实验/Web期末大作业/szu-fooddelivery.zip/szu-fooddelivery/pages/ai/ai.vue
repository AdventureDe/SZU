<template>
	<view class="container">

		<!-- 头部盒子 -->
		<view class="header-box">
			<image src='@/static/img/xiaozhi-avator.png'></image>
			<text class="header-text">Szu 饭点小助手</text>
		</view>

		<!-- 聊天内容 -->
		<view class="chat-box" ref="chatBox">
			<view class="messages" v-for="(message, index) in messages" :key="index">
				<view :class="message.from === 'user' ? 'user-message-box' : 'ai-message-box'">
					<view :class="message.from === 'user' ? 'user-message' : 'ai-message'">
						{{ message.text }}
					</view>
				</view>
			</view>
		</view>

		<!-- 输入框 -->
		<view class="input-box">
			<textarea v-model="userInput" placeholder="输入你的问题..." @confirm="sendMessage" />
			<button @click="sendMessage">发送</button>
		</view>

	</view>
</template>

<script>
	import axios from 'axios';

	export default {
		data() {
			return {
				userInput: '',
				messages: []
			};
		},
		methods: {
			sendMessage() {
				if (this.userInput.trim()) {
					// 1. 添加用户消息
					this.messages.push({
						from: 'user',
						text: this.userInput
					});

					// 2. 清空输入框
					const userMessage = this.userInput;
					this.userInput = '';

					// 3. 调用后端获取AI回应
					this.getAIResponse(userMessage);
				}
			},
			async getAIResponse(userMessage) {
				try {
					const response = await this.fetchAIResponse(userMessage);

					// 4. 添加AI消息
					this.messages.push({
						from: 'ai',
						text: response.data.response
					});

					// 5. 自动滚动到底部
					this.scrollToBottom();
				} catch (error) {
					console.error('Error fetching AI response:', error);
				}
			},
			fetchAIResponse(userMessage) {
				// 向后端发送请求
				return axios.post('http://127.0.0.1:5000/api/ai-chat', {
					message: userMessage
				});
			},
			scrollToBottom() {
				// 等待 DOM 更新完后滚动到底部
				this.$nextTick(() => {
					const chatBox = this.$refs.chatBox;
					chatBox.scrollTop = chatBox.scrollHeight; // 滚动到聊天框的底部
				});
			}
		}
	};
</script>

<style lang="scss">
	/* 整体容器 */
	.container {
		padding: 20px;
		display: flex;
		flex-direction: column;
		height: 100vh;
		overflow: hidden;
		/* 确保不滚动整个页面 */
	}

	/* 头部盒子 */
	.header-box {
		position: fixed;
		top: 0;
		left: 0;
		right: 0;
		background-color: #ffffff;
		padding: 10px;
		text-align: center;
		z-index: 10;
		border-radius: 0 0 20px 20px;
		box-shadow: 0px 2px 5px rgba(0, 0, 0, 0.1);
		display: flex;
		align-items: center;
		/* 使图片和文本垂直居中对齐 */
		justify-content: center;
		/* 水平居中对齐 */
	}

	.header-box image {
		width: 30px;
		height: 30px;
		margin-right: 10px;
		/* 图片和文本之间的间距 */
	}

	.header-text {
		color: #990134;
		font-size: 20px;
		font-weight: bold;
	}


	.chat-box {
	  flex: 1;
	  margin-top:50px;
	  padding-bottom: 140rpx; /* 留出空间给固定在底部的输入框 */
	  overflow-y: auto;
	  display: flex;
	  flex-direction: column;
	}

	.messages {
		margin-bottom: 10px;
	}

	.user-message-box,
	.ai-message-box {
		margin-bottom: 10px;
		display: inline-block;
		width: 100%;
	}

	/* 用户消息样式 */
	.user-message {
		background-color: #d9f7be;
		padding: 10px;
		border-radius: 10px;
		margin: 5px 0;
		align-self: flex-end;
		/* 用户消息右对齐 */
		max-width: 80%;
		word-wrap: break-word;
		/* 自动换行 */
		word-break: break-word;
		/* 自动换行 */
		box-shadow: 0px 2px 5px rgba(0, 0, 0, 0.1);
	}

	/* AI 消息样式 */
	.ai-message {
		background-color: #f0f0f0;
		align-self: flex-start;
		/* AI 消息左对齐 */
		max-width: 80%;
		padding: 10px;
		border-radius: 10px;
		margin: 5px 0;
		word-wrap: break-word;
		word-break: break-word;
		box-shadow: 0px 2px 5px rgba(0, 0, 0, 0.1);
	}

	.input-box {
	  position: fixed; /* 固定在屏幕上 */
	  bottom: 50px; /* 固定在屏幕底部 */
	  left: 0;
	  width: 100%; /* 让输入框占据屏幕宽度 */
	  height: 120rpx; /* 控制输入框的高度 */
	  display: flex;
	  align-items: center; /* 垂直居中对齐 */
	  justify-content: space-between; /* 在水平上分配空间 */
	  background-color: white;
	  border-radius: 4px;
	  box-shadow: 0px -2px 5px rgba(0, 0, 0, 0.1);
	  padding: 5px;
	  z-index: 10; /* 确保输入框在页面最上层 */
	}
	
	textarea {
	  width: 80%; /* 让输入框占据大部分空间 */
	  height: 100%;
	  padding: 10px;
	  border: 1px solid #ccc;
	  border-radius: 4px;
	  font-size: 16px;
	  resize: none; /* 禁用手动调整大小 */
	  overflow-y: auto;
	  margin-right: 10px;
	}
	
	button {
	  width: 80px; /* 设置按钮的宽度 */
	  height: 100%;
	  background-color: #4CAF50;
	  color: white;
	  border: none;
	  border-radius: 10px;
	  font-size: 16px;
	  text-align: center;
	  display: flex;
	  justify-content: center;
	  align-items: center;
	}
</style>
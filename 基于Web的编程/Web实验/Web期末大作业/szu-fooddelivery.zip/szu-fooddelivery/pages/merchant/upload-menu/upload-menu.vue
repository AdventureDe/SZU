<template>
  <view class="container">
    <text class="title">上传文件到 IPFS</text>
    
    <view class="upload-section">
      <input type="file" @change="onFileChange" />
      <button @click="uploadToIPFS" :disabled="!file">上传文件</button>
    </view>
    
    <view v-if="cid">
      <text>文件已上传，CID: {{ cid }}</text>
      <button @click="getFromIPFS">获取文件</button>
    </view>

    <view v-if="fileContent">
      <text>文件内容:</text>
      <text>{{ fileContent }}</text>
    </view>
  </view>
</template>

<script>
import CryptoJS from 'crypto-js';  // 引入 crypto-js


export default {
  data() {
    return {
      file: null,            // 上传的文件
      cid: null,             // 上传后返回的 CID
      fileContent: null,     // 从 IPFS 获取的文件内容
    };
  },
  methods: {
    // 初始化 IPFS 客户端
    ipfsClient() {
      return create({ url: 'https://ipfs.infura.io:5001/api/v0' });  // 使用 Infura 公共 IPFS 节点
    },
    
    // 文件选择处理
    onFileChange(event) {
      const file = event.target.files[0];
      if (file) {
        this.file = file;
      }
    },

    // 上传文件到 IPFS
    async uploadToIPFS() {
      if (!this.file) {
        return;
      }

      const client = this.ipfsClient();
      const reader = new FileReader();
      reader.onloadend = async () => {
        const buffer = Buffer.from(reader.result);
        try {
          const result = await client.add(buffer);
          this.cid = result.path;  // 保存返回的 CID
        } catch (error) {
          console.error('文件上传失败:', error);
        }
      };
      reader.readAsArrayBuffer(this.file);
    },

    // 从 IPFS 获取文件
    async getFromIPFS() {
      if (!this.cid) {
        return;
      }

      const client = this.ipfsClient();
      try {
        const file = await client.cat(this.cid);
        const text = new TextDecoder().decode(file);  // 假设文件是文本格式
        this.fileContent = text;
      } catch (error) {
        console.error('获取文件失败:', error);
      }
    },
  },
};
</script>

<style scoped>
.container {
  padding: 20px;
}

.upload-section {
  margin-bottom: 20px;
}

button {
  margin-top: 10px;
  padding: 10px;
}

text {
  display: block;
  margin-top: 10px;
}

pre {
  background-color: #f4f4f4;
  padding: 10px;
}
</style>

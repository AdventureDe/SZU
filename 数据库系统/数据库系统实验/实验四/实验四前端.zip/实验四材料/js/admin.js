// 获取用户 ID
const user_id = sessionStorage.getItem('userId');

// 下架商品
function removeProduct(productId) {
    // 发送请求到后端，通知后端下架该商品
    fetch(`http://localhost:5000/api/admin_product/${productId}`, {
        method: 'DELETE',
        headers: {
            'Content-Type': 'application/json'
        }
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert('商品已下架');
            // 从页面中移除该商品项
            const productItem = document.querySelector(`.product-item[data-product-id="${productId}"]`);
            if (productItem) {
                productItem.remove();  // 删除商品项
            }
        } else {
            alert('下架商品失败');
        }
    })
    .catch(error => {
        console.error('Error removing product:', error);
        alert('下架商品失败');
    });
}

// 加载商品并添加事件监听器
fetch('http://localhost:5000/api/admin_product')
.then(response => response.json())
.then(products => {
    const productList = document.querySelector('.product-list');
    productList.innerHTML = '';

    products.forEach(product => {
        const productItem = document.createElement('div');
        productItem.classList.add('product-item');
        productItem.innerHTML = `
            <img src="${product.image_url}" alt="${product.product_name}">
            <p class="name">${product.product_name}</p>
            <p class="category">类别：${product.category}</p>
            <p class="description">描述：${product.product_description}</p>
            <p class="place">产地：${product.origin}</p>
            <p class="price">¥${product.price}</p>
            <p class="date">销售期：${product.sales_period}</p>
            <button class="remove-from-cart">下架商品</button> <!-- 新增下架商品按钮 -->
        `;
        productList.appendChild(productItem);

        // 为“下架商品”按钮绑定事件
        const removeFromCartButton = productItem.querySelector('.remove-from-cart');
        removeFromCartButton.addEventListener('click', () => {
            removeProduct(product.product_id);  // 调用下架商品函数
            console.log("商品已下架");
        });
    });
})
.catch(error => console.error('加载商品数据失败', error));

// 显示通知的函数
function showNotification(message) {
    const notification = document.createElement('div');
    notification.className = 'notification';
    notification.innerText = message;
    document.body.appendChild(notification);

    setTimeout(() => {
        notification.remove();
    }, 3000);
}

//搜索栏
document.querySelector('.search-box').addEventListener('input', (event) => {
    console.log(`当前输入内容：${event.target.value}`);
});

function showNotification(message) {
    // 创建通知元素
    const notification = document.createElement('div');
    notification.className = 'notification';
    notification.textContent = message;

    // 将通知添加到页面
    document.body.appendChild(notification);

    // 自动移除通知
    setTimeout(() => {
      notification.remove();
    }, 3000); // 3秒后移除
}

// 获取用户 ID
const user_id = parseInt(sessionStorage.getItem("userId") || "0", 10); 

// 添加商品到购物车
function addToCart(product) {
    if (!user_id) {
        alert('请先登录！');
        error.log(user_id);
        return;
    }
    const quantity = 1;  // 默认数量为 1

    // 创建要发送到后端的数据
    const cartData = {
        user_id: parseInt(user_id),  // 从 sessionStorage 获取 user_id
        product_id: parseInt(product.product_id),
        quantity: quantity
    };
    console.log(cartData);
    // 调用后端 API，使用 fetch 发送数据
    fetch('http://localhost:5000/api/cart', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(cartData)
    })
    .then(response => {
        if (response.status === 204) {
            showNotification('商品已加入购物车！');  // 提示用户商品已加入购物车
        } else if (response.status === 401) {
            
            alert('请先登录！');  // 用户未登录
        } else if (response.status === 404) {
            alert('商品未找到！');  // 商品不存在
        } else {
            alert('添加商品到购物车失败，请稍后再试');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('添加商品到购物车失败，请稍后再试');
    });
}


// 显示通知的函数
function showNotification(message) {
    const notification = document.createElement('div');
    notification.className = 'notification';
    notification.innerText = message;
    document.body.appendChild(notification);

    setTimeout(() => {
        notification.remove();
    }, 3000);
}


// 加载商品并添加事件监听器
fetch('http://localhost:5000/api/shouye_products')
.then(response => response.json())
.then(products => {
    const productList = document.querySelector('.product-list');
    productList.innerHTML = '';

    products.forEach(product => {
        const productItem = document.createElement('div');
        productItem.classList.add('product-item');
        productItem.innerHTML = `
            <img src="${product.image_url}" alt="${product.product_name}">
            <p class="name">${product.product_name}</p>
            <p class="category">类别：${product.category}</p>
            <p class="description">描述：${product.product_description}</p>
            <p class="place">产地：${product.origin}</p>
            <p class="price">¥${product.price}</p>
            <p class="date">销售期：${product.sales_period}</p>
            <i class="far fa-star" onclick="toggleFavorite(this)"></i>
            <button class="add-to-cart">加入购物车</button>
        `;
        productList.appendChild(productItem);
        // 为新商品的“加入购物车”按钮绑定事件
        const addToCartButton = productItem.querySelector('.add-to-cart');
        addToCartButton.addEventListener('click', () => {
            addToCart(product);
            console.log("已经添加");
        });
    });
})
.catch(error => console.error('加载商品数据失败', error));

// 收藏功能（示例）
function toggleFavorite(starElement) {
if (starElement.classList.contains('fas')) {
    starElement.classList.remove('fas');
    starElement.classList.add('far');
} else {
    starElement.classList.remove('far');
    starElement.classList.add('fas');
}
}

//搜索栏
document.querySelector('.search-box').addEventListener('input', (event) => {
    console.log(`当前输入内容：${event.target.value}`);
});

function toggleFavorite(icon) {
    // 切换填充状态
    icon.classList.toggle('filled');
    // 改变图标样式
    if (icon.classList.contains('filled')) {
      icon.classList.remove('far');
      icon.classList.add('fas');
      showNotification('已收藏！');
    } else {
      icon.classList.remove('fas');
      icon.classList.add('far');
      showNotification('已取消收藏！');
    }
}
function showNotification(message) {
    // 创建通知元素
    const notification = document.createElement('div');
    notification.className = 'notification';
    notification.textContent = message;

    // 将通知添加到页面
    document.body.appendChild(notification);

    // 自动移除通知
    setTimeout(() => {
      notification.remove();
    }, 3000); // 3秒后移除
}

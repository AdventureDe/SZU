package shapes;

import java.awt.*;
import java.awt.geom.Ellipse2D;
import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;
public class EllipseShape extends ShapeBase {
	
    public EllipseShape(int x, int y, int w, int h) {
        super(x, y, w, h);
    }
    @Override
    public void draw(Graphics2D g2d) {
        Graphics2D g = (Graphics2D) g2d.create();
        g.setStroke(strokeType);
        g.setColor(strokeColor);
        // 角度转弧度
        double radian = Math.toRadians(rotationAngle);
        g.rotate(radian, x + width / 2.0, y + height / 2.0);
        g.drawOval(x, y, width, height);
        if (fillColor != null) {
            g.setColor(fillColor);
            g.fillOval(x, y, width, height);
        }

        if (selected) {
            g.setColor(Color.BLUE);
            for (Point p : getControlPoints()) {
                g.fillRect(p.x - 3, p.y - 3, 6, 6);
            }
        }
        g.dispose();
    }
    @Override
    public boolean contains(Point p) {
        Ellipse2D ellipse = new Ellipse2D.Double(x, y, width, height);
        return ellipse.contains(p);
    }
    @Override
    public List<Point> getControlPoints() {
        List<Point> points = new ArrayList<>();
        int centerX = x + width / 2;
        int centerY = y + height / 2;
        // 添加水平和垂直方向的两个对称顶点
        points.add(new Point(centerX - width / 2, centerY)); // 左端（水平轴）
        points.add(new Point(centerX + width / 2, centerY)); // 右端（水平轴）
        points.add(new Point(centerX, centerY - height / 2)); // 上端（垂直轴）
        points.add(new Point(centerX, centerY + height / 2)); // 下端（垂直轴）
        return points;
    }
    @Override
    public void updateFromControlPoints(List<Point> controlPoints, 
    		boolean keepAspectRatio, boolean isBigger, int draggingIndex) {
        if (controlPoints.size() != 4) return;
        Point left = controlPoints.get(0); Point right = controlPoints.get(1);
        Point top = controlPoints.get(2);Point bottom = controlPoints.get(3);
        int newWidth = Math.abs(right.x - left.x);
        int newHeight = Math.abs(bottom.y - top.y);
        if (keepAspectRatio && originalAspectRatio > 0) {
            double ratio = originalAspectRatio;
            if (isBigger) {
                if (newWidth < newHeight * ratio) 
                    newWidth = (int) (newHeight * ratio);
                 else 
                    newHeight = (int) (newWidth / ratio);
            } else {
                if (newWidth > newHeight * ratio) 
                    newWidth = (int) (newHeight * ratio);
                else 
                    newHeight = (int) (newWidth / ratio);  }  }
        if (draggingIndex == 1) { // 右边点，固定左边
            this.x = left.x;
            this.y = (top.y + bottom.y) / 2 - newHeight / 2;
            this.width = newWidth;
            this.height = newHeight;
        } else if (draggingIndex == 3) { // 下边点，固定上边
            this.x = (left.x + right.x) / 2 - newWidth / 2;
            this.y = top.y;
            this.width = newWidth;
            this.height = newHeight;
        } else {
            int centerX = (left.x + right.x) / 2; // fallback: 居中（你原来的逻辑）
            int centerY = (top.y + bottom.y) / 2;
            this.x = centerX - newWidth / 2;
            this.y = centerY - newHeight / 2;
            this.width = newWidth;
            this.height = newHeight;
        }
    }
    @Override
    public ShapeBase clone() {
        EllipseShape copy = new EllipseShape(x, y, width, height);
        copy.strokeColor = this.strokeColor;
        copy.fillColor = this.fillColor;
        copy.strokeType = this.strokeType;
        copy.rotationAngle = this.rotationAngle;
        copy.originalAspectRatio = this.originalAspectRatio;
        copy.setSelected(this.isSelected());
        return copy;
    }
    //----------  保存  -------------------
    @Override
    public JSONObject toJSON() {
        JSONObject obj = new JSONObject();
        obj.put("type", "Ellipse");
        obj.put("x", x);
        obj.put("y", y);
        obj.put("width", width);
        obj.put("height", height);
        obj.put("strokeColor", strokeColor.getRGB());
        obj.put("fillColor", fillColor == null ? -1 : fillColor.getRGB());
        obj.put("rotation", rotationAngle);
        JSONObject strokeObj = new JSONObject();
        strokeObj.put("width", strokeType.getLineWidth());
        strokeObj.put("cap", strokeType.getEndCap());
        strokeObj.put("join", strokeType.getLineJoin());
        strokeObj.put("miterlimit", strokeType.getMiterLimit());
        strokeObj.put("dash", strokeType.getDashArray() != null ? new JSONArray(strokeType.getDashArray()) : JSONObject.NULL);
        strokeObj.put("dash_phase", strokeType.getDashPhase());
        obj.put("strokeType", strokeObj);

        return obj;
    }

    public static EllipseShape fromJSON(JSONObject obj) {
        EllipseShape shape = new EllipseShape(
            obj.getInt("x"),
            obj.getInt("y"),
            obj.getInt("width"),
            obj.getInt("height")
        );
        shape.setStrokeColor(new Color(obj.getInt("strokeColor")));
        int fill = obj.getInt("fillColor");
        if (fill != -1) shape.setFillColor(new Color(fill));
        shape.setRotationAngle(obj.optDouble("rotation", 0));
        shape.setStrokeColor(new Color(obj.getInt("strokeColor")));
        if (obj.has("strokeType")) {
            JSONObject strokeObj = obj.getJSONObject("strokeType");
            float width = (float) strokeObj.getDouble("width");
            int cap = strokeObj.getInt("cap");
            int join = strokeObj.getInt("join");
            float miterlimit = (float) strokeObj.getDouble("miterlimit");
            float dash_phase = (float) strokeObj.getDouble("dash_phase");

            BasicStroke stroke;
            if (strokeObj.has("dash") && !strokeObj.isNull("dash")) {
                JSONArray dashArray = strokeObj.getJSONArray("dash");
                float[] dash = new float[dashArray.length()];
                for (int i = 0; i < dash.length; i++) {
                    dash[i] = (float) dashArray.getDouble(i);
                }
                stroke = new BasicStroke(width, cap, join, miterlimit, dash, dash_phase);
            } else {
                stroke = new BasicStroke(width, cap, join, miterlimit);
            }
            shape.setStrokeType(stroke);
        }
        return shape;
    }
    @Override
    public Rectangle getBounds() {
        // 返回当前椭圆的边界矩形
        return new Rectangle(x, y, width, height);
    }

}

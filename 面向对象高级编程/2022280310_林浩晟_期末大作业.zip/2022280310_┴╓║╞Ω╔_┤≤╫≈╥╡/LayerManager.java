package layer;

import java.awt.Graphics2D;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import shapes.ShapeBase;

public class LayerManager<T extends ShapeBase> {
    private List<Layer<T>> layers = new ArrayList<>();
    private Layer<T> selectedLayer;
    public void addLayer(Layer<T> layer) {
        layers.add(layer);
        selectedLayer = layer;
    }
    public void removeLayer(Layer<T> layer) {
        layers.remove(layer);
        if (selectedLayer == layer) {
            selectedLayer = layers.isEmpty() ? null : layers.get(layers.size() - 1);
        }
    }
    public void moveLayerUp(Layer<T> layer) {
        int idx = layers.indexOf(layer);
        if (idx >= 0 && idx < layers.size() - 1) {
            Collections.swap(layers, idx, idx + 1);
        }
    }
    public void moveLayerDown(Layer<T> layer) {
        int idx = layers.indexOf(layer);
        if (idx > 0) {
            Collections.swap(layers, idx, idx - 1);
        }
    }
    public void drawAll(Graphics2D g2d) {
        for (Layer<T> layer : layers) {
            layer.draw(g2d);
        }
    }
    public Layer<T> getSelectedLayer() {
        return selectedLayer;
    }
    public void setSelectedLayer(Layer<T> layer) {
        this.selectedLayer = layer;
    }
    public List<Layer<T>> getLayers() {
        return layers;
    }
}

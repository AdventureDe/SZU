package ui;

import shapes.*;
import state.AppState;
import layer.Layer;

import javax.swing.*;
import java.awt.*;
import java.util.List;

public class ToolPanel extends JPanel {
	/**
	 * 
	 */
	private static final long serialVersionUID = 7677784240035870743L;
	static JLabel modeLabel;  // 显示模式的标签
	public ToolPanel(AppState state, CanvasPanel canvas) {
	    setLayout(new BorderLayout());
	    // 创建标签来显示模式
	    modeLabel = new JLabel("绘画模式", SwingConstants.CENTER);
	    modeLabel.setFont(new Font("宋体", Font.BOLD, 16));
	    modeLabel.setBorder(BorderFactory.createCompoundBorder(
	        BorderFactory.createTitledBorder("模式显示"),
	        BorderFactory.createEmptyBorder(5, 10, 5, 10)
	    ));
	    modeLabel.setPreferredSize(new Dimension(0, 35)); // 设置高度
	    // 创建标签和分隔线的面板
	    JPanel topPanel = new JPanel();
	    topPanel.setLayout(new BorderLayout());
	    topPanel.add(modeLabel, BorderLayout.NORTH);
	    topPanel.add(new JSeparator(JSeparator.HORIZONTAL), BorderLayout.SOUTH);
	    // 添加到 ToolPanel 顶部
	    add(topPanel, BorderLayout.NORTH);
	    // 中部为 tab
	    JTabbedPane tabbedPane = new JTabbedPane();
	    tabbedPane.addTab("图形", createShapeTab(state));
	    tabbedPane.addTab("样式", createStyleTab(state, canvas));
	    tabbedPane.addTab("操作", createTransformTab(state, canvas));
	    add(tabbedPane, BorderLayout.CENTER);
	}
    // -------- 图形工具 Tab --------
    private JPanel createShapeTab(AppState state) {
        JPanel shapePanel = new JPanel();
        shapePanel.setLayout(new FlowLayout(FlowLayout.LEFT, 2, 2));
       // shapePanel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 30));
        shapePanel.setBorder(BorderFactory.createTitledBorder("图形类型"));
        JButton rectBtn = new JButton("矩形");
        JButton ellipseBtn = new JButton("椭圆");
        JButton lineBtn = new JButton("直线");
        JButton freehandBtn = new JButton("自由图形");
        JButton polygonBtn = new JButton("多边形");
        rectBtn.addActionListener(e -> state.setCurrentShapeType(ShapeType.RECTANGLE));
        ellipseBtn.addActionListener(e -> state.setCurrentShapeType(ShapeType.ELLIPSE));
        lineBtn.addActionListener(e -> state.setCurrentShapeType(ShapeType.LINE));
        freehandBtn.addActionListener(e -> state.setCurrentShapeType(ShapeType.FREEHAND));
        polygonBtn.addActionListener(e -> state.setCurrentShapeType(ShapeType.POLYGON));
        shapePanel.add(rectBtn);
        shapePanel.add(ellipseBtn);
        shapePanel.add(lineBtn);
        shapePanel.add(freehandBtn);
        shapePanel.add(polygonBtn);
        return shapePanel;
    }

    // -------- 样式 Tab --------
    private JPanel createStyleTab(AppState state, CanvasPanel canvas) {
        JPanel stylePanel = new JPanel();
        stylePanel.setLayout(new BoxLayout(stylePanel, BoxLayout.Y_AXIS));

        // === 创建一行两列容器 ===
        JPanel rowPanel = new JPanel(new GridLayout(1, 2, 5, 0)); // 横向两个 panel

        // --- 线条样式 ---
        JPanel strokePanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 2, 2));
        strokePanel.setBorder(BorderFactory.createTitledBorder("线条样式"));

        JButton colorButton = new JButton("线条颜色");
        colorButton.addActionListener(e -> {
            Color selectedColor = JColorChooser.showDialog(null, "选择线条颜色", state.getStrokeColor());
            if (selectedColor != null) {
                state.setStrokeColor(selectedColor);
                applyToSelectedShapes(canvas, shape -> shape.setStrokeColor(selectedColor));
                canvas.repaint();
            }
        });

        JSlider widthSlider = new JSlider(1, 10, state.getStrokeWidth());
        widthSlider.setPreferredSize(new Dimension(100, 40)); // 缩小尺寸
        widthSlider.setMajorTickSpacing(1);
        widthSlider.setPaintTicks(true);
        widthSlider.setPaintLabels(true);
        widthSlider.addChangeListener(e -> {
            int width = widthSlider.getValue();
            state.setStrokeWidth(width);
            applyToSelectedShapes(canvas, shape -> shape.setStrokeType(state.getStroke()));
            canvas.repaint();
        });

        String[] lineStyles = {"实线", "虚线"};
        JComboBox<String> lineTypeComboBox = new JComboBox<>(lineStyles);
        lineTypeComboBox.addActionListener(e -> {
            boolean dashed = "虚线".equals(lineTypeComboBox.getSelectedItem());
            state.setDashed(dashed);
            applyToSelectedShapes(canvas, shape -> shape.setStrokeType(state.getStroke()));
            canvas.repaint();
        });

        strokePanel.add(colorButton);
        strokePanel.add(new JLabel("线宽:"));
        strokePanel.add(widthSlider);
        strokePanel.add(new JLabel("线型:"));
        strokePanel.add(lineTypeComboBox);

        // --- 填充样式 ---
        JPanel fillPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 2, 2));
        fillPanel.setBorder(BorderFactory.createTitledBorder("填充颜色"));

        JButton fillColorBtn = new JButton("选择填充色");
        fillColorBtn.addActionListener(e -> {
            Color selectedColor = JColorChooser.showDialog(null, "选择填充颜色", state.getFillColor());
            if (selectedColor != null) {
                state.setFillColor(selectedColor);
                applyToSelectedShapes(canvas, shape -> shape.setFillColor(selectedColor));
                canvas.repaint();
            }
        });

        JButton noFillBtn = new JButton("无填充");
        noFillBtn.addActionListener(e -> {
            state.setFillColor(null);
            applyToSelectedShapes(canvas, shape -> shape.setFillColor(null));
            canvas.repaint();
        });

        fillPanel.add(fillColorBtn);
        fillPanel.add(noFillBtn);

        // 添加到一行中
        rowPanel.add(strokePanel);
        rowPanel.add(fillPanel);

        // 添加整行到主样式 panel
        stylePanel.add(rowPanel);

        return stylePanel;
    }

    // -------- 操作 Tab（旋转和对齐） --------
    private JPanel createTransformTab(AppState state, CanvasPanel canvas) {
        JPanel transformPanel = new JPanel();
        transformPanel.setLayout(new BoxLayout(transformPanel, BoxLayout.Y_AXIS));

        // 创建横向排列的容器
        JPanel rowPanel = new JPanel(new GridLayout(1, 2, 5, 0));

        // --- 旋转 ---
        JPanel rotatePanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 2, 2));
        rotatePanel.setBorder(BorderFactory.createTitledBorder("旋转"));

        JSlider rotateSlider = new JSlider(0, 360, 0);
        rotateSlider.setMajorTickSpacing(90);
        rotateSlider.setMinorTickSpacing(15);
        rotateSlider.setPaintTicks(true);
        rotateSlider.setPaintLabels(true);
        rotateSlider.setPreferredSize(new Dimension(140, 50)); // 缩小尺寸
        rotateSlider.addChangeListener(e -> {
            int angle = rotateSlider.getValue();
            state.setRotationAngle(angle);
            applyToSelectedShapes(canvas, shape -> shape.setRotationAngle(angle));
            canvas.repaint();
        });

        rotatePanel.add(rotateSlider);
        // --- 对齐 ---
        JPanel alignPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 2, 2));
        alignPanel.setBorder(BorderFactory.createTitledBorder("对齐"));

        JPanel alignGrid = new JPanel(new GridLayout(1, 6, 5, 5));
        String[] alignments = {"上对齐", "中对齐", "下对齐", "左对齐", "水平居中", "右对齐"};
        String[] keys = {"top", "middle", "bottom", "left", "center", "right"};

        for (int i = 0; i < alignments.length; i++) {
            String label = alignments[i];
            String key = keys[i];
            JButton btn = new JButton(label);
            btn.setMargin(new Insets(2, 4, 2, 4)); // 更紧凑的按钮
            btn.addActionListener(e -> canvas.alignShapes(CanvasPanel.sShape, key));
            alignGrid.add(btn);
        }

        alignPanel.add(alignGrid);

        // 添加到一行两列容器
        rowPanel.add(rotatePanel);
        rowPanel.add(alignPanel);

        // 添加到主面板
        transformPanel.add(rowPanel);

        return transformPanel;
    }

    // -------- 通用工具函数：对选中图形应用操作 --------
    private void applyToSelectedShapes(CanvasPanel canvas, java.util.function.Consumer<ShapeBase> consumer) {
        List<Layer<ShapeBase>> layers = canvas.getLayers();
        for (Layer<ShapeBase> layer : layers) {
            for (ShapeBase shape : layer.getShapes()) {
                if (shape.isSelected()) {
                    consumer.accept(shape);
                }
            }
        }
    }
}

package ui;

import shapes.*;
import state.*;
import javax.swing.*;
import layer.Layer;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.List;
public class CanvasPanel extends JPanel {
    /**
	 * 
	 */
	private static final long serialVersionUID = 3876814763983640958L;
    private ShapeBase currentShape = null;
    private Point startPoint;
    private FreehandShape freehandShape = null;
    private PolygonShape currentPolygon = null;
    private Point previewEnd = null;
    private List<ShapeBase> clipboard = new ArrayList<>();//用于作为剪切板
    private boolean multiSelectMode = false;
    private boolean isDraggingExistingShape = false;
    private ShapeBase selectedShape = null;
    private int draggingControlPointIndex = -1;
    List<Layer<ShapeBase>> layers = new ArrayList<>();
    private int currentLayerIndex = 0;
    static List<ShapeBase> sShape=new ArrayList<ShapeBase>();
    private Point lastDragPoint = null;
    public CanvasPanel() {
        setBackground(Color.WHITE);
        MouseAdapter mouseHandler = new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                AppState state = AppState.getInstance();
                startPoint = e.getPoint();
                Point clickPoint = e.getPoint();
                selectedShape = null;
                draggingControlPointIndex = -1;
                // 判断是否点击了已存在图形
                boolean found = false;
                //------------------------ 编辑模式 ----------------------------------
                if(state.getisEdit())
                {
                	//------------------- 选择拖动的点 ------------------
                	for (Layer<ShapeBase> layer : layers) {
                	    if (!layer.isVisible()) continue; // 跳过隐藏图层
                	    for (ShapeBase shape : layer.getShapes()) {
                	        if (shape.isSelected()) {
                	            List<Point> cps = shape.getControlPoints();
                	            for (int i = 0; i < cps.size(); i++) {
                	                Point cp = cps.get(i);
                	                if (cp.distance(clickPoint) <= 6) { // 容差范围
                	                    draggingControlPointIndex = i;
                	                    selectedShape = shape;
                	                    selectedShape.recordAspectRatio();//记录比例
                	                    return; // 命中后直接返回
                	                }
                	            }
                	        }
                	    }
                	}
                	multiSelectMode = e.isControlDown();
                	//------------------- 选择拖动的图形 ------------------
                	if (draggingControlPointIndex == -1) {
                	    // 遍历所有图层（从上到下，先绘制后检查）
                	    for (int layerIndex = layers.size() - 1; layerIndex >= 0; layerIndex--) {
                	        Layer<ShapeBase> layer = layers.get(layerIndex);
                	        if (!layer.isVisible()) 
								continue;
                	        for (int shapeIndex = layer.getShapes().size() - 1; shapeIndex >= 0; shapeIndex--) {
                	            ShapeBase shape = layer.getShapes().get(shapeIndex);
                	            if (shape.contains(startPoint)) {
                	                if (!multiSelectMode) {
                	                    // 清除所有图形的选中状态（所有图层）
                	                    for (Layer<ShapeBase> l : layers) {
                	                        for (ShapeBase s : l.getShapes()) {
                	                            s.setSelected(false);
                	                        }
                	                    }
                	                }
                	                isDraggingExistingShape = true;
                	                shape.setSelected(true);
                	                selectedShape = shape;
            	                    sShape.add(selectedShape);//添加选择的图形
            	                    selectedShape.recordAspectRatio();//记录比例
                	                found = true;
                	                return; // 找到后立即返回，不再继续找
                	            }
                	        }
                	    }
                	}
                }
                //------------------------- 绘画模式 -----------------------------------
                if(state.getisDraw())
                {
                	if (!getCurrentLayer().isVisible()) {
                	    return;  // 阻止绘图操作
                	}
	                // -------------  画图形  ------------------
	                if (state.getCurrentShapeType() == ShapeType.POLYGON) {
	                    Point clickPoint1 = e.getPoint();
	                    if (currentPolygon == null || currentPolygon.isCompleted()) {
	                        currentPolygon = new PolygonShape();
	                        currentPolygon.addPoint(clickPoint1);
	                        applyStyleToShape(currentPolygon);
	                        getCurrentLayer().add(currentPolygon);
	                        repaint();
	                        return;
	                    }
	                    if (e.getClickCount() == 2) {
	                        currentPolygon.completePolygon();
	                        currentPolygon = null;
	                        previewEnd = null;
	                    } else {
	                        currentPolygon.addPoint(clickPoint1);
	                        previewEnd = null;
	                    }
	                    applyStyleToShape(currentPolygon);
	                    repaint();
	                    return;
	                }
	
	                if (!found) {
	                    // 创建新图形
	                	 ShapeBase newShape = ShapeFactory.createShape(state.
	                			 getCurrentShapeType(), startPoint.x, startPoint.y);
	                     if (newShape != null) {
	                         applyStyleToShape(newShape);
	                         getCurrentLayer().add(newShape);

	                         if (newShape instanceof FreehandShape) {
	                             freehandShape = (FreehandShape) newShape;
	                         } else {
	                             currentShape = newShape;
	                         }
	                         repaint();
	                     }
	                }
                }
                repaint();
            }

            @SuppressWarnings("incomplete-switch")
			@Override
            public void mouseDragged(MouseEvent e) {
                AppState state = AppState.getInstance();
                if(state.getisEdit())
                {
                	 //------------------------- 编辑模式 -----------------------------------
                	// ------------------------  拖动点  --------------------------
                	if (selectedShape != null && draggingControlPointIndex != -1) {
                	    List<Point> cps = selectedShape.getControlPoints();
                	    Point newPoint = e.getPoint();
                	    if (selectedShape instanceof EllipseShape &&  // 跳过特殊情况
                	        (draggingControlPointIndex == 0 || draggingControlPointIndex == 2)) {
                	        return;
                	    }
                	    boolean isBigger = false;
                	    if (lastDragPoint != null && selectedShape instanceof EllipseShape) {
                	        int deltaX = newPoint.x - lastDragPoint.x;
                	        int deltaY = newPoint.y - lastDragPoint.y;
                	        if (draggingControlPointIndex == 1)  // 右边控制点
                	            isBigger = deltaX > 0; // 右拖是放大
                	        else if (draggingControlPointIndex == 3)  // 下边控制点
                	            isBigger = deltaY > 0; }// 下拖是放大  
                	    // 更新控制点位置
                	    cps.set(draggingControlPointIndex, newPoint);
                	    boolean isShiftDown = (e.getModifiersEx() & InputEvent.SHIFT_DOWN_MASK) != 0;
                	    if(selectedShape instanceof EllipseShape)
                	    	selectedShape.updateFromControlPoints(cps, isShiftDown,isBigger,
                	    			draggingControlPointIndex);
                	    else
                	    	selectedShape.updateFromControlPoints(cps, isShiftDown);
                	    repaint(); // 重绘图形
                	    lastDragPoint = newPoint; // 更新最后拖动点
                	    return;
                	}
                	// ------------------------  拖动图形  --------------------------
	                if (isDraggingExistingShape) {
	                    int dx = e.getX() - startPoint.x;
	                    int dy = e.getY() - startPoint.y;
	                    for (Layer<ShapeBase> layer : layers) {
	                        if (!layer.isVisible()) continue; // 跳过隐藏图层
	                        for (ShapeBase shape : layer.getShapes()) {
	                            if (shape.isSelected()) {
	                                shape.moveBy(dx, dy);
	                            }
	                        }
	                    }
	                    startPoint = e.getPoint();
	                    repaint();
	                    return;
	                }
                }
                if(state.getisDraw())
                {
                	 //------------------------- 绘画模式 -----------------------------------
	                if (state.getCurrentShapeType() == ShapeType.POLYGON && currentPolygon != null) {
	                    previewEnd = e.getPoint();
	                    repaint();
	                    return;
	                }
	                if (state.getCurrentShapeType() == ShapeType.FREEHAND && freehandShape != null) {
	                    freehandShape.addPoint(e.getX(), e.getY());
	                    repaint();
	                    return;
	                } 
	               if (currentShape != null) {
	                    int dx = e.getX() - startPoint.x;
	                    int dy = e.getY() - startPoint.y;
	                    boolean shiftDown = (e.getModifiersEx() & MouseEvent.SHIFT_DOWN_MASK) != 0;
	                    switch (state.getCurrentShapeType()) {
	                        case RECTANGLE:
	                        case ELLIPSE:
	                            if (shiftDown) {
	                                int size = Math.min(Math.abs(dx), Math.abs(dy));
	                                int width = dx < 0 ? -size : size;
	                                int height = dy < 0 ? -size : size;
	                                currentShape.setSize(width, height);
	                            } else 
	                                currentShape.setSize(dx, dy);
	                            break;
	                        case LINE:
	                            if (shiftDown) {
	                                int absDx = Math.abs(dx);
	                                int absDy = Math.abs(dy);
	                                if (absDx > absDy * 2) {
	                                    ((LineShape) currentShape).setEnd(startPoint.x + dx, startPoint.y);
	                                } else if (absDy > absDx * 2) {
	                                    ((LineShape) currentShape).setEnd(startPoint.x, startPoint.y + dy);
	                                } else {
	                                    int signX = dx >= 0 ? 1 : -1;
	                                    int signY = dy >= 0 ? 1 : -1;
	                                    int length = Math.min(absDx, absDy);
	                                    ((LineShape) currentShape).setEnd(startPoint.x 
	                                    		+ signX * length, startPoint.y + signY * length);
	                                }
	                            } else 
	                                ((LineShape) currentShape).setEnd(e.getX(), e.getY());
	                            break;
	                    }
	                }
                }
                repaint();
            }
            @Override
            public void mouseReleased(MouseEvent e) {
                AppState state = AppState.getInstance();
                lastDragPoint = null;
                if (state.getCurrentShapeType() == ShapeType.FREEHAND) {
                    freehandShape = null;
                } else {
                    currentShape = null;
                }
                isDraggingExistingShape = false;
            }
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2) {
                    for (Layer<ShapeBase> layer : layers) {
                        if (!layer.isVisible()) continue; // 跳过隐藏图层
                        for (ShapeBase shape : layer.getShapes()) {
                        	 shape.setSelected(false);
                        }
                    }
                    repaint();
                }
            }
        };
        addMouseListener(mouseHandler);
        addMouseMotionListener(mouseHandler);
        this.setFocusable(true);
        this.requestFocusInWindow();
        addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_DELETE) {
                    deleteSelectedShapes();
                }
            }
        });
        // 鼠标点击后自动获取焦点，才能用键盘操作
        addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                requestFocusInWindow();
            }
        });
        addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.isControlDown() && e.getKeyCode() == KeyEvent.VK_C) {// Ctrl+C - 复制
                    clipboard.clear();
                    for (Layer<ShapeBase> layer : layers) {
                        if (!layer.isVisible()) continue; // 跳过隐藏图层
                        for (ShapeBase shape : layer.getShapes()) 
                        	 if (shape.isSelected()) 
                                 clipboard.add(shape.clone()); // clone() 你需要在 ShapeBase 中实现
                    }
                }
                if (e.isControlDown() && e.getKeyCode() == KeyEvent.VK_V) { // Ctrl+V - 粘贴
                    for (ShapeBase shape : clipboard) {
                        ShapeBase copiedShape = shape.clone(); // 克隆
                        copiedShape.offset(10, 10);            // 偏移以示“粘贴”
                        copiedShape.setSelected(true);
                        getCurrentLayer().add(copiedShape);
                    }
                    repaint();
                }
            }
        });

    }
    public Layer<ShapeBase> getCurrentLayer() {
        return layers.get(currentLayerIndex);
    }

    public void createNewLayer(String name) {
        Layer<ShapeBase> layer = new Layer<>(name);
        layers.add(layer);
        currentLayerIndex = layers.size() - 1;
    }
    /** 给图形应用当前画笔样式 **/
    private void applyStyleToShape(ShapeBase shape) {
        AppState state = AppState.getInstance();
        if (shape == null) return;
        shape.setStrokeColor(state.getStrokeColor());
        shape.setStrokeType(state.getStroke()); // 让 Shape 从 AppState 获取 BasicStroke
        shape.setFillColor(state.getFillColor());
    }
    //推荐方式
    public void deleteSelectedShapes() {
        Layer<ShapeBase> currentLayer = getCurrentLayer();
        currentLayer.getShapes().removeIf(ShapeBase::isSelected);
        repaint();
    }
    public List<Layer<ShapeBase>> getLayers() {
        return layers;
    }
    public void setLayers(List<Layer<ShapeBase>> newLayers) {
        this.layers = newLayers;
        this.currentLayerIndex = 0;
        // 让主界面刷新 JList 图层列表（比如通过回调或引用）
        if (LayerPanel.listModel != null) {
        	LayerPanel.listModel.clear();
            for (Layer<ShapeBase> layer : layers) {
            	LayerPanel.listModel.addElement(layer);
            }
        }
        repaint();
    }
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;
        // 遍历所有图层并绘制其中的图形（顺序很重要）
        for (Layer<ShapeBase> layer : layers) {
            if (layer.isVisible()) {
                layer.draw(g2d);  // 每个图层自己绘制它的所有图形
            }
        }
        // 多边形绘制中的预览线段（只在绘制时显示在顶层）
        if (AppState.getInstance().getCurrentShapeType() == ShapeType.POLYGON
                && currentPolygon != null && previewEnd != null) {
            g2d.setColor(Color.GRAY);
            Point last = currentPolygon.getLastPoint();
            g2d.drawLine(last.x, last.y, previewEnd.x, previewEnd.y);
        }
    }
	public void setCurrentLayerIndex(int index) {
		currentLayerIndex=index;
	}
	public void alignShapes(List<ShapeBase> selectedShapes, String alignment) {
	    Rectangle boundingBox = getBoundingBox(selectedShapes);
	    int offsetX = 0;int offsetY = 0;
	    // 计算目标位置（这里以画布中心为对齐基准）
	    for (ShapeBase shape : selectedShapes) {
	        Rectangle bounds = shape.getBounds();
	        switch (alignment) {
	            case "top":
	                offsetY = boundingBox.y - bounds.y;
	                break;
	            case "middle":
	                offsetY = boundingBox.y + boundingBox.height / 2 - bounds.y - bounds.height / 2;
	                break;
	            case "bottom":
	                offsetY = boundingBox.y + boundingBox.height - bounds.y - bounds.height;
	                break;
	            case "left":
	                offsetX = boundingBox.x - bounds.x;
	                break;
	            case "center":
	                offsetX = boundingBox.x + boundingBox.width / 2 - bounds.x - bounds.width / 2;
	                break;
	            case "right":
	                offsetX = boundingBox.x + boundingBox.width - bounds.x - bounds.width;
	                break;
	        }
	        shape.moveBy(offsetX, offsetY); // 移动元素
	    }
	    repaint(); // 刷新画布
	}
	// 获取选中元素的边界框
	public Rectangle getBoundingBox(List<ShapeBase> selectedShapes) {
	    int minX = Integer.MAX_VALUE;
	    int minY = Integer.MAX_VALUE;
	    int maxX = Integer.MIN_VALUE;
	    int maxY = Integer.MIN_VALUE;
	    for (ShapeBase shape : selectedShapes) {
	        Rectangle bounds = shape.getBounds(); // 假设 getBounds() 获取元素的矩形区域
	        minX = Math.min(minX, bounds.x);
	        minY = Math.min(minY, bounds.y);
	        maxX = Math.max(maxX, bounds.x + bounds.width);
	        maxY = Math.max(maxY, bounds.y + bounds.height);
	    }
	    return new Rectangle(minX, minY, maxX - minX, maxY - minY);
	}
}

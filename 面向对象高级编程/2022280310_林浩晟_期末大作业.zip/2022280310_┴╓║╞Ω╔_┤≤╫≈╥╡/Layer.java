package layer;

import java.awt.Graphics2D;
import java.util.ArrayList;
import java.util.List;

import shapes.ShapeBase;

public class Layer<T extends ShapeBase> {
    private List<T> shapes = new ArrayList<>();
    private boolean visible = true;
    private String name;
    public Layer(String name) {
        this.name = name;
    }
    public void add(T shape) {
        shapes.add(shape);
    }
    public void remove(T shape) {
        shapes.remove(shape);
    }
    public List<T> getShapes() {
        return shapes;
    }
    public boolean isVisible() {
        return visible;
    }
    public void setVisible(boolean visible) {
        this.visible = visible;
    }
    public String getName() {
        return name;
    }
	  public void clearShapes() {
		shapes.clear();
	}
    public void draw(Graphics2D g2d) {
        if (!visible) return;
        for (T shape : shapes) {
            shape.draw(g2d);
        }
    }
	public void setName(String newName) {
		name = newName;
	}
}

package shapes;

import java.awt.*;
import java.awt.geom.AffineTransform;
import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;

public class FreehandShape extends ShapeBase {

    private ArrayList<Point> points = new ArrayList<>();

    public FreehandShape(int startX, int startY) {
        super(startX, startY, 0, 0);
        points.add(new Point(startX, startY));
    }

    public void addPoint(int x, int y) {
        points.add(new Point(x, y));
    }
    @Override
    public void draw(Graphics2D g2d) {
        g2d.setColor(strokeColor); g2d.setStroke(strokeType);
        int minX = Integer.MAX_VALUE, minY = Integer.MAX_VALUE; // 计算外接矩形（用于旋转中心点）
        int maxX = Integer.MIN_VALUE, maxY = Integer.MIN_VALUE;
        for (Point p : points) {
            minX = Math.min(minX, p.x);
            minY = Math.min(minY, p.y);
            maxX = Math.max(maxX, p.x);
            maxY = Math.max(maxY, p.y); }
        double centerX = (minX + maxX) / 2.0;double centerY = (minY + maxY) / 2.0;
        AffineTransform oldTransform = g2d.getTransform();  // 旋转
        double rad = Math.toRadians(rotationAngle); // 假设 rotationAngle 已从父类继承
        g2d.rotate(rad, centerX, centerY);
        for (int i = 0; i < points.size() - 1; i++) {
            Point p1 = points.get(i);
            Point p2 = points.get(i + 1);
            g2d.drawLine(p1.x, p1.y, p2.x, p2.y);
        }
        g2d.setTransform(oldTransform);
        if (selected) {
            Stroke oldStroke = g2d.getStroke();
            g2d.setColor(Color.BLUE);
            g2d.setStroke(new BasicStroke(1, BasicStroke.CAP_BUTT, 
            		BasicStroke.JOIN_BEVEL, 0, new float[]{5}, 0));
            List<Point> controls = getControlPoints();
            int[] xPoints = new int[5];
            int[] yPoints = new int[5];
            for (int i = 0; i < 4; i++) {
                xPoints[i] = controls.get(i).x;
                yPoints[i] = controls.get(i).y;
            }
            xPoints[4] = controls.get(0).x; // 闭合图形
            yPoints[4] = controls.get(0).y;
            g2d.drawPolyline(xPoints, yPoints, 5);
            g2d.setStroke(oldStroke);
            for (Point p : getControlPoints())  // 控制点
                g2d.fillRect(p.x - 3, p.y - 3, 6, 6);
        }
    }

    @Override
    public void moveBy(int dx, int dy) {
        for (Point p : points) {
            p.translate(dx, dy);
        }
    }

    @Override
    public boolean contains(Point p) {
        final double THRESHOLD = 5.0; // 判定为“选中”的容差范围
        for (int i = 0; i < points.size() - 1; i++) {
            Point p1 = points.get(i);
            Point p2 = points.get(i + 1);
            if (pointToSegmentDistance(p1, p2, p) <= THRESHOLD) {
                return true;
            }
        }
        return false;
    }
    private double pointToSegmentDistance(Point p1, Point p2, Point p) {
        double x0 = p.x, y0 = p.y;
        double x1 = p1.x, y1 = p1.y;
        double x2 = p2.x, y2 = p2.y;

        double dx = x2 - x1;
        double dy = y2 - y1;

        if (dx == 0 && dy == 0) {
            // p1 和 p2 是同一个点
            return p.distance(p1);
        }

        double t = ((x0 - x1) * dx + (y0 - y1) * dy) / (dx * dx + dy * dy);
        t = Math.max(0, Math.min(1, t)); // 限制 t 在 [0,1] 范围内

        double projX = x1 + t * dx;
        double projY = y1 + t * dy;

        return Point.distance(x0, y0, projX, projY);
    }
    @Override
    public List<Point> getControlPoints() {
        if (points.isEmpty()) return new ArrayList<>();
        // 计算原始外接矩形（0度状态）
        int minX = Integer.MAX_VALUE, minY = Integer.MAX_VALUE;
        int maxX = Integer.MIN_VALUE, maxY = Integer.MIN_VALUE;
        for (Point p : points) {
            minX = Math.min(minX, p.x); minY = Math.min(minY, p.y);
            maxX = Math.max(maxX, p.x); maxY = Math.max(maxY, p.y);
        } // 使用原始外接矩形中心作为旋转中心
        double centerX = (minX + maxX) / 2.0; double centerY = (minY + maxY) / 2.0;
        double radians = Math.toRadians(rotationAngle);// 旋转四个角点
        List<Point> controls = new ArrayList<>();
        int[][] corners = {
            {minX, minY}, // 左上
            {maxX, minY}, // 右上
            {maxX, maxY}, // 右下
            {minX, maxY}  // 左下
        };
        for (int[] corner : corners) {
            double dx = corner[0] - centerX;
            double dy = corner[1] - centerY;
            int rotatedX = (int) (dx * Math.cos(radians) - dy * Math.sin(radians) + centerX);
            int rotatedY = (int) (dx * Math.sin(radians) + dy * Math.cos(radians) + centerY);
            controls.add(new Point(rotatedX, rotatedY));
        }
        return controls;
    }

    @Override
    public void updateFromControlPoints(List<Point> controlPoints, boolean keepAspectRatio) {
//        if (controlPoints.size() != 4 || points.isEmpty()) return;
//        // 1. 计算原始外接矩形（0度状态）
//        int oldMinX = Integer.MAX_VALUE, oldMinY = Integer.MAX_VALUE;
//        int oldMaxX = Integer.MIN_VALUE, oldMaxY = Integer.MIN_VALUE;
//        for (Point p : points) {
//            oldMinX = Math.min(oldMinX, p.x);
//            oldMinY = Math.min(oldMinY, p.y);
//            oldMaxX = Math.max(oldMaxX, p.x);
//            oldMaxY = Math.max(oldMaxY, p.y);
//        }
//        double oldCenterX = (oldMinX + oldMaxX) / 2.0;
//        double oldCenterY = (oldMinY + oldMaxY) / 2.0;
//        int oldWidth = oldMaxX - oldMinX;
//        int oldHeight = oldMaxY - oldMinY;
//        if (oldWidth == 0 || oldHeight == 0) return;
//        // 2. 将控制点反旋转回0度状态
//        double radians = Math.toRadians(-rotationAngle); // 负角度表示反旋转
//        double cos = Math.cos(radians);
//        double sin = Math.sin(radians);
//        List<Point> unrotatedControls = new ArrayList<>();
//        for (Point p : controlPoints) {
//            // 转换为相对中心坐标
//            double dx = p.x - oldCenterX;
//            double dy = p.y - oldCenterY;
//            
//            // 应用反旋转
//            int unrotatedX = (int)(dx * cos - dy * sin + oldCenterX);
//            int unrotatedY = (int)(dx * sin + dy * cos + oldCenterY);
//            unrotatedControls.add(new Point(unrotatedX, unrotatedY));
//        }
//        // 3. 计算反旋转后的边界
//        int newMinX = Integer.MAX_VALUE, newMinY = Integer.MAX_VALUE;
//        int newMaxX = Integer.MIN_VALUE, newMaxY = Integer.MIN_VALUE;
//        for (Point p : unrotatedControls) {
//            newMinX = Math.min(newMinX, p.x);
//            newMinY = Math.min(newMinY, p.y);
//            newMaxX = Math.max(newMaxX, p.x);
//            newMaxY = Math.max(newMaxY, p.y);
//        }
//        int newWidth = newMaxX - newMinX;
//        int newHeight = newMaxY - newMinY;
//        // 4. 计算缩放比例
//        double scaleX = newWidth / (double) oldWidth;
//        double scaleY = newHeight / (double) oldHeight;
//        // 5. 应用缩放变换
//        ArrayList<Point> newPoints = new ArrayList<>();
//        for (Point p : points) {
//            // 计算点在原矩形中的相对位置
//            double tx = (p.x - oldMinX) / (double) oldWidth;
//            double ty = (p.y - oldMinY) / (double) oldHeight;
//            // 映射到新矩形
//            int newX = (int)(newMinX + tx * newWidth);
//            int newY = (int)(newMinY + ty * newHeight);
//            newPoints.add(new Point(newX, newY));
//        }
//        points.clear();
//        points.addAll(newPoints);
    }
    @Override
    public ShapeBase clone() {
        // 用第一个点初始化副本（避免空指针）
        Point first = points.isEmpty() ? new Point(0, 0) : points.get(0);
        FreehandShape copy = new FreehandShape(first.x, first.y);
        // 复制所有点（跳过第一个已加）
        for (int i = 1; i < points.size(); i++) {
            Point p = points.get(i);
            copy.addPoint(p.x, p.y);
        }
        // 拷贝样式属性
        copy.strokeColor = this.strokeColor;
        copy.fillColor = this.fillColor;
        copy.strokeType = this.strokeType;
        copy.rotationAngle = this.rotationAngle;
        copy.setSelected(true);
        return copy;
    }
    @Override
    public JSONObject toJSON() {
        JSONObject obj = new JSONObject();
        obj.put("type", "Freehand");

        JSONArray pointArray = new JSONArray();
        for (Point p : points) {
            JSONObject pointObj = new JSONObject();
            pointObj.put("x", p.x);
            pointObj.put("y", p.y);
            pointArray.put(pointObj);
        }
        obj.put("rotation", rotationAngle);
        obj.put("points", pointArray);
        obj.put("strokeColor", strokeColor.getRGB());
        obj.put("fillColor", fillColor == null ? -1 : fillColor.getRGB());
        JSONObject strokeObj = new JSONObject();
        strokeObj.put("width", strokeType.getLineWidth());
        strokeObj.put("cap", strokeType.getEndCap());
        strokeObj.put("join", strokeType.getLineJoin());
        strokeObj.put("miterlimit", strokeType.getMiterLimit());
        strokeObj.put("dash", strokeType.getDashArray() != null ? new JSONArray(strokeType.getDashArray()) : JSONObject.NULL);
        strokeObj.put("dash_phase", strokeType.getDashPhase());
        obj.put("strokeType", strokeObj);
        return obj;
    }
    public static FreehandShape fromJSON(JSONObject obj) {
        JSONArray pointArray = obj.getJSONArray("points");
        if (pointArray.length() == 0) return null;

        JSONObject first = pointArray.getJSONObject(0);
        FreehandShape shape = new FreehandShape(first.getInt("x"), first.getInt("y"));

        for (int i = 1; i < pointArray.length(); i++) {
            JSONObject pointObj = pointArray.getJSONObject(i);
            shape.addPoint(pointObj.getInt("x"), pointObj.getInt("y"));
        }

        shape.setStrokeColor(new Color(obj.getInt("strokeColor")));
        int fill = obj.getInt("fillColor");
        if (fill != -1) shape.setFillColor(new Color(fill));
        if (obj.has("rotation")) {
            shape.rotationAngle = obj.getDouble("rotation");
        }
        if (obj.has("strokeType")) {
            JSONObject strokeObj = obj.getJSONObject("strokeType");
            float width = (float) strokeObj.getDouble("width");
            int cap = strokeObj.getInt("cap");
            int join = strokeObj.getInt("join");
            float miterlimit = (float) strokeObj.getDouble("miterlimit");
            float dash_phase = (float) strokeObj.getDouble("dash_phase");

            BasicStroke stroke;
            if (strokeObj.has("dash") && !strokeObj.isNull("dash")) {
                JSONArray dashArray = strokeObj.getJSONArray("dash");
                float[] dash = new float[dashArray.length()];
                for (int i = 0; i < dash.length; i++) {
                    dash[i] = (float) dashArray.getDouble(i);
                }
                stroke = new BasicStroke(width, cap, join, miterlimit, dash, dash_phase);
            } else {
                stroke = new BasicStroke(width, cap, join, miterlimit);
            }
            shape.setStrokeType(stroke);
        }
        return shape;
    }
    @Override
    public Rectangle getBounds() {
        if (points.isEmpty()) return new Rectangle(0, 0, 0, 0);
        // 计算旋转中心
        int minX = Integer.MAX_VALUE, minY = Integer.MAX_VALUE;
        int maxX = Integer.MIN_VALUE, maxY = Integer.MIN_VALUE;
        for (Point p : points) {
            minX = Math.min(minX, p.x);
            minY = Math.min(minY, p.y);
            maxX = Math.max(maxX, p.x);
            maxY = Math.max(maxY, p.y);
        }
        double centerX = (minX + maxX) / 2.0;
        double centerY = (minY + maxY) / 2.0;
        // 旋转每个点
        double radians = Math.toRadians(rotationAngle);
        int boundMinX = Integer.MAX_VALUE, boundMinY = Integer.MAX_VALUE;
        int boundMaxX = Integer.MIN_VALUE, boundMaxY = Integer.MIN_VALUE;
        for (Point p : points) {
            double dx = p.x - centerX;
            double dy = p.y - centerY;
            int rotatedX = (int) (dx * Math.cos(radians) - dy * Math.sin(radians) + centerX);
            int rotatedY = (int) (dx * Math.sin(radians) + dy * Math.cos(radians) + centerY);
            boundMinX = Math.min(boundMinX, rotatedX);
            boundMinY = Math.min(boundMinY, rotatedY);
            boundMaxX = Math.max(boundMaxX, rotatedX);
            boundMaxY = Math.max(boundMaxY, rotatedY);
        }
        return new Rectangle(boundMinX, boundMinY, boundMaxX - boundMinX, boundMaxY - boundMinY);
    }
}

package shapes;

import java.awt.*;
import java.awt.geom.AffineTransform;
import java.awt.geom.Point2D;
import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;
public class RectangleShape extends ShapeBase {
    public RectangleShape(int x, int y, int w, int h) {
        super(x, y, w, h);
    }
    @Override
    public void draw(Graphics2D g2d) {
        AffineTransform oldTransform = g2d.getTransform();// 保存原始变换
        double centerX = x + width / 2.0;// 设置旋转中心为图形中心
        double centerY = y + height / 2.0;
        g2d.rotate(Math.toRadians(rotationAngle), centerX, centerY); // 应用旋转变换
        g2d.setColor(strokeColor); // 设置颜色与画笔
        g2d.setStroke(strokeType);
        if (fillColor != null) { // 填充
            g2d.setColor(fillColor);
            g2d.fillRect(x, y, width, height);
            g2d.setColor(strokeColor); // 恢复画笔颜色
        }
        g2d.drawRect(x, y, width, height);// 描边
        g2d.setTransform(oldTransform); // 恢复变换，确保控制点不被旋转
        if (isSelected()) { // 如果选中，绘制控制点（不旋转）
            g2d.setColor(Color.BLUE);
            for (Point cp : getControlPoints()) {
                g2d.fillRect(cp.x - 4, cp.y - 4, 8, 8);
            }
        }
    }
    @Override
    public boolean contains(Point p) {
        double centerX = x + width / 2.0;
        double centerY = y + height / 2.0;
        double dx = p.x - centerX;
        double dy = p.y - centerY;
        double radians = Math.toRadians(-rotationAngle); // 反向旋转
        double rotatedX = dx * Math.cos(radians) - dy * Math.sin(radians) + centerX;
        double rotatedY = dx * Math.sin(radians) + dy * Math.cos(radians) + centerY;
        Rectangle rect = new Rectangle(x, y, width, height);
        return rect.contains(rotatedX, rotatedY);
    }
    @Override
    public List<Point> getControlPoints() {
        List<Point> points = new ArrayList<>();
        double centerX = x + width / 2.0;
        double centerY = y + height / 2.0;
        Point2D.Double[] originalPoints = {
            new Point2D.Double(x, y),              // Top-left
            new Point2D.Double(x + width, y),      // Top-right
            new Point2D.Double(x, y + height),     // Bottom-left
            new Point2D.Double(x + width, y + height) // Bottom-right
        };
        double radians = Math.toRadians(rotationAngle);
        for (Point2D.Double pt : originalPoints) {
            double dx = pt.x - centerX;
            double dy = pt.y - centerY;
            double rotatedX = dx * Math.cos(radians) - dy * Math.sin(radians) + centerX;
            double rotatedY = dx * Math.sin(radians) + dy * Math.cos(radians) + centerY;
            points.add(new Point((int) rotatedX, (int) rotatedY));
        }
        return points;
    }
    @Override
    public Rectangle getBounds() {
        List<Point> rotatedPoints = getControlPoints();
        int minX = Integer.MAX_VALUE;
        int minY = Integer.MAX_VALUE;
        int maxX = Integer.MIN_VALUE;
        int maxY = Integer.MIN_VALUE;
        for (Point p : rotatedPoints) {
            minX = Math.min(minX, p.x);
            minY = Math.min(minY, p.y);
            maxX = Math.max(maxX, p.x);
            maxY = Math.max(maxY, p.y);
        }
        return new Rectangle(minX, minY, maxX - minX, maxY - minY);
    }
	@Override
    public void updateFromControlPoints(List<Point> points, boolean keepAspectRatio) {
        if (points.size() >= 4) {
            Point p1 = points.get(0); // 原始 top-left 控制点
            Point p4 = points.get(3); // 当前拖动的 bottom-right 控制点（或任意角点）
            int dx = p4.x - p1.x;
            int dy = p4.y - p1.y;
            int absWidth = Math.abs(dx);
            int absHeight = Math.abs(dy);
            int signX = Integer.signum(dx);
            int signY = Integer.signum(dy);
            if (keepAspectRatio && originalAspectRatio > 0) {
                // 修正长宽以匹配比例
                if (absWidth > absHeight * originalAspectRatio) {
                    absWidth = (int)(absHeight * originalAspectRatio);
                } else {
                    absHeight = (int)(absWidth / originalAspectRatio);
                }
                // 基于拖动方向反向偏移
                if (signX >= 0 && signY >= 0) {
                    this.x = p1.x;
                    this.y = p1.y;
                } else if (signX < 0 && signY >= 0) {
                    this.x = p1.x - absWidth;
                    this.y = p1.y;
                } else if (signX >= 0 && signY < 0) {
                    this.x = p1.x;
                    this.y = p1.y - absHeight;
                } else {
                    this.x = p1.x - absWidth;
                    this.y = p1.y - absHeight;
                }
                this.width = absWidth;
                this.height = absHeight;
            } else {
                this.x = Math.min(p1.x, p4.x); // 非保持比例，正常设置
                this.y = Math.min(p1.y, p4.y);
                this.width = Math.abs(p4.x - p1.x);
                this.height = Math.abs(p4.y - p1.y);
            }
        }
    }
    @Override
    public ShapeBase clone() {
        RectangleShape copy = new RectangleShape(x, y, width, height);
        copy.strokeColor = this.strokeColor;
        copy.fillColor = this.fillColor;
        copy.strokeType = this.strokeType;
        copy.rotationAngle = this.rotationAngle; // 复制旋转角度
        copy.originalAspectRatio = this.originalAspectRatio; // 复制长宽比
        copy.setSelected(this.isSelected());
        return copy;
    }
    @Override
    public JSONObject toJSON() {
        JSONObject obj = new JSONObject();
        obj.put("type", "Rectangle");
        obj.put("x", x);
        obj.put("y", y);
        obj.put("width", width);
        obj.put("height", height);
        obj.put("rotation", rotationAngle);
        if (strokeColor != null) {
            obj.put("strokeColor", strokeColor.getRGB());
        }
        if (fillColor != null) {
            obj.put("fillColor", fillColor.getRGB());
        }
        JSONObject strokeObj = new JSONObject();
        strokeObj.put("width", strokeType.getLineWidth());
        strokeObj.put("cap", strokeType.getEndCap());
        strokeObj.put("join", strokeType.getLineJoin());
        strokeObj.put("miterlimit", strokeType.getMiterLimit());
        strokeObj.put("dash", strokeType.getDashArray() != null ? new JSONArray(strokeType.getDashArray()) : JSONObject.NULL);
        strokeObj.put("dash_phase", strokeType.getDashPhase());
        obj.put("strokeType", strokeObj);
        return obj;
    }
    public static RectangleShape fromJSON(JSONObject obj) {
        int x = obj.getInt("x");
        int y = obj.getInt("y");
        int w = obj.getInt("width");
        int h = obj.getInt("height");
        RectangleShape shape = new RectangleShape(x, y, w, h);
        if (obj.has("strokeColor")) {
            shape.strokeColor = new Color(obj.getInt("strokeColor"), true);
        }
        if (obj.has("fillColor")) {
            shape.fillColor = new Color(obj.getInt("fillColor"), true);
        }
        if (obj.has("rotation")) {
            shape.rotationAngle = obj.getDouble("rotation");
        }
        shape.setStrokeColor(new Color(obj.getInt("strokeColor")));
        if (obj.has("strokeType")) {
            JSONObject strokeObj = obj.getJSONObject("strokeType");
            float width = (float) strokeObj.getDouble("width");
            int cap = strokeObj.getInt("cap");
            int join = strokeObj.getInt("join");
            float miterlimit = (float) strokeObj.getDouble("miterlimit");
            float dash_phase = (float) strokeObj.getDouble("dash_phase");
            BasicStroke stroke;
            if (strokeObj.has("dash") && !strokeObj.isNull("dash")) {
                JSONArray dashArray = strokeObj.getJSONArray("dash");
                float[] dash = new float[dashArray.length()];
                for (int i = 0; i < dash.length; i++) {
                    dash[i] = (float) dashArray.getDouble(i);
                }
                stroke = new BasicStroke(width, cap, join, miterlimit, dash, dash_phase);
            } else {
                stroke = new BasicStroke(width, cap, join, miterlimit);
            }
            shape.setStrokeType(stroke);
        }
        return shape;
    }
}

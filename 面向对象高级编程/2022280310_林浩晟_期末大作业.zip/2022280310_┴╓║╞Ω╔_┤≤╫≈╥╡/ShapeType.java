package shapes;

public enum ShapeType {
    RECTANGLE,
    ELLIPSE,
    LINE,
    FREEHAND,
    POLYGON
}

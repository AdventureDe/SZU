package shapes;

import java.awt.*;
import java.util.List;

import org.json.JSONObject;
public abstract class ShapeBase implements Cloneable {
    public int x, y, width, height;
    protected Color strokeColor = Color.BLACK;
    protected int strokeWidth = 1;   //笔画宽度
    protected boolean selected = false;
    protected BasicStroke strokeType = new BasicStroke(1);
    protected Color fillColor = null;  // null 表示不填充
    protected double originalAspectRatio = 1.0;
    protected double rotationAngle = 0; // 以度为单位
    public void recordAspectRatio() {
        if (height != 0) {
            originalAspectRatio = Math.abs((double) width / height);
        } else {
            originalAspectRatio = 1.0; // 避免除0
        }
    }
    public ShapeBase(int x, int y, int w, int h) {
        this.x = x;
        this.y = y;
        this.width = w;
        this.height = h;
    }
    public void setSize(int w, int h) {
        this.width = w;
        this.height = h;
    }
    public Color getStrokeColor() {
        return strokeColor;
    }
    public int getStrokeWidth() {
        return strokeWidth;
    }
    public void setSelected(boolean selected) { // 设置选中状态
        this.selected = selected;
    }
    public void moveBy(int dx, int dy) {
        x += dx;
        y += dy;
    }
    public double getRotationAngle() {
        return rotationAngle;
    }
    public void setRotationAngle(double angle) {
        this.rotationAngle = angle;
    }
    public boolean isSelected() { // 获取选中状态
        return selected;
    }
    // 设置颜色
    public void setStrokeColor(Color color) {
        this.strokeColor = color;
    }
    // 设置粗细
    public void setStrokeWidth(int width) {
        this.strokeWidth = width;
        this.strokeType = new BasicStroke(width);
    }
    // 设置线条类型
    public void setStrokeType(BasicStroke stroke) {
        this.strokeType = stroke;
    }
    //填充部分
    public void setFillColor(Color color) {
        this.fillColor = color;
    }
    public Color getFillColor() {
        return fillColor;
    }
    //用于粘贴偏移  
    public void offset(int dx, int dy) {
        this.x += dx;
        this.y += dy;
    }
    public abstract void draw(Graphics2D g2d);
    public abstract boolean contains(Point p); // 检查是否包含某点（用于选中）
    public abstract java.util.List<Point> getControlPoints();
    public  void updateFromControlPoints(List<Point> controlPoints, boolean keepAspectRatio) {
    }
	public void updateFromControlPoints(List<Point> cps, boolean isShiftDown, boolean isBigger,int drag) {	
	}
    public abstract ShapeBase clone();
	public abstract Rectangle getBounds();
    public abstract JSONObject toJSON();
    public static ShapeBase fromJSON(JSONObject obj) {
        String type = obj.getString("type");
        switch (type) {
            case "Rectangle":
                return RectangleShape.fromJSON(obj);
            case "Line":
                return LineShape.fromJSON(obj);
            case "Freehand":
                return FreehandShape.fromJSON(obj);
            case "Ellipse":
            	return EllipseShape.fromJSON(obj);
            case "Polygon":
            	return PolygonShape.fromJSON(obj);
            default:
                throw new IllegalArgumentException("Unknown shape type: " + type);
        }
    }
}

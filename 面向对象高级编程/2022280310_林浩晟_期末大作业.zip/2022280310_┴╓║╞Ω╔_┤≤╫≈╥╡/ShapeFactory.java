package shapes;

public class ShapeFactory {
    public static ShapeBase createShape(ShapeType type, int x, int y) {
        switch (type) {
            case RECTANGLE:
                return new RectangleShape(x, y, 0, 0);
            case ELLIPSE:
                return new EllipseShape(x, y, 0, 0);
            case LINE:
                return new LineShape(x, y, x, y);
            case FREEHAND:
                return new FreehandShape(x, y);
            case POLYGON:
                return new PolygonShape(); // 多边形按点击点添加
            default:
                throw new IllegalArgumentException("未知图形类型：" + type);
        }
    }
}

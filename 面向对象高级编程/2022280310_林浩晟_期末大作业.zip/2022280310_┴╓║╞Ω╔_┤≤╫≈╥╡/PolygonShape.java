package shapes;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;
public class PolygonShape extends ShapeBase {
    private ArrayList<Point> points = new ArrayList<>();
    private boolean completed = false;

    public PolygonShape() {
        super(0, 0, 0, 0);
    }

    public void addPoint(Point p) {
        if (!completed) {
            points.add(p);
        }
    }

    public void completePolygon() {
        if (points.size() > 2) {
            completed = true;
        }
    }

    public boolean isCompleted() {
        return completed;
    }

    public Point getLastPoint() {
        return points.get(points.size() - 1);
    }
    @Override
    public void draw(Graphics2D g2d) {
        if (points.size() < 2) return;
        List<Point> rotatedPoints = getRotatedPoints();
        if (isCompleted() && fillColor != null) {
            Polygon poly = new Polygon();
            for (Point p : rotatedPoints) {
                poly.addPoint(p.x, p.y);
            }
            g2d.setColor(fillColor);
            g2d.fillPolygon(poly);
        }
        g2d.setStroke(strokeType);
        g2d.setColor(strokeColor);
        for (int i = 0; i < rotatedPoints.size() - 1; i++) {
            Point p1 = rotatedPoints.get(i);
            Point p2 = rotatedPoints.get(i + 1);
            g2d.drawLine(p1.x, p1.y, p2.x, p2.y);
        }
        if (isCompleted()) {
            Point firstPoint = rotatedPoints.get(0);
            Point lastPoint = rotatedPoints.get(rotatedPoints.size() - 1);
            g2d.drawLine(lastPoint.x, lastPoint.y, firstPoint.x, firstPoint.y);
        }
        if (isSelected()) {
            g2d.setColor(Color.RED);
            for (Point cp : rotatedPoints) {
                g2d.fillRect(cp.x - 4, cp.y - 4, 8, 8);
            }
        }
    }
    private List<Point> getRotatedPoints() {
        List<Point> result = new ArrayList<>();
        Point center = getCenter();
        double rad = Math.toRadians(rotationAngle);

        for (Point p : points) {
            int x = p.x - center.x;
            int y = p.y - center.y;

            int rotatedX = (int) (x * Math.cos(rad) - y * Math.sin(rad)) + center.x;
            int rotatedY = (int) (x * Math.sin(rad) + y * Math.cos(rad)) + center.y;

            result.add(new Point(rotatedX, rotatedY));
        }
        return result;
    }
    private Point getCenter() {
        int sumX = 0, sumY = 0;
        for (Point p : points) {
            sumX += p.x;
            sumY += p.y;
        }
        return new Point(sumX / points.size(), sumY / points.size());
    }
    @Override
    public boolean contains(Point p) {
        final int TOLERANCE = 5;
        for (int i = 0; i < points.size() - 1; i++) {
            Point p1 = points.get(i);
            Point p2 = points.get(i + 1);
            if (pointToSegmentDistance(p1, p2, p) <= TOLERANCE) {
                return true;
            }
        }
        if (completed) {// 如果已经闭合，也可以检测内部区域
            Polygon poly = new Polygon();
            for (Point point : points) {
                poly.addPoint(point.x, point.y);
            }
            if (poly.contains(p)) return true;
        }
        return false;
    }

    // 辅助方法：点到线段的距离
    private double pointToSegmentDistance(Point A, Point B, Point P) {
        double dx = B.x - A.x;
        double dy = B.y - A.y;

        if (dx == 0 && dy == 0) {
            dx = P.x - A.x;
            dy = P.y - A.y;
            return Math.sqrt(dx * dx + dy * dy);
        }

        double t = ((P.x - A.x) * dx + (P.y - A.y) * dy) / (dx * dx + dy * dy);
        t = Math.max(0, Math.min(1, t));

        double nearestX = A.x + t * dx;
        double nearestY = A.y + t * dy;
        dx = P.x - nearestX;
        dy = P.y - nearestY;

        return Math.sqrt(dx * dx + dy * dy);
    }
    @Override
    public void moveBy(int dx, int dy) {
        for (int i = 0; i < points.size(); i++) {
            Point p = points.get(i);
            p.translate(dx, dy); // 原地修改点位置
        }
    }

    @Override
    public List<Point> getControlPoints() {
        return new ArrayList<>(points); // 返回副本以避免外部修改原始列表
    }
    @Override
    public void updateFromControlPoints(List<Point> controlPoints,
    		boolean keepAspectRatio) {
        points.clear();
        points.addAll(controlPoints);
    }
    @Override
    public ShapeBase clone() {
        PolygonShape copy = new PolygonShape();
        for (Point p : this.points) {
            copy.points.add(new Point(p));  // 深拷贝每个点
        }
        copy.completed = this.completed;
        copy.strokeColor = this.strokeColor;
        copy.fillColor = this.fillColor;
        copy.strokeType = this.strokeType;
        copy.setSelected(true);  // 默认选中
        return copy;
    }
    //重载
    public void offset(int dx, int dy) {
        for (Point p : points) {
            p.translate(dx, dy);
        }
    }
    @Override
    public JSONObject toJSON() {
        JSONObject obj = new JSONObject();
        obj.put("type", "Polygon");

        JSONArray pointArray = new JSONArray();
        for (Point p : points) {
            JSONObject pointObj = new JSONObject();
            pointObj.put("x", p.x);
            pointObj.put("y", p.y);
            pointArray.put(pointObj);
        }
        obj.put("rotation", rotationAngle);
        obj.put("points", pointArray);
        obj.put("completed", completed);
        obj.put("strokeColor", strokeColor.getRGB());
        JSONObject strokeObj = new JSONObject();
        strokeObj.put("width", strokeType.getLineWidth());
        strokeObj.put("cap", strokeType.getEndCap());
        strokeObj.put("join", strokeType.getLineJoin());
        strokeObj.put("miterlimit", strokeType.getMiterLimit());
        strokeObj.put("dash", strokeType.getDashArray() != null ? new JSONArray(strokeType.getDashArray()) : JSONObject.NULL);
        strokeObj.put("dash_phase", strokeType.getDashPhase());
        obj.put("strokeType", strokeObj);
        obj.put("fillColor", fillColor == null ? -1 : fillColor.getRGB());
        return obj;
    }
    public static PolygonShape fromJSON(JSONObject obj) {
        PolygonShape shape = new PolygonShape();
        JSONArray pointArray = obj.getJSONArray("points");
        for (int i = 0; i < pointArray.length(); i++) {
            JSONObject pointObj = pointArray.getJSONObject(i);
            int x = pointObj.getInt("x");
            int y = pointObj.getInt("y");
            shape.addPoint(new Point(x, y));
        }
        shape.completed = obj.getBoolean("completed");
        shape.setStrokeColor(new Color(obj.getInt("strokeColor")));
        if (obj.has("rotation")) {
            shape.rotationAngle = obj.getDouble("rotation");
        }
        if (obj.has("strokeType")) {
            JSONObject strokeObj = obj.getJSONObject("strokeType");
            float width = (float) strokeObj.getDouble("width");
            int cap = strokeObj.getInt("cap");
            int join = strokeObj.getInt("join");
            float miterlimit = (float) strokeObj.getDouble("miterlimit");
            float dash_phase = (float) strokeObj.getDouble("dash_phase");
            BasicStroke stroke;
            if (strokeObj.has("dash") && !strokeObj.isNull("dash")) {
                JSONArray dashArray = strokeObj.getJSONArray("dash");
                float[] dash = new float[dashArray.length()];
                for (int i = 0; i < dash.length; i++) {
                    dash[i] = (float) dashArray.getDouble(i);
                }
                stroke = new BasicStroke(width, cap, join, miterlimit, dash, dash_phase);
            } else {
                stroke = new BasicStroke(width, cap, join, miterlimit);
            }
            shape.setStrokeType(stroke);
        }
        int fill = obj.getInt("fillColor");
        if (fill != -1) shape.setFillColor(new Color(fill));
        return shape;
    }
    @Override
    public Rectangle getBounds() {
        if (points.isEmpty()) {
            return new Rectangle(0, 0, 0, 0);
        }
        int minX = Integer.MAX_VALUE;
        int minY = Integer.MAX_VALUE;
        int maxX = Integer.MIN_VALUE;
        int maxY = Integer.MIN_VALUE;
        for (Point p : points) {
            minX = Math.min(minX, p.x);
            minY = Math.min(minY, p.y);
            maxX = Math.max(maxX, p.x);
            maxY = Math.max(maxY, p.y);
        }
        return new Rectangle(minX, minY, maxX - minX, maxY - minY);
    }

}


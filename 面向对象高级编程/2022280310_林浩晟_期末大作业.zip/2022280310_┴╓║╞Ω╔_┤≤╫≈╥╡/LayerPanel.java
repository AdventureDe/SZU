package ui;

import layer.Layer;
import shapes.ShapeBase;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import java.awt.*;
import java.awt.event.*;
import java.util.Collections;
import java.util.List;

public class LayerPanel extends JPanel {
    /**
	 * 
	 */
	private static final long serialVersionUID = -1306530174726408540L;
	static DefaultListModel<Layer<ShapeBase>> listModel;
    private JList<Layer<ShapeBase>> layerList;
    private JButton addButton, deleteButton, renameButton, moveUpButton, moveDownButton;
    private CanvasPanel canvas;
    public LayerPanel(CanvasPanel canvas) {
        this.canvas = canvas;
        setLayout(new BorderLayout());
        listModel = new DefaultListModel<>();
        // 初始化图层列表
        layerList = new JList<>(listModel);
        layerList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        layerList.setCellRenderer(new LayerCellRenderer());
        layerList.addListSelectionListener(this::onLayerSelected);
        // 鼠标双击切换图层可见性
        layerList.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int index = layerList.locationToIndex(e.getPoint());
                if (index != -1 && e.getClickCount() == 2) {
                    Layer<ShapeBase> layer = listModel.get(index);
                    layer.setVisible(!layer.isVisible());
                    layerList.repaint();
                    canvas.repaint();
                }
            }
        });
        JScrollPane scrollPane = new JScrollPane(layerList);
        // 控制按钮面板
        JPanel buttonPanel = new JPanel(new GridLayout(5, 1));
        addButton = new JButton("新增");
        deleteButton = new JButton("删除");
        renameButton = new JButton("重命名");
        moveUpButton = new JButton("上移");
        moveDownButton = new JButton("下移");
        addButton.addActionListener(e -> addLayer());
        deleteButton.addActionListener(e -> deleteLayer());
        renameButton.addActionListener(e -> renameLayer());
        moveUpButton.addActionListener(e -> moveLayer(-1));
        moveDownButton.addActionListener(e -> moveLayer(1));
        buttonPanel.add(addButton);
        buttonPanel.add(deleteButton);
        buttonPanel.add(renameButton);
        buttonPanel.add(moveUpButton);
        buttonPanel.add(moveDownButton);
        add(scrollPane, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);
    }
    private void onLayerSelected(ListSelectionEvent e) {
        int index = layerList.getSelectedIndex();
        if (index != -1) {
            canvas.setCurrentLayerIndex(index);
        }
    }
    public void setLayers(List<Layer<ShapeBase>> layers) {
        listModel.clear();
        for (Layer<ShapeBase> l : layers) {
            listModel.addElement(l);
        }
        layerList.setSelectedIndex(0);
    }
    public List<Layer<ShapeBase>> getLayers() {
        return Collections.list(listModel.elements());
    }
    private void addLayer() {
        String name = JOptionPane.showInputDialog("图层名称：");
        if (name != null && !name.isEmpty()) {
            Layer<ShapeBase> newLayer = new Layer<>(name);
            listModel.add(0, newLayer);
            layerList.setSelectedIndex(0);
            canvas.setLayers(getLayers());
        }
    }
    private void deleteLayer() {
        int index = layerList.getSelectedIndex();
        if (index != -1 && listModel.size() > 1) {
            listModel.remove(index);
            canvas.setLayers(getLayers());
            layerList.setSelectedIndex(Math.max(0, index - 1));
        } else {
            JOptionPane.showMessageDialog(this, "至少保留一个图层！");
        }
    }
    private void renameLayer() {
        int index = layerList.getSelectedIndex();
        if (index != -1) {
            Layer<ShapeBase> layer = listModel.get(index);
            String newName = JOptionPane.showInputDialog("新名称：", layer.getName());
            if (newName != null && !newName.isEmpty()) {
                layer.setName(newName);
                layerList.repaint();
            }
        }
    }
    private void moveLayer(int direction) {
        int index = layerList.getSelectedIndex();
        int newIndex = index + direction;
        if (index >= 0 && newIndex >= 0 && newIndex < listModel.size()) {
            Layer<ShapeBase> layer = listModel.get(index);
            listModel.remove(index);
            listModel.add(newIndex, layer);
            layerList.setSelectedIndex(newIndex);
            canvas.setLayers(getLayers());
        }
    }
    // 让列表显示“图层名 + 可见性”
    private static class LayerCellRenderer extends DefaultListCellRenderer {
        /**
		 * 
		 */
		private static final long serialVersionUID = 8886034316454541191L;
		private final Icon visibleIcon = UIManager.getIcon("FileView.fileIcon");
        private final Icon hiddenIcon = UIManager.getIcon("FileView.hardDriveIcon");

        @Override
        public Component getListCellRendererComponent(JList<?> list, Object value, int index,
                                                      boolean isSelected, boolean cellHasFocus) {
            JLabel label = (JLabel) super.getListCellRendererComponent(
                    list, value, index, isSelected, cellHasFocus);
            if (value instanceof Layer) {
                Layer<?> layer = (Layer<?>) value;
                label.setText(layer.getName());
                label.setIcon(layer.isVisible() ? visibleIcon : hiddenIcon);
            }
            return label;
        }
    }
}

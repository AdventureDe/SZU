package shapes;

import java.awt.*;
import java.awt.geom.AffineTransform;
import java.awt.geom.Point2D;
import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;

public class LineShape extends ShapeBase {
    private int x2, y2;

    public LineShape(int x1, int y1, int x2, int y2) {
        super(x1, y1, 0, 0); // width/height 对线段无意义
        this.x2 = x2;
        this.y2 = y2;
    }

    public void setEnd(int x, int y) {
        this.x2 = x;
        this.y2 = y;
    }

    public int getX1() { return x; }
    public int getY1() { return y; }
    public int getX2() { return x2; }
    public int getY2() { return y2; }

    @Override
    public void draw(Graphics2D g2d) {
        g2d.setColor(strokeColor);
        g2d.setStroke(strokeType);
        AffineTransform oldTransform = g2d.getTransform();
        double centerX = (x + x2) / 2.0;
        double centerY = (y + y2) / 2.0;
        double rad = Math.toRadians(rotationAngle);
        g2d.rotate(rad, centerX, centerY);
        g2d.drawLine(x, y, x2, y2);
        g2d.setTransform(oldTransform);
        if (selected) {
            g2d.setColor(Color.BLUE);
            for (Point p : getControlPoints()) {
                g2d.fillRect(p.x - 3, p.y - 3, 6, 6);
            }
        }
    }

    @Override
    public void moveBy(int dx, int dy) {
        offset(dx, dy);
    }

    @Override
    public Rectangle getBounds() {
        List<Point> rotatedPoints = getControlPoints();
        int minX = Integer.MAX_VALUE;
        int minY = Integer.MAX_VALUE;
        int maxX = Integer.MIN_VALUE;
        int maxY = Integer.MIN_VALUE;
        for (Point p : rotatedPoints) {
            minX = Math.min(minX, p.x);
            minY = Math.min(minY, p.y);
            maxX = Math.max(maxX, p.x);
            maxY = Math.max(maxY, p.y);
        }
        return new Rectangle(minX, minY, maxX - minX, maxY - minY);
    }

    @Override
    public boolean contains(Point p) {
        final int tolerance = 5;
        double centerX = (x + x2) / 2.0;
        double centerY = (y + y2) / 2.0;
        double radians = Math.toRadians(-rotationAngle);
        double dx = p.x - centerX;
        double dy = p.y - centerY;
        double rotatedX = dx * Math.cos(radians) - dy * Math.sin(radians) + centerX;
        double rotatedY = dx * Math.sin(radians) + dy * Math.cos(radians) + centerY;
        double distance = ptSegDist(x, y, x2, y2, rotatedX, rotatedY);
        return distance <= tolerance;
    }
    private double ptSegDist(int x1, int y1, int x2, int y2, double px, double py) {
        double dx = x2 - x1;
        double dy = y2 - y1;
        if (dx == 0 && dy == 0) return Point2D.distance(px, py, x1, y1);
        double t = ((px - x1) * dx + (py - y1) * dy) / (dx * dx + dy * dy);
        t = Math.max(0, Math.min(1, t));
        double projX = x1 + t * dx;
        double projY = y1 + t * dy;
        return Point2D.distance(px, py, projX, projY);
    }

    @Override
    public List<Point> getControlPoints() {
        List<Point> points = new ArrayList<>();
        double centerX = (x + x2) / 2.0;
        double centerY = (y + y2) / 2.0;
        double radians = Math.toRadians(rotationAngle);
        Point2D.Double[] originalPoints = {
            new Point2D.Double(x, y),
            new Point2D.Double(x2, y2)
        };
        for (Point2D.Double pt : originalPoints) {
            double dx = pt.x - centerX;
            double dy = pt.y - centerY;
            double rotatedX = dx * Math.cos(radians) - dy * Math.sin(radians) + centerX;
            double rotatedY = dx * Math.sin(radians) + dy * Math.cos(radians) + centerY;
            points.add(new Point((int) rotatedX, (int) rotatedY));
        }
        return points;
    }

    @Override
    public void updateFromControlPoints(List<Point> controlPoints, boolean keepAspectRatio) {
        if (controlPoints.size() >= 2) {
            this.x = controlPoints.get(0).x;
            this.y = controlPoints.get(0).y;
            this.x2 = controlPoints.get(1).x;
            this.y2 = controlPoints.get(1).y;
        }
    }
    @Override
    public ShapeBase clone() {
        LineShape copy = new LineShape(this.x, this.y, this.x2, this.y2);
        copy.strokeColor = this.strokeColor;
        copy.fillColor = this.fillColor;
        copy.strokeType = this.strokeType;
        copy.rotationAngle = this.rotationAngle;
        copy.setSelected(this.isSelected());
        return copy;
    }

    public void offset(int dx, int dy) {
        this.x += dx;
        this.y += dy;
        this.x2 += dx;
        this.y2 += dy;
    }

    @Override
    public JSONObject toJSON() {
        JSONObject obj = new JSONObject();
        obj.put("type", "Line");
        obj.put("x1", x);
        obj.put("y1", y);
        obj.put("x2", x2);
        obj.put("y2", y2);
        obj.put("strokeColor", strokeColor.getRGB());
        obj.put("fillColor", fillColor == null ? -1 : fillColor.getRGB());
        obj.put("rotation", rotationAngle);
        JSONObject strokeObj = new JSONObject();
        strokeObj.put("width", strokeType.getLineWidth());
        strokeObj.put("cap", strokeType.getEndCap());
        strokeObj.put("join", strokeType.getLineJoin());
        strokeObj.put("miterlimit", strokeType.getMiterLimit());
        strokeObj.put("dash", strokeType.getDashArray() != null ? new JSONArray(strokeType.getDashArray()) : JSONObject.NULL);
        strokeObj.put("dash_phase", strokeType.getDashPhase());
        obj.put("strokeType", strokeObj);
        return obj;
    }

    public static LineShape fromJSON(JSONObject obj) {
        LineShape shape = new LineShape(
            obj.getInt("x1"),
            obj.getInt("y1"),
            obj.getInt("x2"),
            obj.getInt("y2")
        );
        shape.setStrokeColor(new Color(obj.getInt("strokeColor")));
        int fill = obj.getInt("fillColor");
        if (fill != -1) shape.setFillColor(new Color(fill));
        shape.setRotationAngle(obj.optDouble("rotation", 0));
        if (obj.has("strokeType")) {
            JSONObject strokeObj = obj.getJSONObject("strokeType");
            float width = (float) strokeObj.getDouble("width");
            int cap = strokeObj.getInt("cap");
            int join = strokeObj.getInt("join");
            float miterlimit = (float) strokeObj.getDouble("miterlimit");
            float dash_phase = (float) strokeObj.getDouble("dash_phase");
            BasicStroke stroke;
            if (strokeObj.has("dash") && !strokeObj.isNull("dash")) {
                JSONArray dashArray = strokeObj.getJSONArray("dash");
                float[] dash = new float[dashArray.length()];
                for (int i = 0; i < dash.length; i++) {
                    dash[i] = (float) dashArray.getDouble(i);
                }
                stroke = new BasicStroke(width, cap, join, miterlimit, dash, dash_phase);
            } else {
                stroke = new BasicStroke(width, cap, join, miterlimit);
            }
            shape.setStrokeType(stroke);
        }
        return shape;
    }
}
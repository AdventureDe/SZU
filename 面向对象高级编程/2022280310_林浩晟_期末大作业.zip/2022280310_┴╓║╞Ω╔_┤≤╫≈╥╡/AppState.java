package state;

import shapes.ShapeBase;
import shapes.ShapeType;

import java.awt.*;

public class AppState {
    private static final AppState instance = new AppState();

    private AppState() {}

    public static AppState getInstance() {
        return instance;
    }
    protected double rotationAngle = 0; // 以度为单位
    private Color strokeColor = Color.BLACK;
    private Color fillColor = null; // null 表示不填充
    private int strokeWidth = 1;
    private boolean dashed = false;
    private ShapeType currentShapeType = ShapeType.RECTANGLE;
    private boolean isEdit = false;
    private boolean isDraw = true;
    private ShapeBase selectedShape = null;
    public boolean getisEdit() {
    	return isEdit;
    }
    public boolean getisDraw() {
    	return isDraw;
    }
    public void setisEdit(boolean in) {
    	isEdit=in;
    }
    public void setisDraw(boolean in) {
    	isDraw=in;
    }
    // Getter 和 Setter
    public Color getStrokeColor() {
        return strokeColor;
    }
    public double getRotationAngle() {
        return rotationAngle;
    }
    public void setRotationAngle(double angle) {
        this.rotationAngle = angle;
    }
    public void setStrokeColor(Color strokeColor) {
        this.strokeColor = strokeColor;
    }
    public Color getFillColor() {
        return fillColor;
    }
    public void setFillColor(Color fillColor) {
        this.fillColor = fillColor;
    }
    public int getStrokeWidth() {
        return strokeWidth;
    }
    public void setStrokeWidth(int strokeWidth) {
        this.strokeWidth = strokeWidth;
    }
   public boolean isDashed() {
        return dashed;
    }
    public void setDashed(boolean dashed) {
        this.dashed = dashed;
    }
    public ShapeType getCurrentShapeType() {
        return currentShapeType;
    }
    public void setCurrentShapeType(ShapeType currentShapeType) {
        this.currentShapeType = currentShapeType;
    }
    public ShapeBase getSelectedShape() {
        return selectedShape;
    }
    public void setSelectedShape(ShapeBase selectedShape) {
        this.selectedShape = selectedShape;
    }
    public void setCurrentFillColor(Color color) {
        this.fillColor = color;
    }
    // 工厂方法统一生成 BasicStroke
    public BasicStroke getStroke() {
        if (dashed) {
            return new BasicStroke(strokeWidth, BasicStroke.CAP_BUTT, BasicStroke.JOIN_BEVEL, 10.0f, new float[]{10.0f}, 0.0f);
        } else {
            return new BasicStroke(strokeWidth);
        }
    }
    
}

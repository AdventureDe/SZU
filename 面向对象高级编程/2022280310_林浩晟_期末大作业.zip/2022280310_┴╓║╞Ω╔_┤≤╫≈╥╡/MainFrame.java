package ui;

import state.*;

import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;

import org.json.JSONArray;
import org.json.JSONObject;

import layer.Layer;
import shapes.ShapeBase;

import java.awt.*;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;

public class MainFrame extends JFrame {
	/**
	 * 
	 */
	private static final long serialVersionUID = 4880117777533816114L;
	CanvasPanel canvas;
    public MainFrame() {
        setTitle("二维图形编辑器");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1000, 700);
        setLocationRelativeTo(null); // 居中
        // 创建菜单栏
        JMenuBar menuBar = createMenuBar();
        setJMenuBar(menuBar);
        // 创建画布
        canvas = new CanvasPanel();
        ToolPanel toolPanel = new ToolPanel(AppState.getInstance(),canvas);
       // 初始化图层
        List<Layer<ShapeBase>> initialLayers = new ArrayList<>();
        initialLayers.add(new Layer<>("图层 1"));
        canvas.setLayers(initialLayers);
        // 创建图层面板
        LayerPanel layerPanel = new LayerPanel(canvas);
        layerPanel.setLayers(initialLayers);
        add(layerPanel, BorderLayout.EAST);
        add(toolPanel, BorderLayout.NORTH); // 工具栏在上方
        add(canvas, BorderLayout.CENTER);
        setVisible(true);
    }
  
    private JMenuBar createMenuBar() {
        JMenuBar menuBar = new JMenuBar();

        JMenu fileMenu = new JMenu("文件");
        JMenuItem newItem = new JMenuItem("新建");
        JMenuItem openItem = new JMenuItem("打开");
        JMenuItem saveItem = new JMenuItem("保存");
        JMenu fileMenu1=new JMenu("模式");
        JMenuItem drawItem=new JMenuItem("绘画模式");
        JMenuItem editItem=new JMenuItem("编辑模式");
        // 添加监听事件
        newItem.addActionListener(e -> {
            canvas.getCurrentLayer().getShapes().clear();  // 清空当前图层的图形
            canvas.repaint();
        });
        saveItem.addActionListener(e -> {
            JFileChooser fileChooser = new JFileChooser();

            // 设置文件过滤器，只允许保存为 .shape 文件
            FileNameExtensionFilter filter = new FileNameExtensionFilter("Shape File (*.shape)", "shape");
            fileChooser.setFileFilter(filter);

            if (fileChooser.showSaveDialog(null) == JFileChooser.APPROVE_OPTION) {
                File file = fileChooser.getSelectedFile();

                // 自动添加 .shape 后缀（如果用户没有写）
                if (!file.getName().toLowerCase().endsWith(".shape")) {
                    file = new File(file.getAbsolutePath() + ".shape");
                }

                JSONArray array = new JSONArray();
                // 遍历所有图层
                for (Layer<ShapeBase> layer : canvas.getLayers()) {
                    JSONObject layerObject = new JSONObject();
                    layerObject.put("name", layer.getName());
                    layerObject.put("visible", layer.isVisible());

                    // 图层内的所有形状
                    JSONArray shapesArray = new JSONArray();
                    for (ShapeBase shape : layer.getShapes()) {
                        shapesArray.put(shape.toJSON());
                    }
                    layerObject.put("shapes", shapesArray);
                    array.put(layerObject);
                }

                try (PrintWriter out = new PrintWriter(file)) {
                    out.print(array.toString(4));
                    JOptionPane.showMessageDialog(null, "保存成功！");
                } catch (IOException ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(null, "保存失败：" + ex.getMessage());
                }
            }
        });
        openItem.addActionListener(e -> {
            JFileChooser fileChooser = new JFileChooser();
            // 设置文件过滤器，只允许选择 .shape 文件
            FileNameExtensionFilter filter = new FileNameExtensionFilter("Shape File (*.shape)", "shape");
            fileChooser.setFileFilter(filter);
            if (fileChooser.showOpenDialog(null) == JFileChooser.APPROVE_OPTION) {
                File file = fileChooser.getSelectedFile();
                // 检查是否为 .shape 文件
                if (!file.getName().toLowerCase().endsWith(".shape")) {
                    JOptionPane.showMessageDialog(null, "只能打开 .shape 文件！", "错误", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                try {
                    String content = new String(Files.readAllBytes(file.toPath()));
                    JSONArray array = new JSONArray(content);
                    List<Layer<ShapeBase>> loadedLayers = new ArrayList<>();

                    // 遍历 JSON 中的每个图层
                    for (int i = 0; i < array.length(); i++) {
                        JSONObject layerObj = array.getJSONObject(i);

                        // 解析图层信息
                        String layerName = layerObj.getString("name");
                        boolean isVisible = layerObj.getBoolean("visible");
                        Layer<ShapeBase> layer = new Layer<>(layerName);
                        layer.setVisible(isVisible);

                        // 解析图层中的形状
                        JSONArray shapesArray = layerObj.getJSONArray("shapes");
                        for (int j = 0; j < shapesArray.length(); j++) {
                            JSONObject shapeObj = shapesArray.getJSONObject(j);
                            ShapeBase shape = ShapeBase.fromJSON(shapeObj);  // 从 JSON 中加载形状
                            layer.add(shape);
                        }

                        // 将解析的图层添加到加载的图层列表中
                        loadedLayers.add(layer);
                    }

                    // 设置图层到 canvas
                    canvas.setLayers(loadedLayers);
                    JOptionPane.showMessageDialog(null, "加载成功！");
                    repaint();
                } catch (IOException ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(null, "读取失败：" + ex.getMessage(), "错误", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
        drawItem.addActionListener(e->{
        	AppState.getInstance().setisDraw(true);
        	AppState.getInstance().setisEdit(false);
        	ToolPanel.modeLabel.setText("绘画模式");
        });
        editItem.addActionListener(e->{
        	AppState.getInstance().setisDraw(false);
        	AppState.getInstance().setisEdit(true);
        	ToolPanel.modeLabel.setText("编辑模式");
        });
        fileMenu.add(newItem);
        fileMenu.add(openItem);
        fileMenu.add(saveItem);
        fileMenu1.add(drawItem);
        fileMenu1.add(editItem);
        menuBar.add(fileMenu);
        menuBar.add(fileMenu1);

        return menuBar;
    }
}

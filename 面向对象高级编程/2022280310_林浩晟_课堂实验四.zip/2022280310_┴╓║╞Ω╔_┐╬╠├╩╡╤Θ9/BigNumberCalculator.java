package t2;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.RoundingMode;

public class BigNumberCalculator {
	public static String evaluate(String expression) {
        expression = expression.trim();
        String[] tokens;
        char operator = ' ';
        if (expression.contains(" + ")) {
            tokens = expression.split(" \\+ ");
            operator = '+';
        } else if (expression.contains(" - ")) {
            tokens = expression.split(" - ");
            operator = '-';
        } else if (expression.contains(" * ")) {
            tokens = expression.split(" \\* ");
            operator = '*';
        } else if (expression.contains(" / ")) {
            tokens = expression.split(" / "); 
            operator = '/';
        } else {
            throw new IllegalArgumentException("不支持的表达式格式。");
        }
        String left = tokens[0].trim();
        String right = tokens[1].trim();
        boolean isDecimal = left.contains(".") || right.contains(".");
        if (isDecimal) {
            BigDecimal num1 = new BigDecimal(left);
            BigDecimal num2 = new BigDecimal(right);

            switch (operator) {
                case '+': return num1.add(num2).toPlainString();
                case '-': return num1.subtract(num2).toPlainString();
                case '*': return num1.multiply(num2).toPlainString();
                case '/':
                    if (num2.compareTo(BigDecimal.ZERO) == 0) {
                        throw new ArithmeticException("除数不能为零");
                    }
                    return num1.divide(num2, 20, RoundingMode.HALF_UP).stripTrailingZeros().toPlainString();
                default: throw new IllegalArgumentException("无效操作符");
            }
        } else {
            BigInteger num1 = new BigInteger(left);
            BigInteger num2 = new BigInteger(right);

            switch (operator) {
                case '+': return num1.add(num2).toString();
                case '-': return num1.subtract(num2).toString();
                case '*': return num1.multiply(num2).toString();
                case '/':
                    if (num2.equals(BigInteger.ZERO)) {
                        throw new ArithmeticException("除数不能为零");
                    }
                    return num1.divide(num2).toString();
                default: throw new IllegalArgumentException("无效操作符");
            } 
        }
    }

    public static void test(String expression) {
        System.out.println("Expression: " + expression);
        try {
            String result = evaluate(expression);
            System.out.println("Result: " + result);
        } catch (ArithmeticException e) {
            System.out.println("Error: " + e.getMessage());
        }
        System.out.println();
    }
    
    public static void main(String[] args) {
        test("123456789123456789123456789 + 987654321987654321987654321");
        test("999999999999999999999999999999 * 888888888888888888888888888888");
        test("100000000000000000000000000000 / 0");
        test("1000.0001 - 999.9999");
        test("1234567.8910 * 0.0001");
    }
}

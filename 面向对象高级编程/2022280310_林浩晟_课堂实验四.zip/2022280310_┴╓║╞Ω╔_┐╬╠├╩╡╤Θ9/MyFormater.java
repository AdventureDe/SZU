package t3;
 
public class MyFormater {
    public static String myFormat(String format, String... args) {
        StringBuilder result = new StringBuilder();
        int argIndex = 0;
        int i = 0;

        while (i < format.length()) {
            if (i + 1 < format.length() && format.charAt(i) == '{' && format.charAt(i + 1) == '}') {
                if (argIndex < args.length) {
                    result.append(args[argIndex++]);
                } else {
                    result.append("{}"); 
                }
                i += 2; 
            } else {
                result.append(format.charAt(i));
                i++;
            }
        }

        return result.toString();
    }

    public static void main(String[] args) {
        String result = myFormat("This is {} {}", "pos1", "pos2");
        
        System.out.println(result);

        System.out.println(myFormat("Hello, {}!", "World"));             
    }
}

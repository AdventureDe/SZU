package t1;

import java.util.Date;
import java.util.Calendar;

class SensitiveData {
    private final Date startDate;
    private final Date endDate;
    public SensitiveData(Date start, Date end) {
        if (start == null || end == null) {
            throw new IllegalArgumentException("日期不能为空。");
        }

        Date now = new Date(); 
        Date safeStart = new Date(start.getTime());
        Date safeEnd = new Date(end.getTime());

        if (safeStart.after(now) || safeEnd.after(now)) {
            throw new IllegalArgumentException("日期不能是将来的时间。");
        }
 
        if (safeEnd.before(safeStart)) {
            throw new IllegalArgumentException("结束日期不能早于开始日期。");
        }
        this.startDate = safeStart;
        this.endDate = safeEnd;
    }

    public Date getStartDate() {
        return new Date(startDate.getTime());
    }
    public Date getEndDate() {
        return new Date(endDate.getTime());
    }

    @Override
    public String toString() {
        return "SensitiveData{" +
                "startDate=" + startDate +
                ", endDate=" + endDate +
                '}';
    }
}

public class SensitiveDataTest {
    public static void main(String[] args) {
        testValidDates();
        testFutureDate();
        testEndBeforeStart();
        testImmutability();
    }
    // 测试正常构造和数据读取
    public static void testValidDates() {
        Calendar cal = Calendar.getInstance();
        cal.set(2022, Calendar.JANUARY, 1);
        Date start = cal.getTime();

        cal.set(2023, Calendar.JANUARY, 1);
        Date end = cal.getTime();

        try {
            SensitiveData sd = new SensitiveData(start, end);
            System.out.println("testValidDates PASSED");
            System.out.println("Start: " + sd.getStartDate());
            System.out.println("End: " + sd.getEndDate());
        } catch (Exception e) {
            System.out.println("testValidDates FAILED: " + e.getMessage());
        }
    }
    // 测试未来日期输入（应该抛出异常）
    public static void testFutureDate() {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DAY_OF_YEAR, 1); // 明天
        Date future = cal.getTime();

        try {
            new SensitiveData(future, future);
            System.out.println("testFutureDate FAILED: 应该抛出异常");
        } catch (IllegalArgumentException e) {
            System.out.println("testFutureDate PASSED: " + e.getMessage());
        }
    }
    // 测试 endDate 早于 startDate（应抛出异常） 
    public static void testEndBeforeStart() {
        Calendar cal = Calendar.getInstance();
        cal.set(2023, Calendar.JANUARY, 1);
        Date end = cal.getTime();

        cal.set(2024, Calendar.JANUARY, 1);
        Date start = cal.getTime();
        try {
            new SensitiveData(start, end);
            System.out.println("testEndBeforeStart FAILED: 应该抛出异常");
        } catch (IllegalArgumentException e) {
            System.out.println("testEndBeforeStart PASSED: " + e.getMessage());
        }
    }

    // 测试外部修改传入日期对象是否影响内部数据
    public static void testImmutability() {
        Calendar cal = Calendar.getInstance();
        cal.set(2020, Calendar.MARCH, 10);
        Date start = cal.getTime();

        cal.set(2020, Calendar.APRIL, 10);
        Date end = cal.getTime();

        SensitiveData sd = new SensitiveData(start, end);

        start.setTime(0);
        end.setTime(0);
        Date retrievedStart = sd.getStartDate();
        Date retrievedEnd = sd.getEndDate();

        if (retrievedStart.getTime() != 0 && retrievedEnd.getTime() != 0){
            System.out.println("testImmutability PASSED");
        } else {
            System.out.println("testImmutability FAILED");
        }
    }
}











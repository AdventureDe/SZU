package t1;
import java.util.*;
import java.lang.reflect.*;

public class ReflectiveListCreator {

    public static void main(String[] args) {
        test(new String[]{"java.util.ArrayList", "Hello", "World", "Java"});
        test(new String[]{"java.util.LinkedList", "Reflective", "Test", "Case"});
        test(new String[]{"java.util.FakeList", "Testing", "Error", "Handling"});
        test(new String[]{"java.util.ArrayList"});
    }
 
    public static void test(String[] args) {
        try {
            if (args.length < 1) {
                throw new IllegalArgumentException("No class name provided.");
            }

            Class<?> clazz = Class.forName(args[0]);
            Object instance = clazz.getDeclaredConstructor().newInstance();

            if (!(instance instanceof List)) {
                throw new IllegalArgumentException("Class does not implement List.");
            }

            List<String> list = (List<String>) instance;
            for (int i = 1; i < args.length; i++) {
                list.add(args[i]); 
            }

            System.out.println("List contents: " + list);
        } catch (Exception e) {
            System.out.println("Error occurred: " + e);
        }

        System.out.println();
    }
}


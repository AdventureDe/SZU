package t2;
import java.io.*;
import java.util.*;

class MyFileNotFoundException extends Exception {
    public MyFileNotFoundException(String message) {
        super(message);
    }
}
class InvalidContentException extends Exception {
    public InvalidContentException(String message) {
        super(message);
    }
}

class EmptyFileException extends Exception {
    public EmptyFileException(String message) {
        super(message);
    }
}
class FileParser {
    public static List<Integer> parseFile(File file)
            throws MyFileNotFoundException, InvalidContentException, EmptyFileException {
        if (!file.exists()) {
            throw new MyFileNotFoundException("File not found: " + file.getName());
        }

        List<Integer> numbers = new ArrayList<>();
        boolean hasContent = false;
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty()) continue;

                hasContent = true;
                String[] parts = line.split(",");

                for (String part : parts) {
                    String trimmed = part.trim();
                    if (trimmed.isEmpty()) continue;
                    try {
                        int number = Integer.parseInt(trimmed);
                        numbers.add(number);
                    } catch (NumberFormatException e) {
                        throw new InvalidContentException("Invalid content in file: " + file.getName());
                    }
                }
            }
        } catch (IOException e) {
            throw new MyFileNotFoundException("Error reading file: " + file.getName());
        }
        if (!hasContent) {
            throw new EmptyFileException("File is empty: " + file.getName());
        }
        return numbers;
    }
}
 
public class FileParserTest {
    public static void main(String[] args) {
        String basePath = "C:/Users/MasterRin/Desktop/test";
        String[] fileNames = {
            "numbers.txt",
            "invalid_content.txt",
            "empty.txt",
            "spaces_and_newlines.txt"
        };

        for (String name : fileNames) {
            File file = new File(basePath, name);
            System.out.println(name);
            try {
                List<Integer> result = FileParser.parseFile(file);
                System.out.println(result);
            } catch (MyFileNotFoundException | InvalidContentException | EmptyFileException e) {
                System.out.println("Error: " + e.getMessage());
            }
            System.out.println();
        }
    }
}

package t1;

interface Powerable
{
    void charge();
}

interface Controllable{
    void turnOn();
    void turnOff();
}

interface SmartDevice extends Powerable, Controllable
{
    boolean connectToWiFi(String password);
}

//SmartLamp类，实现SmartDevice接口
class SmartLamp implements SmartDevice
{
    protected boolean isOn = false;
    protected boolean isCharging = false;
    protected boolean isConnectedToWiFi = false;
    static final String WIFI_PASSWORD = "12345678";
    @Override
        public void charge() {
        isCharging = true;
        System.out.println("智能灯正在充电");
    }
    @Override
        public void turnOn() {
            isOn = true;
            System.out.println("智能灯已打开");
    }
    @Override
        public void turnOff() {
        isOn = false;
        System.out.println("智能灯已关闭");
    }
    @Override
        public boolean connectToWiFi(String password) {
        if (WIFI_PASSWORD.equals(password)) {
            isConnectedToWiFi = true;
            System.out.println("智能灯成功连接至WiFi");
            return true;
        }
        else {
            System.out.println("密码错误，智能灯连接WiFi失败");
            return false;
        }
    }
}

//测试类
public class SmartLampTest 
{
    public static void main(String[] args) {
        SmartLamp lamp = new SmartLamp();

        lamp.charge();
        lamp.turnOn(); 
        lamp.turnOff();

        lamp.connectToWiFi("11111111");
        lamp.connectToWiFi("12345678");
    }
}

package t2;

interface Shape{
    void draw();
    double area(); 
}

//定义抽象类 AbstractShape，实现 Shape 接口，为所有图形提供统一的绘制逻辑
abstract class AbstractShape implements Shape {
	private String name;  //图形名称
 //构造函数，设置图形名称
	public AbstractShape(String name) {
    	this.name = name;
	}
 //实现 draw 方法，提供默认的绘制实现
 @Override
 	public void draw() {
     	System.out.println("draw " + name);
 	}
 //抽象方法 area，由子类实现各自的面积计算逻辑
 @Override
 	public abstract double area();
}

//定义 Circle 类，继承 AbstractShape，表示圆形
class Circle extends AbstractShape {
	private double radius;  // 圆的半径

 //构造函数，调用父类构造器传入图形名称为“圆”
	public Circle(double radius) {
		super("圆");
     	this.radius = radius;
	}
 //实现 area 方法，返回圆的面积
 @Override
 	public double area() {
     	return Math.PI * radius * radius;
 	}
}

//定义 Rectangle 类，继承 AbstractShape，表示长方形
class Rectangle extends AbstractShape {
	private double width;   // 长方形的宽度
 	private double height;  // 长方形的高度
 //构造函数，调用父类构造器传入图形名称为“长方形”
 	public Rectangle(double width, double height) {
 		super("长方形");
     	this.width = width;
     	this.height = height;
 	}
 //实现 area 方法，返回长方形的面积
 @Override
 	public double area() {
	 	return width * height;
 	}
}
//测试类
public class ShapeTest{
    public static void main(String[] args){
        Shape circle=new Circle(5);
        circle.draw();
        System.out.println("圆面积："+circle.area());

        Shape rectangle=new Rectangle(4,6);
        rectangle.draw();
        System.out.println("长方形面积:"+rectangle.area());
    }
}
 
 










package t1;

import java.util.Arrays;

class MyLinkedList<E> {
    private class Node {
        E data;
        Node next;
        Node(E data) {
            this.data = data;
            this.next = null;
        }
    }
    Node head;
    int size;

    public MyLinkedList() {
        head = null;
        size = 0;
    }

    public void addLast(E e) {
    	 if (e == null) {//不允许添加null
    	        throw new NullPointerException();
    	    }
        Node newNode = new Node(e);
        if (head == null) {
            head = newNode;
        } else {
            Node cur = head;
            while (cur.next != null) {
                cur = cur.next;
            }
            cur.next = newNode;
        }
        size++;
    }

    public void addFirst(E e) {
        Node newNode = new Node(e);
        newNode.next = head;
        head = newNode;
        size++;
    }

    public void remove(int idx) {
        if (idx < 0 || idx >= size) {
            throw new IndexOutOfBoundsException();
        }
        if (idx == 0) {
            head = head.next;
        } else {
            Node prev = head;
            for (int i = 0; i < idx - 1; i++) {
                prev = prev.next;
            }
            prev.next = prev.next.next;
        }
        size--;
    }
 
    public E get(int idx) {
        if (idx < 0 || idx >= size) {
            throw new IndexOutOfBoundsException();
        }
        Node cur = head;
        for (int i = 0; i < idx; i++) {
            cur = cur.next;
        }
        return cur.data;
    }

    public int size() {
        return size;
    }

    public boolean contains(E e) {
        Node cur = head;
        while (cur != null) {
            if (e != null && e.equals(cur.data)) {
                return true;
            }
            cur = cur.next;
        }
        return false;
    }
    
    public void clear() {
        head = null;
        size = 0;
    }
    @SuppressWarnings("unchecked")
    public E[] toArray() {
        E[] array = (E[]) new Object[size];
        Node cur = head;
        for (int i = 0; i < size; i++) {
            array[i] = cur.data;
            cur = cur.next;
        }
        return array;
    }
}
public class TestMyLinkedList {
    public static void main(String[] args) {
        // 创建 MyLinkedList 实例
        MyLinkedList<Integer> list = new MyLinkedList<>();

        // 测试空链表的操作
        System.out.println("Initial size of list: " + list.size());  // 预期输出: 0
        try {
            System.out.println("Get element from empty list: " + list.get(0));
        } catch (IndexOutOfBoundsException e) {
            System.out.println("Caught an IndexOutOfBoundsException when trying to get element from empty list");  // 预期捕获异常
        }

        // 测试 addLast 和 addFirst 方法
        list.addLast(10);
        list.addFirst(5);
        list.addLast(20);
        System.out.println("After adding elements: " + Arrays.toString(list.toArray()));  // 预期输出: [5, 10, 20]
        
        // 测试添加 null 元素（如果允许）
        try {
            list.addLast(null);
            System.out.println("After adding null: " + Arrays.toString(list.toArray()));
        } catch (NullPointerException e) {
            System.out.println("Caught NullPointerException when adding null");  // 如果不允许 null，预期捕获异常
        }
        
        // 测试越界访问
        try {
            System.out.println("Attempt to access out of bounds: " + list.get(5));
        } catch (IndexOutOfBoundsException e) {
            System.out.println("Caught an IndexOutOfBoundsException when accessing out of bounds");  // 预期捕获异常
        }
        
        // 测试删除操作中的越界
        try {
            list.remove(5);
        } catch (IndexOutOfBoundsException e) {
            System.out.println("Caught an IndexOutOfBoundsException when trying to remove out of bounds element");  // 预期捕获异常
        }
        
        // 正常测试 contains, remove 和 size 方法
        System.out.println("List contains 10: " + list.contains(10));  // 预期输出: true
        list.remove(1);
        System.out.println("After removing element at index 1: " + Arrays.toString(list.toArray()));  // 预期输出: [5, 20]
        System.out.println("Size after removal: " + list.size());  // 预期输出: 2

        // 测试 clear 方法
        list.clear();
        System.out.println("After clearing the list: " + list.size());  // 预期输出: 0

        // 重新添加元素并测试 toArray 方法
        list.addFirst(15);
        list.addLast(25);
        System.out.println("Final list: " + Arrays.toString(list.toArray()));  // 预期输出: [15, 25]
    }
}


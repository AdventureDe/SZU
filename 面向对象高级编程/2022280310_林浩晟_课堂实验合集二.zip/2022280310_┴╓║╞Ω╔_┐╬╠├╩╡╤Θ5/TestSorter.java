package t2;

class Sorter {
    public static <E extends Comparable<? super E>> void sort(E[] a) 
    {
        for (int i = 0; i < a.length - 1; i++) {
            for (int j = 0; j < a.length - i - 1; j++) {
                if (a[j].compareTo(a[j + 1]) > 0) { 
                    E temp = a[j];
                    a[j] = a[j + 1];
                    a[j + 1] = temp;
                }
            }
        }
    }
} 
public class TestSorter {
    public static void main(String[] args) {
        Integer[] numbers = {10, 3, 4, 15, 7};
        String[] words = {"banana", "apple", "pear", "orange"};

        Sorter.sort(numbers);
        Sorter.sort(words);

        System.out.println("Sorted numbers:");
        for (int num : numbers) {
            System.out.print(num + " ");
        }
        System.out.println();

        System.out.println("Sorted words:");
        for (String word : words) {
            System.out.print(word + " ");
        }
        System.out.println();
    }
}

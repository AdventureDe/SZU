package t3;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
 
class FlattenedArray<T> {
    private final List<T[]> arrays;
    private final List<Integer> indexOffsets;
    private int totalSize;

    public FlattenedArray() {
        arrays = new ArrayList<>();
        indexOffsets = new ArrayList<>();
        totalSize = 0;
    }

    public void add(T[] array) {
        if (array == null) {
            throw new IllegalArgumentException();
        }
        arrays.add(array);
        indexOffsets.add(totalSize);
        totalSize += array.length;
    }
    
    public T get(int index){
        if (index < 0 || index >= totalSize) {
            throw new IndexOutOfBoundsException();
        }
        int arrayIdx = findArrayIndex(index);
        int localIdx = index - indexOffsets.get(arrayIdx);
        return arrays.get(arrayIdx)[localIdx];
    } 
    private int findArrayIndex(int index){
        int left = 0, right = indexOffsets.size() - 1;
        while (left <= right) {
            int mid = (left + right) / 2;
            int start = indexOffsets.get(mid);
            int end = (mid == indexOffsets.size() - 1)
            		? totalSize : indexOffsets.get(mid + 1);
            if (index >= start && index < end) return mid;
            if (index < start) right = mid - 1;
            else left = mid + 1;
        }
        throw new IndexOutOfBoundsException();
    }
    public void set(int arrayIndex, int elementIndex, T value){
        if (arrayIndex < 0 || arrayIndex >= arrays.size()) {
            throw new IndexOutOfBoundsException();
        }
        if (elementIndex < 0 || elementIndex >= arrays.get(arrayIndex).length) {
            throw new IndexOutOfBoundsException();
        }
        arrays.get(arrayIndex)[elementIndex] = value;
    }

    public int size(){
        return totalSize;
    }

    @Override
    public String toString(){
        StringBuilder sb = new StringBuilder("[");
        for (int i = 0; i < arrays.size(); i++) {
            if (i > 0) sb.append(", ");
            sb.append(Arrays.toString(arrays.get(i)));
        }
        sb.append("]");
        return sb.toString();
    }
}

public class FlattenedArrayTest {
    public static void main(String[] args) {
        FlattenedArray<String> fa = new FlattenedArray<>();
        fa.add(new String[]{"apple", "banana"});
        fa.add(new String[]{"cherry", "date", "elderberry"});
        fa.add(new String[]{"fig"});

        System.out.println("Original: " + fa.get(0));  // 输出 "apple"
        fa.set(0, 0, "apricot"); // 修改第一个数组的第一个元素
        System.out.println("Modified: " + fa.get(0));  // 输出 "apricot"
        System.out.println("Unaffected: " + fa.get(3));  // 输出 "date"，验证独立性
        System.out.println(fa.size());  // 输出 6
        System.out.println("Arrays: " + fa.toString());  // 输出所有数组的元素
        // 输出格式：[[apricot, banana], [cherry, date, elderberry], [fig]]
        
        try {
            fa.get(-1); // 尝试访问一个负索引
            System.out.println("Test Illegal Index Access: Failed (No exception for negative index)");
        } catch (IndexOutOfBoundsException e) {
            System.out.println("Test Illegal Index Access: Passed (Correct exception for negative index)");
        }

        try {
            fa.get(6); // 尝试访问一个不存在的索引
            System.out.println("Test Illegal Index Access: Failed (No exception for index out of bounds)");
        } catch (IndexOutOfBoundsException e) {
            System.out.println("Test Illegal Index Access: Passed (Correct exception for index out of bounds)");
        }
    }
}

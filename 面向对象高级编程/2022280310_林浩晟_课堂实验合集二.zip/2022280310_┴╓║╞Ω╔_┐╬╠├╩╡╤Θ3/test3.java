package t3;

import java.util.ArrayList;

interface IStorage<E>{
    void store(E item);
    E retrieve(int index);
}

class Storage<E> implements IStorage<E>{
    private ArrayList<E> items = new ArrayList<>();

    @Override
    public void store(E item) {
        items.add(item);
    }
    @Override
    public E retrieve(int index){//根据索引检索存储的元素
        if (index >= 0 && index < items.size())
        {
            return items.get(index);
        } 
        return null;
    }
}

class CountingStorage<E> extends Storage<E> {
    private int count = 0;

    @Override
    public void store(E item){ 
        super.store(item);
        count++;
    }

    public int getItemCount(){
        return count;
    }
}

class CountingStorageWithForwarding<E> implements IStorage<E> {
    private final Storage<E> storage = new Storage<>();
    private int count = 0;
    @Override
    public void store(E item){
        storage.store(item);
        count++;
    }
    @Override
    public E retrieve(int index){
        return storage.retrieve(index);
    }
    public int getItemCount() 
    {
        return count;
    }
}
 
public class test3 {
    public static void main(String[] args) {
        CountingStorageWithForwarding<String> storage = new CountingStorageWithForwarding<>();
        storage.store("apple");
        storage.store("banana");
        storage.store("123456");
        System.out.println("存储的元素包含：" + storage.getItemCount());
        System.out.println("第一个元素：" + storage.retrieve(0));
        System.out.println("第二个元素：" + storage.retrieve(1));
        System.out.println("第三个元素：" + storage.retrieve(2));
    }
}
 





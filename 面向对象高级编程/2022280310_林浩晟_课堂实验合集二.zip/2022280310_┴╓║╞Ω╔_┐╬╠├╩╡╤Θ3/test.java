package t2;

abstract class Shape{
    protected String name;
    public static final double PI = 3.141592653;
    public Shape(String name)
    {
        this.name = name;
    }
 
    public abstract double area();
    public abstract double perimeter();
} 

class Rectangle extends Shape 
{
    private double width;
    private double height;

    public Rectangle(String name, double width, double height) {
        super(name);
        this.width = width;
        this.height = height;
    }
    @Override
    public double area() {
        return width * height;
    }
    @Override
    public double perimeter() {
        return 2 * (width + height);
    }
}

class Circle extends Shape
{
    private double radius;

    public Circle(String name, double radius){
        super(name);
        this.radius = radius;
    }
    @Override
    public double area(){
        return PI * radius * radius;
    }
    @Override
    public double perimeter(){
        return 2 * PI * radius;
    }
}
public class test {
    public static void main(String[] args) {
        Shape rectangle = new Rectangle("Rectangle", 5, 10);
        Shape circle = new Circle("Circle", 5);

        System.out.println(rectangle.name + " 面积: " + rectangle.area());
        System.out.println(rectangle.name + " 周长: " + rectangle.perimeter());
        
        System.out.println(circle.name + " 面积: " + circle.area());
        System.out.println(circle.name + " 周长: " + circle.perimeter());
    }
}


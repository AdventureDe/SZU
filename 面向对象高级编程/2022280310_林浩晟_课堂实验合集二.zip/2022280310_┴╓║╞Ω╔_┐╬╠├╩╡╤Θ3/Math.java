package t1;

public class Math
{
    public static final double PI = 3.141592653;

    public static double circumference(double radius)
    {
        return 2 * PI * radius;
    }

    public static void main(String[] args){
        double radius = 5.0;
        System.out.println("圆的周长: " + circumference(radius));
    }
}

package imageProcess;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

@FunctionalInterface
interface ShortUnaryOperator {
    short applyAsShort(short operand);
}
@FunctionalInterface
interface ShortBinaryOperator {
    short applyAsShort(short left, short right);
}

class Img {
    enum IMG_STORE_TYPE {GRAY, GRAY_A, RGB, RGB_A;}

    int width;
    int height;
    IMG_STORE_TYPE store_type;
    short[] pixel_data;

    public void readImg(String filePath) {
        try {
            BufferedImage img = ImageIO.read(new File(filePath));
            if (img == null) {
                System.err.println("Unsupported image format.");
                return;
            }

            width = img.getWidth();
            height = img.getHeight();
            int numChannels = img.getColorModel().getNumComponents();

            if (numChannels == 1) {
                store_type = IMG_STORE_TYPE.GRAY;
            } else if (numChannels == 2) {
                store_type = IMG_STORE_TYPE.GRAY_A;
            } else if (numChannels == 3) {
                store_type = IMG_STORE_TYPE.RGB;
            } else {
                store_type = IMG_STORE_TYPE.RGB_A;
            }

            pixel_data = new short[width * height * numChannels];

            int index = 0;
            for (int y = 0; y < height; y++) {
                for (int x = 0; x < width; x++) {
                    int rgb = img.getRGB(x, y);
                    pixel_data[index++] = (short)((rgb >> 16) & 0xFF); // R
                    pixel_data[index++] = (short)((rgb >> 8) & 0xFF);  // G
                    pixel_data[index++] = (short)(rgb & 0xFF);         // B
                    if (numChannels == 4 || img.getColorModel().hasAlpha()) {
                        pixel_data[index++] = (short)((rgb >> 24) & 0xFF); // A
                    }
                }
            }

        } catch (IOException e) {
            System.err.println("Failed to read image: " + e.getMessage());
        }
    }

    public void writeImg(String filePath) {
        if (pixel_data == null || pixel_data.length == 0) {
            System.err.println("No image data to write.");
            return;
        }

        BufferedImage output = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
        int index = 0;

        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                int r = pixel_data[index++];
                int g = pixel_data[index++];
                int b = pixel_data[index++];
                int rgb = (r << 16) | (g << 8) | b;
                output.setRGB(x, y, rgb);
                if (store_type == IMG_STORE_TYPE.RGB_A) {
                    index++; // skip alpha
                }
            }
        }

        try {
            File outFile = new File(filePath);
            ImageIO.write(output, "png", outFile);
        } catch (IOException e) {
            System.err.println("Failed to write image: " + e.getMessage());
        }
    }

    public Img UnaryOperation(ShortUnaryOperator unary_op) {
        if (unary_op == null || this.pixel_data == null) {
            Img empty = new Img();
            empty.width = this.width;
            empty.height = this.height;
            empty.store_type = this.store_type;
            empty.pixel_data = new short[0];
            return empty;
        }

        Img result = new Img();
        result.width = this.width;
        result.height = this.height;
        result.store_type = this.store_type;
        result.pixel_data = new short[this.pixel_data.length];

        for (int i = 0; i < this.pixel_data.length; i++) {
            int value = unary_op.applyAsShort(this.pixel_data[i]);
            result.pixel_data[i] = (short) Math.max(0, Math.min(255, value));
        }

        return result;
    }

    public Img BinaryOperation(Img other, ShortBinaryOperator binary_op) {
        if (binary_op == null || other == null || other.pixel_data == null || this.pixel_data == null) {
            Img empty = new Img();
            empty.width = this.width;
            empty.height = this.height;
            empty.store_type = this.store_type;
            empty.pixel_data = new short[0];
            return empty;
        }

        if (this.width != other.width || this.height != other.height || this.pixel_data.length != other.pixel_data.length) {
            throw new IllegalArgumentException("图像大小或像素数据不一致");
        }

        Img result = new Img();
        result.width = this.width;
        result.height = this.height;
        result.store_type = this.store_type;
        result.pixel_data = new short[this.pixel_data.length];

        for (int i = 0; i < this.pixel_data.length; i++) {
            int value = binary_op.applyAsShort(this.pixel_data[i], other.pixel_data[i]);
            result.pixel_data[i] = (short) Math.max(0, Math.min(255, value));
        }

        return result;
    }
}

public class ImgTest {
    public static void main(String[] args) {
        Img img1 = new Img();
        img1.readImg("C:/Users/MasterRin/Desktop/1.png");

        Img img2 = new Img();
        img2.readImg("C:/Users/MasterRin/Desktop/3.png");

        // 反色操作
        ShortUnaryOperator invert = x -> (short)(255 - x); 
        Img inverted = img1.UnaryOperation(invert);
        inverted.writeImg("C:/Users/MasterRin/Desktop/inverted.png");

        // 加法操作
        ShortBinaryOperator add = (a, b) -> (short)(a + b);
        Img added = img1.BinaryOperation(img2, add);
        added.writeImg("C:/Users/MasterRin/Desktop/added1.png");
 
        // 减法操作
        ShortBinaryOperator subtract = (a, b) -> (short)(a - b);
        Img subtracted = img1.BinaryOperation(img2, subtract);
        subtracted.writeImg("C:/Users/MasterRin/Desktop/subtracted1.png");
    }
}


package t1;

import java.util.*;

class Statistics {
    // 返回列表最小值
    public static <E extends Comparable<? super E>> E min(List<? extends E> list) {
        if (list == null || list.isEmpty()) {
            return null;
        }
        E min = list.get(0);
        for (E item : list) {
            if (item.compareTo(min) < 0) {
                min = item;
            }
        }
        return min;
    }

    // 返回列表最大值
    public static <E extends Comparable<? super E>> E max(List<? extends E> list) {
        if (list == null || list.isEmpty()) {
            return null;
        }
        E max = list.get(0);
        for (E item : list) {
            if (item.compareTo(max) > 0) {
                max = item;
            }
        }
        return max;
    }

    // 返回列表中位数
    @SuppressWarnings("unchecked")
	public static <E extends Comparable<? super E>> E median(List<? extends E> list) {
        if (list == null || list.isEmpty()) {
            return null;
        }
        List<E> sorted = new ArrayList<>(list);
        Collections.sort(sorted);
        int size = sorted.size();

        if (size % 2 == 1) {
            return sorted.get(size / 2);
        } else { 
            E lower = sorted.get(size / 2 - 1);
            E upper = sorted.get(size / 2);
            Double avg = (((Number) lower).doubleValue() + ((Number) upper).doubleValue()) / 2.0;
            return (E) avg;
        }
    }
}

class SetOperation {
    @SafeVarargs
    public static <E> Set<E> union(Set<? extends E>... sets) {
        Set<E> result = new HashSet<>();
        if (sets == null || sets.length == 0) return result;
        for (Set<? extends E> set : sets) {
            if (set != null) {
                result.addAll(set);
            }
        }
        return result;
    }

    // 返回集合的交集
    @SafeVarargs
    public static <E> Set<E> intersection(Set<? extends E>... sets) {
        if (sets == null || sets.length == 0) 
        	return new HashSet<>();

        Iterator<Set<? extends E>> iterator = Arrays.stream(sets)
                .filter(Objects::nonNull)
                .iterator();

        if (!iterator.hasNext())
        	return new HashSet<>();
        Set<E> result = new HashSet<>(iterator.next());
        while (iterator.hasNext()) {
            result.retainAll(iterator.next());
        }
        return result;
    } 
}
 
public class Test_t1 {
    public static void main(String[] args) {
        List<Integer> nums = Arrays.asList(3, -5, 4, 1, 5, 9);
        System.out.println("Min: " + Statistics.min(nums));
        System.out.println("Max: " + Statistics.max(nums));
        System.out.println("Median: " + Statistics.median(nums));

        Set<Integer> s1 = new HashSet<>(Arrays.asList(1, 2, 3, 4));
        Set<Integer> s2 = new HashSet<>(Arrays.asList(3, 4, 5, 6));
        Set<Integer> s3 = new HashSet<>(Arrays.asList(4, 5, 6, 7));

        System.out.println("Union: " + SetOperation.union(s1, s2, s3));
        System.out.println("Intersection: " + SetOperation.intersection(s1, s2, s3));
    }
}

 


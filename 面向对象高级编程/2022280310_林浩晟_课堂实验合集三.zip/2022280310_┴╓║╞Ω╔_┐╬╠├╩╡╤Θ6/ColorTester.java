package t3;
import java.util.*;
 
enum Color {
    RED, GREEN, BLUE;
}

class ColorMixer {
    private static final Map<EnumSet<Color>, String> colorMap = new HashMap<>();

    static {
        colorMap.put(EnumSet.of(Color.RED, Color.GREEN), "Yellow");
        colorMap.put(EnumSet.of(Color.GREEN, Color.BLUE), "Cyan");
        colorMap.put(EnumSet.of(Color.RED, Color.BLUE), "Magenta");
        colorMap.put(EnumSet.of(Color.RED, Color.GREEN, Color.BLUE), "White");
    }

    public static String mixColors(EnumSet<Color> colors) {
        return colorMap.getOrDefault(colors, "Unknown");
    } 
}

public class ColorTester {
    public static void main(String[] args) {
        EnumSet<Color> rg = EnumSet.of(Color.RED, Color.GREEN);
        EnumSet<Color> gr = EnumSet.of(Color.GREEN, Color.RED);
        EnumSet<Color> gb = EnumSet.of(Color.GREEN, Color.BLUE);
        EnumSet<Color> rb = EnumSet.of(Color.RED, Color.BLUE);
        EnumSet<Color> rgb = EnumSet.of(Color.RED, Color.GREEN, Color.BLUE);
        EnumSet<Color> r = EnumSet.of(Color.RED); // 非法输入测试

        System.out.println("Red + Green = " + ColorMixer.mixColors(rg));
        System.out.println("Green + Red = " + ColorMixer.mixColors(gr));
        System.out.println("Green + Blue = " + ColorMixer.mixColors(gb));
        System.out.println("Red + Blue = " + ColorMixer.mixColors(rb));
        System.out.println("Red + Green + Blue = " + ColorMixer.mixColors(rgb));
        System.out.println("Red = " + ColorMixer.mixColors(r));
    } 
}

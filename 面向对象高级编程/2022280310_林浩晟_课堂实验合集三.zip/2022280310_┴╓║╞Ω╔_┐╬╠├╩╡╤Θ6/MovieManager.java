package t4;
import java.util.EnumSet;
 
enum MovieGenre {
    ACTION, COMEDY, DRAMA, FANTASY, HORROR, ROMANCE;
}

class Movie {
    private String title;
    private EnumSet<MovieGenre> genres;
    public Movie(String title) {
        this.title = title;
        this.genres = EnumSet.noneOf(MovieGenre.class); 
    }
    public void addGenre(MovieGenre genre) {
        genres.add(genre);
    }
    public void removeGenre(MovieGenre genre) {
        genres.remove(genre);
    }
    public String getTitle() {
        return title;
    }
    public EnumSet<MovieGenre> getGenres() {
        return genres.clone(); 
    }
    @Override
    public String toString() {
        return "Movie: " + title + "\nGenres: " + genres;
    }
}
 
public class MovieManager {
    public static void main(String[] args) {
        Movie movie1 = new Movie("Inception");
        movie1.addGenre(MovieGenre.ACTION);
        movie1.addGenre(MovieGenre.DRAMA);
        movie1.addGenre(MovieGenre.FANTASY);

        Movie movie2 = new Movie("Titanic");
        movie2.addGenre(MovieGenre.DRAMA);
        movie2.addGenre(MovieGenre.ROMANCE);

        System.out.println(movie1);
        movie1.removeGenre(MovieGenre.DRAMA);
        System.out.println("After removing DRAMA from Inception:");
        System.out.println(movie1);

        System.out.println(movie2);
    }
}




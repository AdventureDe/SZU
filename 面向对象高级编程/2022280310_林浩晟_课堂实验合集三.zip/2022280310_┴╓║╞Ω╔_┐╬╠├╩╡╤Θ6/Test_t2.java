package t2;

class Vector3 {
    public final double x, y, z;

    public Vector3(double x, double y, double z) {
        this.x = x;
        this.y = y;
        this.z = z;
    }
    // 向量加法
    public Vector3 add(Vector3 other) {
        return new Vector3(this.x + other.x, this.y + other.y, this.z + other.z);
    }
    // 向量减法
    public Vector3 subtract(Vector3 other) {
        return new Vector3(this.x - other.x, this.y - other.y, this.z - other.z);
    }
    // 向量叉乘
    public Vector3 cross(Vector3 other) {
        return new Vector3(
            this.y * other.z - this.z * other.y,
            this.z * other.x - this.x * other.z,
            this.x * other.y - this.y * other.x
        );
    }

    @Override
    public String toString() {
        return String.format("(%.2f, %.2f, %.2f)", x, y, z);
    }
}
interface Operation {
    Vector3 apply(Vector3 v1, Vector3 v2);
}

enum VectorBasicOperation implements Operation {
    ADD {
        public Vector3 apply(Vector3 v1, Vector3 v2) {
            return v1.add(v2);
        }
    },
    SUB {
        public Vector3 apply(Vector3 v1, Vector3 v2) {
            return v1.subtract(v2);
        }
    };
}

enum VectorExtendedOperation implements Operation {
    CROSS {
        public Vector3 apply(Vector3 v1, Vector3 v2) {
            return v1.cross(v2);
        }
    }; 
}

public class Test_t2 {
    public static void main(String[] args) {
        Vector3 v1 = new Vector3(1, 2, 3);
        Vector3 v2 = new Vector3(4, 5, 6);
        for (VectorBasicOperation op : VectorBasicOperation.values()) {
            System.out.printf("%s: %s%n", op.name(), op.apply(v1, v2));
        }

        for (VectorExtendedOperation op : VectorExtendedOperation.values()) {
            System.out.printf("%s: %s%n", op.name(), op.apply(v1, v2));
        }
    }
}








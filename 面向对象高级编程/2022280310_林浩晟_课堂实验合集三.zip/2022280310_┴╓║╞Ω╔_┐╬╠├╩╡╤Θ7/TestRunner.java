package t2;

import java.lang.annotation.*;
import java.lang.reflect.Method;
import java.util.*;

@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.METHOD)
@Repeatable(ExceptionTests.class)
@interface ExceptionTest {
    Class<? extends Throwable> value();
}

@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.METHOD)
@interface ExceptionTests {
    ExceptionTest[] value();
}
 
class Sample {
    @ExceptionTests({
        @ExceptionTest(IndexOutOfBoundsException.class)
    })
    public static void m1() {
        int[] array = new int[0];
        int i = array[1];
    }
    @ExceptionTest(ArithmeticException.class)
    public static void m2() {
        int i = 0;
        int j = 1 / i;
    }
    @ExceptionTest(NullPointerException.class)
    public static void m3() {
        String s = null;
        int length = s.length();
    }
    @ExceptionTest(IndexOutOfBoundsException.class)
    @ExceptionTest(NullPointerException.class)
    public static void m4() {
        Random rand = new Random();
        int randNum = rand.nextInt(101);
        if (randNum % 2 == 0) {
            m1();
        } else {
            m3();
        }
    }
}

public class TestRunner { 
    public static void main(String[] args) throws Exception {
        int passed = 0;
        int failed = 0;
        Method[] methods = Sample.class.getDeclaredMethods();
        for (Method m : methods) {
            ExceptionTest[] annotations = m.getAnnotationsByType(ExceptionTest.class);
            if (annotations.length == 0)
                continue; 
            try {
                m.invoke(null); 
                System.out.printf("Test %s failed: no exception%n", m.getName());
                failed++; 
            } catch (Exception wrapped) {
                Throwable cause = wrapped.getCause();
                boolean ok = false;
                List<Class<? extends Throwable>> expected = new ArrayList<>();
                for (ExceptionTest exTest : annotations) {
                    expected.add(exTest.value());
                    if (exTest.value().isInstance(cause)) {
                        ok = true; 
                    } 
                }
                if (ok) {
                    passed++;
                } else {
                    System.out.printf("Test %s failed: expected %s, got %s: %s%n",
                            m.getName(), expected, cause.getClass(), cause.getMessage());
                    failed++;
                } 
            }
        }
        int total = passed + failed;
        double rate = total > 0 ? passed * 100 / total : 0;
        System.out.printf("Passed: %d, Failed: %d, 通过率: %d%%\n", passed, failed, (int) rate);
    }
}

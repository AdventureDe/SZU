package t1;

import java.util.*;

class Vehicle {
    public enum Type{
        CAR, BIKE, MOTOR
    }
    private String model;
    private Type type;
    public Vehicle(String model, Type type){
        this.model = model;
        this.type = type;
    }
    public String getModel(){
        return model;
    }
    public Type getType(){ 
        return type;
    }
    @Override
    public String toString() {
        return "Model: " + model + "   Type: " + type;
    }
    public static void printVehiclesByType(EnumMap<Type, List<Vehicle>> vehicleMap){
        for (Type type : Type.values()) {
            System.out.println(type + ":");
            List<Vehicle> vehicles = vehicleMap.get(type);
            if (vehicles != null && !vehicles.isEmpty()) {
                for (Vehicle v : vehicles) {
                    System.out.println(v);
                }
            } else {
                System.out.println("None");
            }
        }
    }
}

public class VehicleTest {
    public static void main(String[] args) {
        EnumMap<Vehicle.Type, List<Vehicle>> vehicleMap = new EnumMap<>(Vehicle.Type.class);
 
        Vehicle car1 = new Vehicle("法拉利", Vehicle.Type.CAR);
        Vehicle car2 = new Vehicle("特斯拉", Vehicle.Type.CAR);
        vehicleMap.computeIfAbsent(Vehicle.Type.CAR, k -> new ArrayList<>()).add(car1);
        vehicleMap.computeIfAbsent(Vehicle.Type.CAR, k -> new ArrayList<>()).add(car2);

        Vehicle bike1 = new Vehicle("Type1", Vehicle.Type.BIKE);
        Vehicle bike2 = new Vehicle("Type2", Vehicle.Type.BIKE);
        vehicleMap.computeIfAbsent(Vehicle.Type.BIKE, k -> new ArrayList<>()).add(bike1);
        vehicleMap.computeIfAbsent(Vehicle.Type.BIKE, k -> new ArrayList<>()).add(bike2);

        Vehicle.printVehiclesByType(vehicleMap);
    }
} 


 



package t2;

import java.util.*;
import java.util.stream.*;

class Transaction {
    private String buyer;
    private String seller;
    private double amount;

    public Transaction(String buyer, String seller, double amount) {
        this.buyer = buyer;
        this.seller = seller;
        this.amount = amount;
    } 

    public String getBuyer() {
        return buyer;
    }

    public double getAmount() {
        return amount;
    }
}

public class TransactionProcessing {
    public static void main(String[] args) {
    	//将单词转换为大写
    	 List<String> collection = Arrays.asList("My", "name", "is", "John", "Doe");

         List<String> uppercased = collection.stream()
             .map(String::toUpperCase)
             .collect(Collectors.toList());

         System.out.println(uppercased);
         System.out.println();
    	//筛选字母长度小于 4 的单词
         collection = Arrays.asList("My", "name", "is", "John", "Doe");

         List<String> filtered = collection.stream()
             .filter(s -> s.length() < 4)
             .collect(Collectors.toList());

         System.out.println(filtered);
         System.out.println();
    	//使用 flatMap 实现列表展开
         List<List<String>> collections = Arrays.asList(
                 Arrays.asList("Viktor", "Farcic"),
                 Arrays.asList("John", "Doe", "Third")
             );
         List<String> flattened = collections.stream()
                 .flatMap(List::stream) 
                 .collect(Collectors.toList());

         System.out.println(flattened); 
         System.out.println();
    	//处理一个交易列表 
        List<Transaction> transactions = Arrays.asList(
            new Transaction("Alice", "Bob", 150.0),
            new Transaction("Bob", "Charlie", 200.0),
            new Transaction("Alice", "David", 50.0),
            new Transaction("Alice", "Charlie", 300.0)
        );

        processTransactions(transactions);
        // 应输出：
        // Alice: 500.0
        // Bob: 200.0
    }

    public static void processTransactions(List<Transaction> transactions) {
        Map<String, Double> buyerTotal = transactions.stream()
            .collect(Collectors.groupingBy(
                Transaction::getBuyer,
                Collectors.summingDouble(Transaction::getAmount)
            ));

        buyerTotal.entrySet().stream()
            .sorted(Map.Entry.<String, Double>comparingByValue(Comparator.reverseOrder()))
            .forEach(entry ->
                System.out.println(entry.getKey() + ": " + entry.getValue()));
    }
}

package t1;

@FunctionalInterface
interface VectorBinaryOperation 
{
    Vector3 apply(Vector3 v1, Vector3 v2);
}
@FunctionalInterface
interface ScalarOperation
{
    double apply(Vector3 v1, Vector3 v2);
}

class Vector3 
{
    private double x, y, z;
    public Vector3(double x, double y, double z){
        this.x = x;
        this.y = y;
        this.z = z;
    }
    public double getX() 
    { 
    	return x;
    }
    public double getY() 
    { 
    	return y;
    }
    public double getZ()
    { 
    	return z; 
    }
    public Vector3 normalize(){
        double length = Math.sqrt(x * x + y * y + z * z);
        if (length == 0) return new Vector3(0, 0, 0); 
        return new Vector3(x / length, y / length, z / length);
    }
    @Override
    public String toString(){
        return String.format("Vector3(%.2f, %.2f, %.2f)", x, y, z);
    }
}

public class Vector3Test {
    public static void main(String[] args) {
        Vector3 v1 = new Vector3(1, 2, 3);
        Vector3 v2 = new Vector3(4, 5, 6);
 
        VectorBinaryOperation add = (a, b) ->
            new Vector3(a.getX() + b.getX(), a.getY() + b.getY(), a.getZ() + b.getZ());
        VectorBinaryOperation subtract = (a, b) ->
            new Vector3(a.getX() - b.getX(), a.getY() - b.getY(), a.getZ() - b.getZ());
        ScalarOperation dotProduct = (a, b) ->
            a.getX() * b.getX() + a.getY() * b.getY() + a.getZ() * b.getZ();
        VectorBinaryOperation crossProduct = (a, b) -> new Vector3(
            a.getY() * b.getZ() - a.getZ() * b.getY(),
            a.getZ() * b.getX() - a.getX() * b.getZ(),
            a.getX() * b.getY() - a.getY() * b.getX()
        );
        System.out.println("v1 = " + v1);
        System.out.println("v2 = " + v2);
        System.out.println("Add: " + add.apply(v1, v2));
        System.out.println("Subtract: " + subtract.apply(v1, v2));
        System.out.println("Dot Product: " + dotProduct.apply(v1, v2));
        System.out.println("Cross Product: " + crossProduct.apply(v1, v2));
        System.out.println("Normalize v1: " + v1.normalize());
        System.out.println("Normalize v2: " + v2.normalize());
    }
}

package t2;

class Car implements Cloneable, Comparable<Car> 
{
    private String licensePlate;
    private String model;
    private String color;
    private Engine engine;
    //Car构造函数
    public Car(String licensePlate, String model, String color, Engine engine) 
    {
        this.licensePlate = licensePlate;
        this.model = model;
        this.color = color;
        this.engine = new Engine(engine);
    }
    public Car(Car car)//复制构造器
    {
        this.licensePlate = car.licensePlate;
        this.model = car.model;
        this.color = car.color;
        this.engine = new Engine(car.engine);
    }
    @Override
    public Car clone()//实现clone方法，深克隆
    {
        return new Car(this);
    }
    @Override
    public int compareTo(Car other)//实现compareTo方法，基于Engine对象比较
    {
        return this.engine.compareTo(other.engine);
    }
    @Override
    public String toString() 
    {
        return "Car{licensePlate='" + licensePlate + "', model='" + model + "', color='" + color + "', engine=" + engine + "}";
    }
    //Engine类实现Comparable接口
    static class Engine implements Comparable<Engine> 
    {
        private int horsepower;
        private int cylinders;
        private String fuelType;
        public Engine(int horsepower, int cylinders, String fuelType) 
        {
            this.horsepower = horsepower;
            this.cylinders = cylinders;
            this.fuelType = fuelType;
        }
        public Engine(Engine engine) 
        {
            this.horsepower = engine.horsepower;
            this.cylinders = engine.cylinders;
            this.fuelType = engine.fuelType;
        }
        @Override
        public int compareTo(Engine other) 
        {
            if (this.horsepower != other.horsepower) 
            {
                return Integer.compare(this.horsepower, other.horsepower);
            }
            return Integer.compare(this.cylinders, other.cylinders);
        }
        @Override
        public String toString()
        {
            return "Engine{horsepower=" + horsepower + ", cylinders=" + cylinders + ", fuelType='" + fuelType + "'}";
        }
    }
}
public class clone{
    public static void main(String[] args) 
    {
        //创建原始 Car 对象
        Car.Engine engine1 = new Car.Engine(300, 6, "Gasoline");
        Car car1 = new Car("粤888888", "Tesla", "Red", engine1);
        //测试 clone 方法
        Car car2 = car1.clone();
        System.out.println("Original: " + car1);
        System.out.println("Clone: " + car2);
        //确保是深克隆
        System.out.println(car1 == car2);
        //测试 compareTo 方法
        Car.Engine engine2 = new Car.Engine(400, 8, "Gasoline");
        Car car3 = new Car("粤666666", "Ford Mustang", "Blue", engine2);
        int comparison = car1.compareTo(car3);
        if (comparison < 0) 
        {
            System.out.println("car1 has a weaker engine than car3");
        } else if (comparison > 0) 
        {
            System.out.println("car1 has a stronger engine than car3");
        } else 
        {
            System.out.println("Both cars have equal engine power");
        }
        //测试复制构造器
        Car car4 = new Car(car1);
        System.out.println("Copy:" + car4);

        //验证深克隆
        System.out.println(car1 == car4);
    }
}

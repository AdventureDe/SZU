package t1;

import java.util.Objects;

class Book {
    private String isbn;
    private String title;
    private String author;
    private int year;

    public Book(String isbn, String title, String author, int year){
        this.isbn = isbn;
        this.title = title;
        this.author = author;
        this.year = year;
    }
    @Override
    public boolean equals(Object obj) {
    	if (this == obj) //验证是否为同一个实例
    		return true;
        if (obj == null || getClass() != obj.getClass())//obj为null或者类不一样
        	return false;
        Book book = (Book) obj;
        if(isbn.equals(book.isbn) && title != null)
        	return true;
        else 
        	return false;
    }
    @Override
    public int hashCode() {
        return Objects.hash(isbn, title);
    }
    @Override
    public String toString() {
        return "Book{" +
                "ISBN='" + isbn + '\'' +
                ", Title='" + title + '\'' +
                ", Author='" + author + '\'' +
                ", Year=" + (year == 0 ? "Unknown" : year) +
                '}';
    }
}

public class booktest {
    public static void main(String[] args) {
        Book book1 = new Book("1234567890", "Java Basics", "John Doe", 2021);
        Book book2 = new Book("1234567890", "Java Basics", "Jane Doe", 2022);
        Book book3 = new Book("0987654321", "Python Fundamentals", "Alice Smith", 2020);
          
        System.out.println(book1.equals(book2)); //true
        System.out.println(book1.equals(book3)); //false

        System.out.println(book1.hashCode() == book2.hashCode()); //true
        System.out.println(book1.hashCode() == book3.hashCode()); //false
        
        System.out.println(book1.toString());
        System.out.println(book3.toString());
        System.out.println(new Book("1111111111", "C++ Primer", "Bjarne Stroustrup", 0).toString()); //Year=Unknown
    }
}



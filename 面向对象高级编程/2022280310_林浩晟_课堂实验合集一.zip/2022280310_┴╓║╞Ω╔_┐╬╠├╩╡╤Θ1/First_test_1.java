package first_test;

import java.util.HashMap;
import java.util.Map;

//接口
interface TeaService {
 String produceTea();//声明方法
}

//分别实现返回"Green Tea"和"Black Tea"
class GreenTeaService implements TeaService {
 @Override
 public String produceTea() {
     return "Green Tea";
 }
}

class BlackTeaService implements TeaService {
 @Override
 public String produceTea() {
     return "Black Tea";
 }
}

class TeaServiceProvider {
 private final Map<String, TeaService> services = new HashMap<>();
 
 public void registerService(String name, TeaService service) {
     services.put(name, service);
 }
 
 public TeaService getTeaService(String name) {
     if (!services.containsKey(name)) {
         throw new IllegalArgumentException("出错：" + name);
     }
     return services.get(name);
 }
}

//测试
class First_test_1 {
 public static void main(String[] args) {
     TeaServiceProvider provider = new TeaServiceProvider();
     
     //注册服务
     provider.registerService("green", new GreenTeaService());
     provider.registerService("black", new BlackTeaService());
     
     //生成实体
     TeaService green = provider.getTeaService("green");
     TeaService black = provider.getTeaService("black");
     
     System.out.println(green.produceTea()); 
     System.out.println(black.produceTea()); 
     
     //测试未注册服务
     try {
         provider.getTeaService("Service_test");
     } catch (IllegalArgumentException e) {
         System.out.println(e.getMessage()); 
     }
 }
}


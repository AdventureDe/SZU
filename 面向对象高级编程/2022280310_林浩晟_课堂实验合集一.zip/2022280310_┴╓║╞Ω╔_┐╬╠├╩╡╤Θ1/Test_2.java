package test_2;

// 基础类及 Builder
class Person {
    private final String name;
    private int age;
    private String location;
    private String job;
    private String gender;

    protected Person(Builder<?> builder) {
        this.name = builder.name;
        this.age = builder.age;
        this.location = builder.location;
        this.job = builder.job;
        this.gender = builder.gender;
    }

    @Override
    public String toString() {
        return "Person{" +
                "name='" + name + '\'' +
                ", age=" + age +
                ", location='" + location + '\'' +
                ", job='" + job + '\'' +
                ", gender='" + gender + '\'' +
                '}';
    }

    abstract static class Builder<T extends Builder<T>> {
        private final String name;
        private int age;
        private String location;
        private String job;
        private String gender;
        public Builder(String name) {
            this.name = name;
        }
        public T age(int age) {
            this.age = age;
            return self();
        }
        public T location(String location) {
            this.location = location;
            return self();
        }
        public T job(String job) {
            this.job = job;
            return self();
        }
        public T gender(String gender) {
            this.gender = gender;
            return self();
        }
        abstract Person build();
        protected abstract T self();
    }
}

// 高个子子类
class TallPerson extends Person {
    private final double height;
    private TallPerson(TallBuilder builder) {
        super(builder);
        this.height = builder.height;
    }
    @Override
    public String toString() {
        return super.toString() + ", TallPerson{height=" + height + "}";
    }
    public static class TallBuilder extends Person.Builder<TallBuilder> {
        private double height;
        public TallBuilder(String name) {
            super(name);
        }
        public TallBuilder height(double height) {
            this.height = height;
            return this;
        }
        @Override
        public TallPerson build() {
            return new TallPerson(this);
        }
        @Override
        protected TallBuilder self() {
            return this;
        }
    }
}

// 胖子子类
class FatPerson extends Person {
    private final double weight;
    private FatPerson(FatBuilder builder) {
        super(builder);
        this.weight = builder.weight;
    }
    @Override
    public String toString() {
        return super.toString() + ", FatPerson{weight=" + weight + "}";
    }
    public static class FatBuilder extends Person.Builder<FatBuilder> {
        private double weight;

        public FatBuilder(String name) {
            super(name);
        }
        public FatBuilder weight(double weight) {
            this.weight = weight;
            return this;
        }
        @Override
        public FatPerson build() {
            return new FatPerson(this);
        }
        @Override
        protected FatBuilder self() {
            return this;
        }
    }
}

class Test_2 {
    public static void main(String[] args) {
        TallPerson tall = new TallPerson.TallBuilder("张三")
                .age(30)
                .height(185.5)
                .job("工程师")
                .build();
        System.out.println(tall);

        FatPerson fat = new FatPerson.FatBuilder("李四")
                .weight(90.5)
                .location("北京")
                .gender("男")
                .build();
        System.out.println(fat);
    }
}

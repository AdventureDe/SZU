package test_3;

public class Emperor {
    //静态实例保证类加载时即初始化
    private static final Emperor INSTANCE = new Emperor();
    
    private Emperor(){
        // 防止反射攻击
        if (INSTANCE != null) {
            throw new IllegalStateException("皇帝已经存在");
        }
    }
    public static Emperor getInstance() {
        return INSTANCE;
    }
    
    public void rule() {
        System.out.println("1111");
    }
    // 验证单例特性
    public static void main(String[] args) {
        Emperor e1 = Emperor.getInstance();
        Emperor e2 = Emperor.getInstance();
      
        System.out.println("是否为同一皇帝：" + (e1 == e2)); // 输出 true
        System.out.println("哈希值对比：");
        System.out.println("e1.hashCode() = " + e1.hashCode());
        System.out.println("e2.hashCode() = " + e2.hashCode());
        e1.rule(); 
    }
}

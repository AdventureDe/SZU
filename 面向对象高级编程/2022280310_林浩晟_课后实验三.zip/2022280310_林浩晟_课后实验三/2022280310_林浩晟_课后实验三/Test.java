package temp;

import java.util.*;

public class Test {
    public static void main(String[] args) {
        // 创建一个 2x2 的 NumJa2DArray 实例
        NumJa.NumJa2DArray<Double> mat = new NumJa.NumJa2DArray<>(2, 2);
        mat.set(0, 0, 3.2);
        mat.set(0, 1, 4.1);//  3.2  4.1
        mat.set(1, 0, 1.9);//  1.9  0.5
        mat.set(1, 1, 0.5);
        NumJa.NumJa2DArray<Double> mat1 = new NumJa.NumJa2DArray<>(1, 2);
        mat1.set(0, 0, 6.0);
        mat1.set(0, 1, 1.4);// 6.0  1.4
        // concatenate
       mat1 = NumJa.NumJa2DArray.concatenate(mat, mat1, 0);
       for(int i = 0;i < mat1.rows;i++) {
    	   for(int j = 0;j < mat1.cols;j++) {
    		   System.out.print(mat1.get(i,j)+" ");
    	   }
    	   System.out.println(); 
       }
        // amin,amax
        List<Double> rowMins = NumJa.NumJa2DArray.amin(mat, 1);
        System.out.println("Min per row: " + rowMins);
        List<Double> colMax = NumJa.NumJa2DArray.amax(mat, 0);
        System.out.println("Max per column: " + colMax);
        // where
        System.out.println("Where < 2.0:");
        NumJa.NumJa2DArray.where(mat, x -> x < 2.0);
        System.out.println("Where > 4.0:"); 
        NumJa.NumJa2DArray.where(mat, x -> x > 4.0);
        // argsort
        List<int[]> sortedIndices = mat.argsort(1); 
        System.out.println("Argsort along axis 1:");
        for (int[] row : sortedIndices) {
            System.out.println(Arrays.toString(row));
        }

        Double[] flatArray = mat.toArray(0, Double.class);
        System.out.println("Flattened array: " + Arrays.toString(flatArray));
        System.out.println("Contains 4.1? " + mat.contains(4.1));
        System.out.println("Matrix size: " + Arrays.toString(mat.size()));
    }
}

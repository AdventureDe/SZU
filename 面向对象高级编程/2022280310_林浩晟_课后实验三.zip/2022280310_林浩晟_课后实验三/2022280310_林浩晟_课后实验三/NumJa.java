package temp;

import java.lang.reflect.Array;
import java.util.*;
import java.util.function.Predicate;

public class NumJa {
    public static class NumJa2DArray<E extends Comparable<E>> {
        private final Object[] data;
        final int rows; 
        final int cols;

        public NumJa2DArray(int rows, int cols) {
            this.rows = rows;
            this.cols = cols;
            this.data = new Object[rows * cols];
        }

        public void set(int row, int col, E value) {
            data[row * cols + col] = value;
        }

        @SuppressWarnings("unchecked")
        public E get(int row, int col) {
            return (E) data[row * cols + col];
        }
        public int[] size() {
            return new int[]{rows, cols};
        }
        public boolean contains(E e) {
            for (Object item : data) {
                if (Objects.equals(item, e)) return true;
            }
            return false;
        }
        @SuppressWarnings("unchecked")
        public E[] toArray(int axis, Class<E> clazz) {
            E[] result = (E[]) Array.newInstance(clazz, data.length);
            if (axis == 0) {
                System.arraycopy(data, 0, result, 0, data.length);
            } else {
                int index = 0;
                for (int col = 0; col < cols; col++) {
                    for (int row = 0; row < rows; row++) {
                        result[index++] = get(row, col);
                    }
                }
            }
            return result;
        }

        public List<int[]> argsort(int axis) {
            List<int[]> result = new ArrayList<>();
            if (axis == 0) {
                for (int col = 0; col < cols; col++) {
                    final int colIndex = col;
                    Integer[] indices = new Integer[rows];
                    for (int i = 0; i < rows; i++) 
                    	indices[i] = i;
                    Arrays.sort(indices, Comparator.comparing(i -> get(i, colIndex)));
                    result.add(Arrays.stream(indices).mapToInt(Integer::intValue).toArray());
                }

            } else if (axis == 1) {
                for (int row = 0; row < rows; row++) {
                    final int rowIndex = row;
                    Integer[] indices = new Integer[cols];
                    for (int i = 0; i < cols; i++) 
                    	indices[i] = i;
                    Arrays.sort(indices, Comparator.comparing(i -> get(rowIndex, i)));
                    result.add(Arrays.stream(indices).mapToInt(Integer::intValue).toArray());
                }
            }
            else {
            	throw new IllegalArgumentException("非法axis参数");
            }
            return result;
        }

        public static <E extends Comparable<E>> List<E> amin(NumJa2DArray<E> arr, int axis) {
            List<E> result = new ArrayList<>();
            if (axis == 0) {
                for (int col = 0; col < arr.cols; col++) {
                    E min = arr.get(0, col);
                    for (int row = 1; row < arr.rows; row++) {
                        if (arr.get(row, col).compareTo(min) < 0) 
                        	min = arr.get(row, col);
                    }
                    result.add(min);
                }
            } else if(axis == 1) {
                for (int row = 0; row < arr.rows; row++) {
                    E min = arr.get(row, 0);
                    for (int col = 1; col < arr.cols; col++) {
                        if (arr.get(row, col).compareTo(min) < 0) 
                        	min = arr.get(row, col); 
                    }
                    result.add(min);
                }
            }
            else {
            	throw new IllegalArgumentException("非法axis参数");
            }
            return result;
        }

        public static <E extends Comparable<E>> List<E> amax(NumJa2DArray<E> arr, int axis) {
            List<E> result = new ArrayList<>();
            if (axis == 0) {
                for (int col = 0; col < arr.cols; col++) {
                    E max = arr.get(0, col);
                    for (int row = 1; row < arr.rows; row++) {
                        if (arr.get(row, col).compareTo(max) > 0) 
                        	max = arr.get(row, col);
                    }
                    result.add(max);
                }
            } else if(axis == 1) {
                for (int row = 0; row < arr.rows; row++) {
                    E max = arr.get(row, 0);
                    for (int col = 1; col < arr.cols; col++) {
                        if (arr.get(row, col).compareTo(max) > 0) 
                        	max = arr.get(row, col);
                    }
                    result.add(max);
                }
            }
            else {
            	throw new IllegalArgumentException("非法axis参数");
            }
            return result;
        }

        public static <E extends Comparable<E>> NumJa2DArray<E> concatenate(
                NumJa2DArray<E> a, NumJa2DArray<E> b, int axis) {
            if (axis == 0) {
                if (a.cols != b.cols) 
                	throw new IllegalArgumentException("列数不一致");
                NumJa2DArray<E> res = new NumJa2DArray<>(a.rows + b.rows, a.cols);
                for (int i = 0; i < a.rows; i++)
                    for (int j = 0; j < a.cols; j++) 
                    	res.set(i, j, a.get(i, j));
                for (int i = 0; i < b.rows; i++)
                    for (int j = 0; j < b.cols; j++) 
                    	res.set(i + a.rows, j, b.get(i, j));
                return res;
            } else if (axis == 1) {
                if (a.rows != b.rows) 
                	throw new IllegalArgumentException("行数不一致");
                NumJa2DArray<E> res = new NumJa2DArray<>(a.rows, a.cols + b.cols);
                for (int i = 0; i < a.rows; i++) {
                    for (int j = 0; j < a.cols; j++) 
                    	res.set(i, j, a.get(i, j));
                    for (int j = 0; j < b.cols; j++)
                    	res.set(i, j + a.cols, b.get(i, j));
                }
                return res;
            }
            throw new IllegalArgumentException("非法axis参数");
        }
        
        public static <E extends Comparable<E>> void where(
                NumJa2DArray<E> arr, Predicate<E> condition) {
            List<Integer> rowIndices = new ArrayList<>();
            List<Integer> colIndices = new ArrayList<>();

            for (int i = 0; i < arr.rows; i++) {
                for (int j = 0; j < arr.cols; j++) {
                    if (condition.test(arr.get(i, j))) {
                        rowIndices.add(i);
                        colIndices.add(j);
                    }
                }
            }
            System.out.print("(array([");
            for (int i = 0; i < rowIndices.size(); i++) {
                System.out.print(rowIndices.get(i));
                if (i != rowIndices.size() - 1) System.out.print(", ");
            }
            System.out.print("]), array([");
            for (int i = 0; i < colIndices.size(); i++) {
                System.out.print(colIndices.get(i));
                if (i != colIndices.size() - 1) System.out.print(", ");
            }
            System.out.println("]))");
        }
    }
}

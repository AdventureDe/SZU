package t1;
import java.util.*;

interface Solve<T>{
    T solve(T mat);
}

interface Decompose<T>{
    T[] decompose();
}

interface SVDSolve<T> extends Solve<T>, Decompose<T> {
    T compute(T mat);
    void SVD();
    T getU();
    T getSigma();
    T getV();
}

class DenseMatrix implements SVDSolve<DenseMatrix>{
    private double[][] data;
    private int rows, cols;
    public DenseMatrix(int rows, int cols){
        this.rows = rows;
        this.cols = cols;
        data = new double[rows][cols];
    }
    public void setValue(int row, int col, double value){
        data[row][col] = value;
    }

    public double getValue(int row, int col){
        return data[row][col];
    }

    public int rows(){
        return rows;
    }
    public int cols(){
        return cols;
    }

    @Override
    public DenseMatrix solve(DenseMatrix mat){
    	System.out.println("求解矩阵，稠密矩阵");
        return mat;
    }
    @Override
    public DenseMatrix[] decompose(){
    	System.out.println("分解矩阵，稠密矩阵");
        return new DenseMatrix[]{this, this};
    }
    @Override
    public DenseMatrix compute(DenseMatrix mat){
        System.out.println("计算矩阵，稠密矩阵");
        SVD();
        return this;
    }

    @Override
    public void SVD() {
        System.out.println("SVD分解，稠密矩阵");
    }
    @Override
    public DenseMatrix getU(){
    	System.out.println("getU");
        return this;
    }
    @Override
    public DenseMatrix getSigma(){
    	System.out.println("getSigma");
        return this;
    }
    @Override
    public DenseMatrix getV() {
    	System.out.println("getV");
        return this;
    }

    @Override
    public String toString(){
        StringBuilder sb = new StringBuilder();
        for (double[] row : data) {
            sb.append(Arrays.toString(row)).append("\n");
        }
        return sb.toString();
    }
    @Override
    public boolean equals(Object obj){
        if (this == obj) return true;
        if (!(obj instanceof DenseMatrix)) return false;
        DenseMatrix other = (DenseMatrix) obj;
        return Arrays.deepEquals(this.data, other.data);
    }
    @Override
    public int hashCode(){
        return Arrays.deepHashCode(data);
    }
}

class ConstMatrix {
    public static final DenseMatrix PAULI_MATRIX = new DenseMatrix(2, 2);
    static {
        PAULI_MATRIX.setValue(0, 0, 0);
        PAULI_MATRIX.setValue(0, 1, 1);
        PAULI_MATRIX.setValue(1, 0, 1);
        PAULI_MATRIX.setValue(1, 1, 0);
    }
}

interface Sparse {
    void addElement(int i, int j, double value);
    int NonZeroCount();
    boolean IsCompressed();
}

abstract class SparseMap implements Sparse {
    List<double[]> elements = new ArrayList<>();
    @Override
    public void addElement(int i, int j, double value) {
        elements.add(new double[]{i, j, value});
    }
    @Override
    public int NonZeroCount(){
        return elements.size();
    }
}

class SparseCompressed extends SparseMap{
    private boolean compressed = false;

    public void compress() {
        compressed = true;
        System.out.println("矩阵已压缩！");
    }
    @Override
    public boolean IsCompressed() {
        return compressed;
    }
}

class SparseMatrix extends SparseMap implements SVDSolve<SparseMatrix> {
    @Override
    public SparseMatrix solve(SparseMatrix mat){
        System.out.println("求解矩阵，稀疏矩阵");
        return mat;
    }
    @Override
    public SparseMatrix[] decompose(){
        System.out.println("分解矩阵，稀疏矩阵");
        return new SparseMatrix[] {this, this}; 
    }
    @Override
    public SparseMatrix compute(SparseMatrix mat){
        System.out.println("计算矩阵，稀疏矩阵");
        return this;
    }
    @Override
    public void SVD(){
        System.out.println("SVD函数，稀疏矩阵");
    }
    @Override
    public SparseMatrix getU(){
    	System.out.println("getU");
        return this;
    }
    @Override
    public SparseMatrix getSigma(){
    	System.out.println("getSigma");
        return this;
    }
    @Override
    public SparseMatrix getV(){
    	System.out.println("getV");
        return this;
    }
	@Override
	public boolean IsCompressed(){
		return false;
	}
}

class HilbertMatrix {
    DenseMatrix matrix;
    int size;
    public HilbertMatrix(int size){
        this.size = size;
        matrix = new DenseMatrix(size, size);
        for (int i = 0; i < size; i++)
        {
            for (int j = 0; j < size; j++){
                matrix.setValue(i, j, 1.0 / (i + j + 1));
            }
        }
    }
    public double getValue(int row, int col){
        return matrix.getValue(row, col);
    }
    public int rows(){
        return size;
    }
    public int cols(){
        return size;
    }
    public void cholesky(){
        System.out.println("cholesky分解");
    }
}  
 
public class Test {
    public static void main(String[] args) {
        //测试 DenseMatrix
        System.out.println("测试DenseMatrix:");
        DenseMatrix dense = new DenseMatrix(3, 3);
        dense.setValue(0, 0, 1.0);
        dense.setValue(1, 1, 2.0);
        dense.setValue(2, 2, 3.0);
        System.out.println("DenseMatrix:\n" + dense);
        //调用 DenseMatrix 的 SVD 操作
        dense.compute(dense);
        dense.getU();
        dense.getSigma();
        dense.getV();
        dense.solve(dense);
        dense.decompose();
        System.out.println("-------------------------------------------------------------------------");
        //测试 SparseMatrix
        System.out.println("测试SparseMatrix:");
        SparseMatrix sparse = new SparseMatrix();
        sparse.addElement(0, 1, 5.0);
        sparse.addElement(2, 2, 3.0);
        System.out.println("Non-zero count = " + sparse.NonZeroCount());
        //调用 SparseMatrix 的 SVD 操作
        sparse.compute(sparse);
        sparse.getU();
        sparse.getSigma();
        sparse.getV();
        sparse.solve(sparse);
        sparse.decompose();
        System.out.println("-------------------------------------------------------------------------");
        //测试 HilbertMatrix
        System.out.println("测试HilbertMatrix:");
        HilbertMatrix hilbert = new HilbertMatrix(5);
        System.out.println("Value at (2,2): " + hilbert.getValue(2, 2));
        hilbert.cholesky();
    }
}


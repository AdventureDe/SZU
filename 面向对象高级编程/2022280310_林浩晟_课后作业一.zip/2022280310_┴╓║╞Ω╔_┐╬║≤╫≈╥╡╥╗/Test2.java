package kewai2;

import java.util.*;

interface Component 
{
    void function();
}
abstract class SmartDevice implements Component{
    protected boolean deviceStatus = false;
    public void toggleStatus()
    {
        deviceStatus = !deviceStatus;
        System.out.println(getClass().getSimpleName() + "现在是" + (deviceStatus ? "开的" : "关的"));
    } 
} 
class SmartLight extends SmartDevice {
    private int brightness = 50;
    public void setBrightness(int level) {
        if (level >= 0 && level <= 100) {
            brightness = level;
            System.out.println("灯亮度设置为" + brightness + "%");
        } else {
            System.out.println("错误的亮度设置");
        }
    }
    @Override
    public void function() {
        System.out.println("灯提供光亮。");
    }
}

class SmartDoor extends SmartDevice{
    private static SmartDoor instance;
    private SmartDoor() {}

    public static SmartDoor getInstance() {
        if (instance == null) {
            instance = new SmartDoor();
        }
        return instance;
    }
    @Override
    public void function() {
        System.out.println("门提供安全感。");
    }
}
class SmartHomeSystem {
    private List<Component> components = new ArrayList<>();
    public void addComponent(Component component) {
        components.add(component);
    }
    public void operateAll() {
        for (Component component : components) {
            component.function();
        }
    }
}
class DeviceFactory {
    public static SmartDevice createDevice(String type) {
        switch (type.toLowerCase()) {
            case "light":
                return new SmartLight();
            case "door":
                return SmartDoor.getInstance();
            default:
                throw new IllegalArgumentException("未知的类型");
        }
    }
}
public class Test2 {
    public static void main(String[] args) {
        SmartHomeSystem homeSystem = new SmartHomeSystem();
        
        SmartLight light = (SmartLight) DeviceFactory.createDevice("light");
        SmartDoor door = (SmartDoor) DeviceFactory.createDevice("door");
        
        homeSystem.addComponent(light);
        homeSystem.addComponent(door);
        
        homeSystem.operateAll();
        
        light.toggleStatus();
        light.setBrightness(80);
        
        door.toggleStatus();
    }
}

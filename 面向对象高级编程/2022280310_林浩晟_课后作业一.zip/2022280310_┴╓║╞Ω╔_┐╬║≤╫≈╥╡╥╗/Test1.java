package kewai1;

import java.util.*;

abstract class SmartWatch implements Cloneable, Comparable<SmartWatch>{
    protected String mBrand;
    protected int mBatteryLife;
    protected boolean mWaterResistant;
    protected ArrayList<String> mSensors;

    protected SmartWatch(Builder<?> builder) {
        this.mBrand = builder.mBrand;
        this.mBatteryLife = builder.mBatteryLife;
        this.mWaterResistant = builder.mWaterResistant;
        this.mSensors = new ArrayList<>(builder.mSensors);
    }

    public abstract static class Builder<T extends Builder<T>>
    {
        private String mBrand;
        private int mBatteryLife;
        private boolean mWaterResistant;
        private ArrayList<String> mSensors = new ArrayList<>();
        public T setBrand(String brand) {
            this.mBrand = brand;
            return self();
        }
        public T setBatteryLife(int batteryLife) {
            this.mBatteryLife = batteryLife;
            return self();
        }
        public T setWaterResistant(boolean waterResistant) {
            this.mWaterResistant = waterResistant;
            return self();
        }
        public T addSensor(String sensor) {
            this.mSensors.add(sensor);
            return self();
        }
        protected abstract T self();
        public abstract SmartWatch build();
    }

    @Override
    public String toString() {
        return "SmartWatch{" +
                "Brand='" + mBrand + '\'' +
                ", BatteryLife=" + mBatteryLife +
                ", WaterResistant=" + mWaterResistant +
                ", Sensors=" + mSensors +
                '}';
    }
    @Override
    public SmartWatch clone() {
        try {
            SmartWatch cloned = (SmartWatch) super.clone();
            cloned.mSensors = new ArrayList<>(this.mSensors);
            return cloned;
        } catch (CloneNotSupportedException e) {
            throw new AssertionError();
        }
    }
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (!(obj instanceof SmartWatch)) return false;
        SmartWatch that = (SmartWatch) obj;
        return mBatteryLife == that.mBatteryLife &&
                mWaterResistant == that.mWaterResistant &&
                Objects.equals(mBrand, that.mBrand) &&
                Objects.equals(mSensors, that.mSensors);
    }

    @Override
    public int hashCode() {
        return Objects.hash(mBrand, mBatteryLife, mWaterResistant, mSensors);
    }
    @Override
    public int compareTo(SmartWatch other) {
        return Integer.compare(other.mBatteryLife, this.mBatteryLife);
    }
}

class FitnessWatch extends SmartWatch{
    private boolean mGPS;
    private FitnessWatch(Builder builder) {
        super(builder);
        this.mGPS = builder.mGPS;
    }
    public static class Builder extends SmartWatch.Builder<Builder> {
        private boolean mGPS;
        public Builder setGPS(boolean gps){
            this.mGPS = gps;
            return this;
        }
        @Override
        protected Builder self() {
            return this;
        }
        @Override
        public FitnessWatch build() {
            return new FitnessWatch(this);
        }
    }
    @Override
    public String toString(){
        return super.toString() + ", GPS=" + mGPS;
    }
    @Override
    public boolean equals(Object obj) {
        if (!super.equals(obj)) return false;
        if (!(obj instanceof FitnessWatch)) return false;
        FitnessWatch that = (FitnessWatch) obj;
        return mGPS == that.mGPS;
    }
    @Override
    public int hashCode(){
        return Objects.hash(super.hashCode(), mGPS);
    }
}

class FashionWatch extends SmartWatch{
    private String mMaterial;
    private FashionWatch(Builder builder) {
        super(builder);
        this.mMaterial = builder.mMaterial;
    }
    public static class Builder extends SmartWatch.Builder<Builder> {
        private String mMaterial;

        public Builder setMaterial(String material) {
            this.mMaterial = material;
            return this;
        }
        @Override
        protected Builder self() {
            return this;
        }
        @Override
        public FashionWatch build() {
            return new FashionWatch(this);
        }
    }
    @Override
    public String toString(){
        return super.toString() + ", Material='" + mMaterial + '\'';
    }
    @Override
    public boolean equals(Object obj) {
        if (!super.equals(obj)) return false;
        if (!(obj instanceof FashionWatch)) return false;
        FashionWatch that = (FashionWatch) obj;
        return Objects.equals(mMaterial, that.mMaterial);
    }
    @Override
    public int hashCode(){
        return Objects.hash(super.hashCode(), mMaterial);
    }
}

public class Test1 {
    public static void main(String[] args) {
        FitnessWatch fitnessWatch =new FitnessWatch.Builder()
                .setBrand("FitPro")
                .setBatteryLife(24)
                .setWaterResistant(true)
                .addSensor("Heart Rate")
                .setGPS(true)
                .build();

        FashionWatch fashionWatch=new FashionWatch.Builder()
                .setBrand("StyleX")
                .setBatteryLife(48)
                .setWaterResistant(false)
                .addSensor("Temperature")
                .setMaterial("Stainless Steel")
                .build();

        System.out.println(fitnessWatch);
        System.out.println(fashionWatch);

        System.out.println("一样吗" + fitnessWatch.equals(fashionWatch));

        List<SmartWatch> watche=Arrays.asList(fitnessWatch, fashionWatch);
        Collections.sort(watche);
        System.out.println(watche);
    }
}

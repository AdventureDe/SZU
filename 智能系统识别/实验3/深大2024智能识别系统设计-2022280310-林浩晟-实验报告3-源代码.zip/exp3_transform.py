import cv2
import numpy as np
import os
"""
    使用 HSV 空间调整图片亮度
    :param image: 输入图像
    :param delta: 亮度变化值 (正值提亮，负值调暗)
    :return: 调整后的图像
    """
def adjust_hsv_brightness(image, delta=0):
    if image is None:
        raise ValueError("oops")
    hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)
    h, s, v = cv2.split(hsv)
    # 确保亮度调整不超过 uint8 范围
    v = np.clip(v.astype(np.int16) + delta, 0, 255).astype(np.uint8)
    # 确保合并的通道尺寸一致
    if h.shape == s.shape == v.shape:
        hsv = cv2.merge((h, s, v))
    else:
        raise ValueError("HSV channel dimensions do not match.")

    return cv2.cvtColor(hsv, cv2.COLOR_HSV2BGR)


def process_images(input_folder, output_folder, delta):
    if not os.path.exists(output_folder):
        os.makedirs(output_folder)
    for filename in os.listdir(input_folder):
        input_path = os.path.join(input_folder, filename)
        output_path = os.path.join(output_folder, filename)

        if filename.lower().endswith(('.png', '.jpg')):
            image = cv2.imread(input_path)
            if image is not None:
                try:
                    adjusted_image = adjust_hsv_brightness(image, delta=delta)
                    cv2.imwrite(output_path, adjusted_image)
                    print(f"Processed {filename}")
                except ValueError as e:
                    print(f"Error processing {filename}: {e}")
            else:
                print(f"Failed to load image: {filename}")

# 文件夹路径
input_folder = r"D:/pythonprogram/OpenCV/exp3/common/"
output_folder_bright = r"D:/pythonprogram/OpenCV/exp3/bright/"
output_folder_dark = r"D:/pythonprogram/OpenCV/exp3/dark/"

# 调整亮度
process_images(input_folder, output_folder_bright, delta=50)  # 提亮
process_images(input_folder, output_folder_dark, delta=-120)  # 调暗

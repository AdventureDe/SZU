from facenet_pytorch import MTCNN
import cv2
import numpy as np
import torch

# 初始化 Fast-MTCNN
mtcnn = MTCNN(keep_all=True, device='cuda' if torch.cuda.is_available() else 'cpu')

def detect_faces(image_path):
    image = cv2.imread(image_path)# 读取图像
    image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)# 转换为 RGB 格式
    boxes, probs, landmarks = mtcnn.detect(image_rgb, landmarks=True)#检测人脸
    #其中
    # boxes：人脸的边界框，形如 [x1, y1, x2, y2]。
    #probs：检测到每个人脸的置信度。
    #landmarks：关键点坐标，包含左眼、右眼、鼻尖、左嘴角、右嘴角。
    if boxes is not None:#确保上述正确执行
        for box, landmark in zip(boxes, landmarks):# 标记 人脸用绿色 关键点用红色
            x1, y1, x2, y2 = [int(v) for v in box]
            cv2.rectangle(image, (x1, y1), (x2, y2), (0, 255, 0), 2)
            for (x, y) in landmark:
                cv2.circle(image, (int(x), int(y)), 2, (0, 0, 255), -1)
    # 显示结果图像
    cv2.imshow("Detected Faces", image)
    cv2.waitKey(0)
    cv2.destroyAllWindows()
    return landmarks  #用于提取仿射变换

def align_face(image_path, landmarks):
    image = cv2.imread(image_path)
    # 确保提取的是 landmarks 的第一个人脸的关键点
    if len(landmarks) > 0:
        landmark = landmarks[0]  # 选取第一个检测到的人脸的关键点
        # 提取左眼、右眼和鼻尖的坐标
        src_points = np.array([
            landmark[0][:2],  # 左眼
            landmark[1][:2],  # 右眼
            landmark[2][:2], # 鼻尖
            landmark[3][:3],# 左嘴角
            landmark[4][:4]# 右嘴角
        ], dtype=np.float32)
        # 定义目标位置 (例如：将眼睛和鼻子映射到特定位置)
        dst_points = np.array([
            [30.2946, 51.6963],  # 左眼
            [65.5318, 51.5014],  # 右眼
            [48.0252, 71.7366],  # 鼻尖
            [33.5493, 92.3655],  # 左嘴角
            [62.7299, 92.2041]   # 右嘴角
        ], dtype=np.float32)

        # 计算仿射变换矩阵
        M, _ = cv2.estimateAffinePartial2D(src_points, dst_points)

        # 对图像进行仿射变换
        aligned_face = cv2.warpAffine(image, M, (96, 112))
        cv2.imshow("Aligned Face", aligned_face)
        cv2.waitKey(0)
        cv2.destroyAllWindows()

        return aligned_face
    else:
        print("oops")
        return None


# 执行流程
image_path = r"D:/pythonprogram/OpenCV/exp3/common/0206.jpg"
landmarks = detect_faces(image_path)

if landmarks is not None:#确保输出的关键点不为空
    # 进行人脸对齐
    aligned_face = align_face(image_path, landmarks)

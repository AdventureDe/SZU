from facenet_pytorch import MTCNN
import cv2
import numpy as np
import torch
import os
# 初始化 Fast-MTCNN
mtcnn = MTCNN(keep_all=True, device='cuda' if torch.cuda.is_available() else 'cpu')


def detect_faces(image_path):
    image = cv2.imread(image_path)
    image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    boxes, probs, landmarks = mtcnn.detect(image_rgb, landmarks=True)

    if boxes is not None:
        for box, landmark in zip(boxes, landmarks):
            x1, y1, x2, y2 = [int(v) for v in box]
            cv2.rectangle(image, (x1, y1), (x2, y2), (0, 255, 0), 2)
            for (x, y) in landmark:
                cv2.circle(image, (int(x), int(y)), 2, (0, 0, 255), -1)

    # 显示原始图像（包含框和关键点）
    cv2.imshow("Detected Faces", image)
    cv2.waitKey(0)
    cv2.destroyAllWindows()
    return image, boxes, landmarks

def process(folder):
    for file in os.listdir(folder):
        path=os.path.join(folder,file)
        if file.lower().endswith((".jpg",".png")) :
            image=cv2.imread(path)
            if image is not None:
                try:
                    detect_faces(path)
                except ValueError:
                    print("oops")
        else:
            print(f"Failed to load image: {filename}")

folder=r"D:/pythonprogram/OpenCV/exp3/common/"
process(folder)


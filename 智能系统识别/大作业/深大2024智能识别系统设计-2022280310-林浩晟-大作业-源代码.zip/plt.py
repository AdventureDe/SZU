import matplotlib.pyplot as plt
from matplotlib import rcParams

# Adjust default font settings for better readability in publications
rcParams['font.sans-serif'] = ['SimHei']  # To display Chinese characters
rcParams['axes.unicode_minus'] = False  # To display minus signs correctly
rcParams['font.size'] = 14  # Set font size for readability

# 数据
groups = ['平凡数据组','低模糊度组', '高模糊度组', '强光照组', '弱光照组']
precision = [0.8337, 0.8597, 0.8223, 0.8369, 0.7776]
avg_detection_time = [0.4456, 0.4532, 0.4712, 0.4432, 0.4823]  # 平均处理时间（单位：秒）


# 创建图形与两个y轴
fig, ax1 = plt.subplots(figsize=(8, 6))

# 绘制精确率的条形图，调整条形宽度
ax1.bar(groups, precision, color=['#1f77b4', '#ff7f0e', '#2ca02c', '#d62728', '#9467bd'],
        edgecolor='black', linewidth=1.2, width=0.8)  # 设置条形图宽度为 0.6

# 设置左侧纵轴（精确率）标签
ax1.set_xlabel('测试组', fontsize=16)
ax1.set_ylabel('精确率', color='black', fontsize=16)
ax1.set_title('不同组别精确率与平均处理时间对比', fontsize=18)

# 添加网格线，优化可读性
ax1.grid(True, axis='y', linestyle='dotted', linewidth=0.7, alpha=0.7)

# 创建第二个纵轴（共享x轴）
ax2 = ax1.twinx()

# 绘制平均处理时间的折线图
ax2.plot(groups, avg_detection_time, color='purple', marker='o', linestyle='-', linewidth=2, label='平均处理时间（秒）')

# 设置右侧纵轴（平均处理时间）标签
ax2.set_ylabel('平均处理时间（秒）', color='purple', fontsize=14)

# 添加右侧y轴的网格线
ax2.grid(True, axis='y', linestyle='--', linewidth=0.7, alpha=0.7)

# 设置x轴和y轴的标签字体大小
ax1.tick_params(axis='both', labelsize=14)
ax2.tick_params(axis='y', labelsize=14)

# 添加图例
ax2.legend(loc='upper left', bbox_to_anchor=(1.05, 1.05), fontsize=14)  # 将图例放在图表右侧

# 显示图表
plt.tight_layout()  # 优化布局以防止标签重叠
plt.show()

import cv2
import os
import sys
import numpy as np
import time
from paddleocr import PaddleOCR, draw_ocr

os.environ['TESSDATA_PREFIX'] = r'D:/Tesseract-OCR'

#预处理
def pre_process(image):
    gray_image=cv2.cvtColor(image,cv2.COLOR_BGR2GRAY);#转为灰化图
    #均值模糊处理 去除小的噪声，平滑图像
    blur_image=cv2.blur(gray_image,(3,3))
    #提取边缘特征
    sobel_image=cv2.Sobel(blur_image,cv2.CV_16S,1,0,ksize=3)
    sobel_image=cv2.convertScaleAbs(sobel_image)
    #分离hsv色彩通道
    hsv_image=cv2.cvtColor(image,cv2.COLOR_BGR2HSV)
    h,s,v=hsv_image[:,:,0],hsv_image[:,:,1],hsv_image[:,:,2]

    #根据内地车牌的特征设置限制(新能源车牌  白色渐变为绿色)
    color_image=(((h > 26) & (h < 34)) | ((h > 100) & (h < 124))|((h > 30) & (h < 110))) & (s > 70) & (v > 70)
    color_image=color_image.astype('float32')#提取与限制相符的图片
    #将sobel边缘检测结果与提取的颜色区域相乘，生成符合条件的边缘特征
    out_image=np.multiply(sobel_image,color_image)
    out_image=out_image.astype(np.uint8)
    #Otsu二值化
    ret,binary_image=cv2.threshold(out_image,0,255,cv2.THRESH_BINARY | cv2.THRESH_OTSU)
    #闭运算  填补小间隙，连接断开的区域
    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (30, 10))
    close_image = cv2.morphologyEx(binary_image, cv2.MORPH_CLOSE, kernel)
    # 调试
    # cv2.imshow("closed_image",color_image)
    # cv2.waitKey(0)
    # cv2.destroyAllWindows()
    return close_image

# 漫水填充函数
def flood_fill(rect, image, lower_thresh=100, upper_thresh=255):
    """
    漫水填充算法，用于车牌区域填充。

    参数：
    rect: 车牌区域的最小外接矩形
    image: 输入的图像
    lower_thresh: 填充的最小阈值（可调）
    upper_thresh: 填充的最大阈值（可调）
    """
    # 获取矩形的四个顶点
    box = cv2.boxPoints(rect)
    box = box.astype(np.int32)
    # 在车牌区域进行填充
    mask = np.zeros((image.shape[0] + 2, image.shape[1] + 2), dtype=np.uint8)  # 修正掩码的大小
    flood_fill_result = cv2.floodFill(image, mask, (int(rect[0][0]), int(rect[0][1])), (255, 255, 255),
                                      (lower_thresh,) * 3, (upper_thresh,) * 3, flags=4)
    return flood_fill_result[1]  # 返回填充后的图像

# 霍夫变换函数
def apply_hough_transform(license_plate_image):
    """
    对车牌区域应用霍夫变换，检测车牌的直线边界。

    参数：
    license_plate_image: 提取出的车牌图像
    """
    # 转为灰度图像
    gray = cv2.cvtColor(license_plate_image, cv2.COLOR_BGR2GRAY)
    # 应用Canny边缘检测
    edges = cv2.Canny(gray, 50, 150, apertureSize=3)

    # 使用霍夫变换检测直线
    lines = cv2.HoughLinesP(edges, 1, np.pi / 180, threshold=100, minLineLength=100, maxLineGap=10)

    if lines is not None:
        for line in lines:
            x1, y1, x2, y2 = line[0]
            cv2.line(license_plate_image, (x1, y1), (x2, y2), (0, 255, 0), 2)  # 绘制检测到的直线

    return license_plate_image


def locate_licensePlate(original_image, pre_image):
    """
    从预处理后的图像中定位车牌区域，并应用漫水填充和霍夫变换。
    """
    contours, _ = cv2.findContours(pre_image, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    aspect_ratio_min = 2.0  # 长宽比最小值
    aspect_ratio_max = 5.0  # 长宽比最大值

    min_area = 2000  # 面积阈值，用于排除噪声
    max_area = 30000
    plates = []

    for contour in contours:
        rect = cv2.minAreaRect(contour)
        box = cv2.boxPoints(rect)
        box = box.astype(np.int32)

        width = rect[1][0]
        height = rect[1][1]
        aspect_ratio = max(width, height) / min(width, height) if min(width, height) != 0 else 0
        area = cv2.contourArea(contour)

        # 筛选条件：长宽比和面积
        if aspect_ratio_min <= aspect_ratio <= aspect_ratio_max and min_area <= area <= max_area:
            x, y, w, h = cv2.boundingRect(box)
            imagecopy = original_image.copy()
            temp = imagecopy[y:y + h, x:x + w]

            # 应用漫水填充
            filled_image = flood_fill(rect, imagecopy)

            # 应用霍夫变换检测车牌边界
            hough_image = apply_hough_transform(filled_image)

            plates.append(rect)
            cv2.drawContours(original_image, [box], -1, (0, 0, 255), 2)
            # 调试
            # cv2.imshow("Hough Transformed Plate", hough_image)
            # cv2.waitKey(0)

    # 显示结果 调试
    # cv2.imshow("Detected Plates with Flood Fill and Hough Transform", original_image)
    # cv2.waitKey(0)
    # cv2.destroyAllWindows()
    return plates

def extract_char(license_image):
    # 初始化 PaddleOCR（使用中文和英文模型）
    ocr = PaddleOCR(use_angle_cls=True, lang='ch')
    # OCR 识别
    enhanced_image=enhance_image(license_image)
    # cv2.imshow("Enhanced image",enhanced_image)
    # cv2.waitKey(0)
    result = ocr.ocr(enhanced_image, cls=True)
    # 打印结果
    for line in result[0]:
        print(f"车牌号: {line[1][0]}，置信度: {line[1][1]}")

def enhance_image(image):
    denoised = cv2.bilateralFilter(image, 9, 75, 75)

    gray = cv2.cvtColor(denoised, cv2.COLOR_BGR2GRAY)

    clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
    enhanced_contrast = clahe.apply(gray)

    kernel = np.array([[0, -1, 0],
                       [-1, 5, -1],
                       [0, -1, 0]])
    sharpened = cv2.filter2D(enhanced_contrast, -1, kernel)

    enhanced_image = cv2.cvtColor(sharpened, cv2.COLOR_GRAY2BGR)
    return enhanced_image

def license_identity( image_path):
    image=cv2.imread(image_path)
    imagecopy=image.copy()
    pre_image=pre_process(image)
    license_plate_rect=locate_licensePlate(image,pre_image)

    for rect in license_plate_rect:
        box = cv2.boxPoints(rect)  # 获取矩形四个顶点
        box = box.astype(np.int32)
        x, y, w, h = cv2.boundingRect(box)
        aerror=10
        temp = imagecopy[y-aerror:y+h+aerror, x-aerror:x+w+aerror]
        #test=cv2.imread(r"D:/pythonprogram/OpenCV/Ten car images/car7.bmp")
        # 调试
        # cv2.imshow("Cut image",temp)
        # cv2.waitKey(0)
        extract_char(temp)

# main
# img=r"D:/CCPD2020/ccpd_green/test/04-90_267-207&511_555&616-550&605_211&616_207&515_555&511-0_0_3_1_26_30_31_30-68-81.jpg"
# start_time = time.time()
# for i in range(100):
#     license_identity(img)
# end_time = time.time()
# time=end_time-start_time
# aver=time/100
# print(aver)
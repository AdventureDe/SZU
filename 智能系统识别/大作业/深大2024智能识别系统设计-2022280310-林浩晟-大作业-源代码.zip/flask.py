from flask import Flask, request, jsonify
import os
import shutil

app = Flask(__name__)

# 存储上传的文件或文件夹的目录
UPLOAD_FOLDER = 'uploads/'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

# 允许的文件类型
ALLOWED_EXTENSIONS = {'jpg', 'jpeg', 'png'}

# 判断文件扩展名是否允许
def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

# 上传文件接口
@app.route('/upload', methods=['POST'])
def upload_file():
    # 检查是否有文件上传
    if 'file' not in request.files:
        return jsonify({"error": "没有文件上传"}), 400

    file = request.files['file']
    if file.filename == '':
        return jsonify({"error": "没有选择文件"}), 400

    # 检查文件是否允许
    if file and allowed_file(file.filename):
        filename = file.filename
        file_path = os.path.join(UPLOAD_FOLDER, filename)
        file.save(file_path)

        # 进行车牌识别（此处可以调用你已有的车牌识别方法）
        license_plate = recognize_license_plate(file_path)

        return jsonify({"message": "文件上传成功", "license_plate": license_plate})
    else:
        return jsonify({"error": "不支持的文件类型"}), 400


# 上传文件夹接口
@app.route('/upload_folder', methods=['POST'])
def upload_folder():
    # 检查是否上传了文件夹
    if 'folder' not in request.files:
        return jsonify({"error": "没有文件夹上传"}), 400

    folder = request.files.getlist('folder')

    # 遍历上传的文件并保存
    folder_path = os.path.join(UPLOAD_FOLDER, 'folder')
    os.makedirs(folder_path, exist_ok=True)

    for file in folder:
        if file and allowed_file(file.filename):
            filename = file.filename
            file_path = os.path.join(folder_path, filename)
            file.save(file_path)

    # 在此可以进行批量车牌识别处理
    license_plates = process_folder(folder_path)

    return jsonify({"message": "文件夹上传成功", "license_plates": license_plates})


# 车牌识别功能（假设你已经实现了识别逻辑）
def recognize_license_plate(image_path):
    # 在此调用车牌识别代码并返回车牌号
    return "川A12345"  # 这是一个模拟的结果，替换为实际的识别代码


# 批量处理文件夹中的图片
def process_folder(folder_path):
    license_plates = []
    for filename in os.listdir(folder_path):
        file_path = os.path.join(folder_path, filename)
        if allowed_file(filename):
            plate = recognize_license_plate(file_path)
            license_plates.append(plate)
    return license_plates


if __name__ == '__main__':
    app.run(debug=True)

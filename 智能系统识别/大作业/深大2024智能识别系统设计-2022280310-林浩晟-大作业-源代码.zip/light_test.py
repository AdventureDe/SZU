import os
import re
import math
from LicensePlateIdentity import license_identity
# test
provinces = ["皖", "沪", "津", "渝", "冀", "晋", "蒙", "辽", "吉", "黑", "苏", "浙", "京", "闽", "赣", "鲁", "豫", "鄂", "湘", "粤", "桂", "琼", "川", "贵", "云", "藏", "陕", "甘", "青", "宁", "新", "警", "学", "O"]
alphabets = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'J', 'K', 'L', 'M', 'N', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W',
             'X', 'Y', 'Z', 'O']
ads = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'J', 'K', 'L', 'M', 'N', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X',
       'Y', 'Z', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'O']

def count_files_in_directory(directory_path):
    # 获取文件夹中的所有文件和文件夹
    files = [f for f in os.listdir(directory_path) if os.path.isfile(os.path.join(directory_path, f))]
    return len(files)

def parse_filename(filename):
    """
    解析CCPD数据集文件名，提取相关信息。
    """
    # 去掉文件扩展名
    filename_without_extension = filename.split('.')[0]

    # 先按 '-' 分割文件名
    split_data = filename_without_extension.split('-')

    # 打印分割后的数据（可以用来调试查看结果）
    #print("Split Data:", split_data)

    if split_data:
        area = split_data[0]
        tilt = split_data[1]
        bbox_coords = split_data[2]
        four_corners = split_data[3]
        plate_str = split_data[4]
        light = split_data[5]
        blur = split_data[6]
        return {
            "Area": area,
            "Tilt": tilt,
            "Bounding Box Coordinates": bbox_coords,
            "Four Corners": four_corners,
            "Plate Str": plate_str,
            "Light": light,
            "Blur": blur
        }
    else:
        print(f"Error parsing file name: {filename}")
        return None

def test_license_plate_recognition(dataset_path):
    """
    测试数据集中的所有图片，调用车牌识别函数进行测试。
    """
    # 获取数据集路径下所有文件
    file_count = count_files_in_directory(dataset_path)
    image_files = [f for f in os.listdir(dataset_path) if f.endswith('.jpg')]
    success = 0
    aver = 0
    for image_file in image_files:
        image_path = os.path.join(dataset_path, image_file)

        # 解析文件名，提取车牌信息
        parsed_data = parse_filename(image_file)
        if parsed_data:
            if(float(parsed_data["Light"])> 109.125125):
                test_license = license_identity(image_path)
        else:
            print(f"Error parsing file name: {image_file}")

        license = generate_license_plate(parsed_data[4])# 放入车牌字符串
        if(license==test_license):
            success+=1  #成功样例加一

    success_rate = success/file_count

    return success_rate


def generate_license_plate(index_str):
    """
    根据车牌号的索引字符串生成车牌号
    """
    # 分割索引字符串
    indices = index_str.split('_')

    # 省份：取第一个索引
    province_index = int(indices[0])
    province = provinces[province_index] if province_index < len(provinces) else 'O'

    # 字母：取第二个索引
    alphabet_index = int(indices[1])
    alphabet = alphabets[alphabet_index] if alphabet_index < len(alphabets) else 'O'

    # 车牌号字符：取接下来的五个索引
    plate_chars = []
    for i in range(2, 8):
        char_index = int(indices[i])
        char = ads[char_index] if char_index < len(ads) else 'O'
        plate_chars.append(char)

    # 合并车牌号
    license_plate = province + alphabet + ''.join(plate_chars)
    return license_plate


if __name__ == "__main__":
    dataset_path = r"D:\CCPD2020\ccpd_green\test"  # 数据集路径
    test_license_plate_recognition(dataset_path)
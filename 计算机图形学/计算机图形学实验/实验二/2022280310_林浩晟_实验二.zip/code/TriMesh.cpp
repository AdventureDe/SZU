﻿#include "TriMesh.h"
#include<algorithm>

// 颜色
const glm::vec3 basic_colors[8] = {
    glm::vec3(1.0, 1.0, 1.0),  // white
    glm::vec3(1.0, 1.0, 0.0),  // yellow
    glm::vec3(0.0, 1.0, 0.0),  // green
    glm::vec3(0.0, 1.0, 1.0),  // cyan
    glm::vec3(1.0, 0.0, 1.0),  // magenta
    glm::vec3(1.0, 0.0, 0.0),  // red
    glm::vec3(0.0, 0.0, 0.0),  // black
    glm::vec3(0.0, 0.0, 1.0)   // blue
};

// 立方体的顶点
const glm::vec3 cube_vertices[8] = {
    glm::vec3(-0.5, -0.5, -0.5),
    glm::vec3(0.5, -0.5, -0.5),
    glm::vec3(-0.5, 0.5, -0.5),
    glm::vec3(0.5, 0.5, -0.5),
    glm::vec3(-0.5, -0.5, 0.5),
    glm::vec3(0.5, -0.5, 0.5),
    glm::vec3(-0.5, 0.5, 0.5),
    glm::vec3(0.5, 0.5, 0.5)
};

TriMesh::TriMesh() {
}

TriMesh::~TriMesh() {
}

std::vector<glm::vec3> TriMesh::getVertexPositions() {
    return vertex_positions;
}

std::vector<glm::vec3> TriMesh::getVertexColors() {
    return vertex_colors;
}

std::vector<vec3i> TriMesh::getFaces() {
    return faces;
}

std::vector<glm::vec3> TriMesh::getPoints() {
    return points;
}

std::vector<glm::vec3> TriMesh::getColors() {
    return colors;
}

void TriMesh::cleanData() {
    vertex_positions.clear();
    vertex_colors.clear();

    faces.clear();

    points.clear();
    colors.clear();
}

void TriMesh::storeFacesPoints() {
    points.clear();
    colors.clear();

    // 根据每个三角面片的顶点下标存储要传入 GPU 的数据
    for (int i = 0; i < faces.size(); i++) {
        // 坐标
        points.push_back(vertex_positions[faces[i].x]);
        points.push_back(vertex_positions[faces[i].y]);
        points.push_back(vertex_positions[faces[i].z]);

        // 颜色
        colors.push_back(vertex_colors[faces[i].x]);
        colors.push_back(vertex_colors[faces[i].y]);
        colors.push_back(vertex_colors[faces[i].z]);
    }
}

void TriMesh::generateCow() {
    cleanData(); 
    readOff("./Models/cow.off");
}

void TriMesh::readOff(const std::string &filename) {
    if (filename.empty()) return;

    // fin打开文件读取文件信息
    std::ifstream fin;
    fin.open(filename);
    if (!fin) {
        printf("File open failed.\n");
        return;
    } else {
        std::string str; fin >> str;
        //读取文件中顶点数、面片数、边数
        int nVertices, nFaces, nEdges; fin >> nVertices >> nFaces >> nEdges;

        float mx = -1e9, mn = 1e9;  //最大坐标 最小坐标
        for (int i = 0; i < nVertices; i++) 
        {       //根据顶点数，循环读取每个顶点坐标
            glm::vec3 tmp_node; fin >> tmp_node.x >> tmp_node.y >> tmp_node.z;
            vertex_positions.push_back(tmp_node);
            mx = std::max({ mx, tmp_node.x, tmp_node.y, tmp_node.z });
            mn = std::min({ mn, tmp_node.x, tmp_node.y, tmp_node.z });   
        }
        for (int i = 0; i < nVertices; i++) 
            vertex_colors.push_back(glm::vec3((vertex_positions[i].x - mn) / (mx - mn), 
                                                (vertex_positions[i].y - mn) / (mx - mn), (vertex_positions[i].z - mn) / (mx - mn)));
        // 根据面片数循环读取每个面片信息, 用构建的 vec3i 结构体保存
        for (int i = 0; i < nFaces; i++) {
            // num 记录此面片由几个顶点构成, a 、b 、c 为构成该面片顶点序号
            int num, a, b, c; fin >> num >> a >> b >> c;
            faces.push_back(vec3i(a, b, c));
        }
    }
    fin.close();
    storeFacesPoints();
};